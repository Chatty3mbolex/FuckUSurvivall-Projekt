package com.yourgame.survival.screens;


import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.FrameBuffer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.utils.ScissorStack;
import com.yourgame.survival.SurvivalGame;
import com.yourgame.survival.data.Inventory;
import com.yourgame.survival.data.SkillDefs;
import com.yourgame.survival.data.SkillEffects;
import com.yourgame.survival.entity.Entities;
import com.yourgame.survival.entity.EntityMetrics;
import com.yourgame.survival.entity.EntityType;
import com.yourgame.survival.render.ChunkRenderer;
import com.yourgame.survival.render.EntityRegions;
import com.yourgame.survival.render.EntityRenderer;
import com.yourgame.survival.render.RenderPipeline;
import com.yourgame.survival.render.TilesetRegions;
import com.yourgame.survival.render.UiRegions;
import com.yourgame.survival.systems.AiSystem;
import com.yourgame.survival.systems.CombatSystem;
import com.yourgame.survival.systems.EncounterSpawner;
import com.yourgame.survival.systems.EntityCollisionSystem;
import com.yourgame.survival.systems.SystemScheduler;
import com.yourgame.survival.world.Biome;
import com.yourgame.survival.world.World;
import com.yourgame.survival.world.TileIds;
// Nicht fertiges Feature: // import com.yourgame.survival.world.SpawnSettings; // (unused)
import com.yourgame.survival.world.WorldNodeSpawner;
import com.yourgame.survival.world.WorldNodes;

// Nicht fertiges Feature: duplicate import (FileHandle is already imported above)
// import com.badlogic.gdx.files.FileHandle;
import java.util.HashMap;
import java.util.ArrayList;

/** Block-3 target: endless chunk stream, visible biomes, basic collision constraints. */
public final class GameScreen extends ScreenAdapter {
  private final SurvivalGame game;

  private OrthographicCamera cam;
  private OrthographicCamera uiCam;
  private SpriteBatch batch;
  private BitmapFont font;
  private ShapeRenderer shape;

  // UI text readability: 200% scale, black (except MainMenu/Pause which are separate screens)
  private static final float UI_FONT_SCALE = com.yourgame.survival.tuning.TuningGameplay.UI_FONT_SCALE;

  // Skill indices (cached to avoid repeated string lookups per-frame)
  private static final int SK_MINING = SkillDefs.indexOf("Mining");
  private static final int SK_WOODCUTTING = SkillDefs.indexOf("Woodcutting");
  private static final int SK_HUNTING = SkillDefs.indexOf("Hunting");
  // Nicht fertiges Feature: unused skills (kept for later re-enable)
  // private static final int SK_FISHING = SkillDefs.indexOf("Fishing");
  // private static final int SK_FORAGING = SkillDefs.indexOf("Foraging");
  private static final int SK_LOOTING = SkillDefs.indexOf("Looting");
  private static final int SK_COMBAT_MELEE = SkillDefs.indexOf("CombatMelee");
  private static final int SK_COMBAT_RANGED = SkillDefs.indexOf("CombatRanged");
  private static final int SK_HEALTH = SkillDefs.indexOf("Health");
  private static final int SK_STAMINA = SkillDefs.indexOf("Stamina");
  private static final int SK_SPRINTING = SkillDefs.indexOf("Sprinting");
  private static final int SK_HUNGER_CTRL = SkillDefs.indexOf("HungerControl");
  private static final int SK_SLEEP_CTRL = SkillDefs.indexOf("SleepControl");
  private static final int SK_BARTER = SkillDefs.indexOf("Barter");
  private static final int SK_NEGOTIATION = SkillDefs.indexOf("Negotiation");
  private static final int SK_TRADING = SkillDefs.indexOf("Trading");
  private static final int SK_STEALTH = SkillDefs.indexOf("Stealth");
  private static final int SK_INTIMIDATION = SkillDefs.indexOf("Intimidation");
  // Nicht fertiges Feature: unused skills (kept for later re-enable)
  // private static final int SK_CLIMBING = SkillDefs.indexOf("Climbing");
  // private static final int SK_BOATING = SkillDefs.indexOf("Boating");

  // Movement speed skill: SkillDefs has no explicit "Speed"; we use Navigation as the movement-speed progression.
  private static final int SK_SPEED = SkillDefs.indexOf("Navigation");
  private static final int SK_COLD_RES = SkillDefs.indexOf("ColdResistance");
  private static final int SK_HEAT_RES = SkillDefs.indexOf("HeatResistance");

  // Mouse aim in world coords (may be clamped to the action ring)
  private float mouseWorldX = 0f;
  private float mouseWorldY = 0f;

  // Cursor rendering: hide OS cursor inside action ring and draw custom cursor.
  private boolean lastCursorHidden = false;
  private boolean drawUnarmedDotCursor = false;

  // Debug: show hovered IDs at cursor (toggle with F3)
  boolean debugHoverIds = true;

  // Debug: make road tiles blocking so we can detect invisible roadMask areas.
  private boolean debugRoadBlocksMovement = false;

  // ===== Ranged combat: Bow arrows (projectile) =====
  private static final int ARROW_MAX = 64;
  // Ammo item id (must match items.json)
  private static final int ITEM_ARROW = 47;
  private static final float ARROW_HIT_RADIUS = 6.0f; // projectile thickness for reliable hits (tight-ish)
  private final boolean[] arrowAlive = new boolean[ARROW_MAX];
  private final float[] arrowX = new float[ARROW_MAX];
  private final float[] arrowY = new float[ARROW_MAX];
  private final float[] arrowVx = new float[ARROW_MAX];
  private final float[] arrowVy = new float[ARROW_MAX];
  private final float[] arrowTravel = new float[ARROW_MAX];
  private final float[] arrowRange = new float[ARROW_MAX];
  private final float[] arrowDmg = new float[ARROW_MAX];
  private float bowCooldownT = 0f;

  // Harvest SFX (hold-to-hack)
// Nicht fertiges Feature:   private float hackSfxT = 0f;

  // RMB hold behavior: emulate repeated click (press/release) at fixed cadence.
  // This lets harvesting/using tools look like discrete swings while still being hold-to-use.
  private static final float RMB_PULSE_PERIOD = 0.5f;
  private static final float RMB_HIT_WINDOW = 0.18f;
  private boolean rmbHoldActive = false;
  private float rmbPulseT = 0f;
  private float rmbHitT = 0f;

  // Sneak (hold V)
  private boolean sneaking = false;
  private boolean sneakingPrev = false;

  private final SystemScheduler scheduler = new SystemScheduler();

  // Block 7: render/input scratch + future state/command buffering (structural only)
  private final RenderScratch scratch = new RenderScratch();
// Nicht fertiges Feature:   private final UiState uiState = new UiState();
  private final InputState inputState = new InputState();
// Nicht fertiges Feature:   private final CommandBuffer commands = new CommandBuffer();

  // Block 8: deterministic command pipeline scaffolding
  private final com.yourgame.survival.sim.CommandQueue commandQueue = new com.yourgame.survival.sim.CommandQueue(256);
// Nicht fertiges Feature:   private com.yourgame.survival.sim.SimContext simContext = null;

  private final long worldSeed;
  private World world;
  private final WorldNodes worldNodes = new WorldNodes();
  private WorldNodeSpawner nodeSpawner;

  private TilesetRegions tiles;
  private ChunkRenderer chunkRenderer;

  // (obsolete netcode removed)

  // Block 4 bootstrap
  private final Entities entities = new Entities();
  private int playerE = -1;
  private final Inventory inv = new Inventory();
  private final com.yourgame.survival.data.Wallet wallet = new com.yourgame.survival.data.Wallet();
  private final com.yourgame.survival.data.PlayerProgress progress = new com.yourgame.survival.data.PlayerProgress();
  private final com.yourgame.survival.data.SurvivalNeeds needs = new com.yourgame.survival.data.SurvivalNeeds();
  // Ensure the player starts a new game at full HP (after hpMax is computed from skills).
  private boolean forceFullHpOnce = true;

  // Nicht fertiges Feature: commented out unused method
  /*
  private static long fnv1aStep(long h, long v) {
    // 64-bit FNV-1a
    h ^= v;
    return h * 0x100000001b3L;
  }
  */

  // (obsolete snapshot hashing removed)

  // (obsolete replication code removed)

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  

  
  private final com.yourgame.survival.systems.DayNightSystem dayNight = new com.yourgame.survival.systems.DayNightSystem();

  // Day/Night visuals
  private Texture dayNight1x1;
  private Texture dnLightTex;      // radial gradient (debug lamp)
  private FrameBuffer dnMaskFbo;
  private TextureRegion dnMaskRegion;

  // Fog of War overlay (playfield): low-res alpha texture scaled over the area
  private Pixmap fowPm;
  private Texture fowTex;
  private float dnLampScreenX = 0f;
  private float dnLampScreenY = 0f;
  private boolean dnLampScreenValid = false;
  private float dnVisual = 1f;     // current 0..1 (0=night,1=day)
  private float dnWarm = 0f;       // current 0..1 warm twilight
  private float dnTarget = 1f;
  private float dnWarmTarget = 0f;
  private int dnDebugMode = 0;     // 0=off, 1=force-day, 2=force-night
  private boolean dnLightOn = false;   // F5 debug lamp
  private boolean dnLightXLOn = false; // Shift+L extra-large debug lamp

  // Day/Night BG music (absolute paths, sequential loop playlists)
  private static final float DN_MIDPOINT = 0.5f;
  private static final float DN_SWITCH_SEC = 2.0f;
  private static final float TRACK_FADE_IN_SEC = 1.25f;

  private boolean dnSideDay = true;
  private boolean dnSwitching = false;
  private float dnSwitchT = 0f;
  private boolean dnSwitchToDay = true;

  private float dayTrackFadeInT = TRACK_FADE_IN_SEC;
  private float nightTrackFadeInT = TRACK_FADE_IN_SEC;

  private final String[] dayBgTracks = {
    "C:/Users/kuehn/Downloads/geovanebruny-16-acoustic-piano-life-deserves-16309.mp3",
    "C:/Users/kuehn/Downloads/dmassaiii-dreaded-lullaby-255495.mp3",
  };
  private final String[] nightBgTracks = {
    "C:/Users/kuehn/Downloads/dream-protocol-broken-dreams-but-wex27ll-remain-r1-212005.mp3",
    "C:/Users/kuehn/Downloads/pixelmaniax-varnen-377757.mp3",
  };
  private int dayBgIdx = 0;
  private int nightBgIdx = 0;
  private Music dayBgMusic;
  private Music nightBgMusic;
  private float dayBgVol = 1f;
  private float nightBgVol = 0f;

  private final com.yourgame.survival.data.DataRegistry data = new com.yourgame.survival.data.DataRegistry();
  private final com.yourgame.survival.systems.CraftSystem craft = new com.yourgame.survival.systems.CraftSystem();
  private com.yourgame.survival.systems.MerchantSystem merchants;

  // Central item pricing DB (COPPER based)
  private final com.yourgame.survival.data.PriceBook priceBook = new com.yourgame.survival.data.PriceBook(60);

  // Pricing editor (Shift+F12)
  private boolean pricingOpen = false;
  private boolean pricingPresetPopup = false;
  private int pricingSel = 0;
  private int pricingScroll = 0;
  private final int[] pricingEditCopper = new int[60];
  private String pricingEditBuffer = "";
  private String[] pricingPresetNames = new String[0];

  private final AiSystem ai = new AiSystem();
  private final CombatSystem combat = new CombatSystem();
  private final EntityCollisionSystem entityCollision = new EntityCollisionSystem();
  private final EncounterSpawner encounterSpawner = new EncounterSpawner();

  // WorldMap state (v3 save). This is the persistent data that goes into savegames.
  private final com.yourgame.survival.worldmap.WorldMapState worldMap = new com.yourgame.survival.worldmap.WorldMapState();

  // WorldMap runtime (rules engine). Kept separate from the state so we can change rules
  // without breaking savegames.
  //
  // Decision:
  // - We construct the alpha registry in code for now.
  // - Later this will be loaded from assets (JSON etc.), but the template IDs must remain stable
  //   because savegames store them.
  private final com.yourgame.survival.worldmap.WorldMapRuntime worldMapRt =
      new com.yourgame.survival.worldmap.WorldMapRuntime(
          com.yourgame.survival.worldmap.WorldMapRuntime.createAlphaRegistry());

  // WorldMap travel glue (runtime state change + world loading).
  private final com.yourgame.survival.worldmap.WorldMapTravelController worldMapTravel =
      new com.yourgame.survival.worldmap.WorldMapTravelController(
          worldMapRt,
          new com.yourgame.survival.worldmap.JsonAreaWorldLoader());

  // ============================================================
  // FUSA Story mode (AREAS ONLY)
  // ============================================================
  // Procedural mode has been removed: the game always runs in Areas-only mode.
  // Guardrail: we must NOT stream/generate biomes/chunks in the background during play.
  private static final boolean AREA_MODE = true;

  // ============================================================
  // Debug toggles (dev)
  // ============================================================

  // F10: verbose tile-tree streaming debug overlay via toast.
  private boolean dbgTileTrees = false;
  private float dbgTileTreesToastCooldown = 0f;

  // Tile-tree harvest progress cache (tile-based; avoids using Entities slots).
  private int tileTreeHitTx = -1;
  private int tileTreeHitTy = -1;
  private float tileTreeHitHp = 0f;
  private float tileTreeHitUiT = 0f;

  // Runtime seconds since this GameScreen instance started (used for simple cooldowns).
  private float runtimeSec = 0f;

  // Tile-tree policy:
  // - false: trees never get cut/removed and never leave stumps (harvest yields drops only).
  // - true: trees are cut persistently via areaTreeCutBits (stumps).
  private static final boolean TILE_TREES_FELL_ON_HARVEST = true;

  // Anti-exploit: cooldown before the same tile-tree can yield drops again.
  private static final float TILE_TREE_HARVEST_COOLDOWN_SEC = 35f;
  private final com.badlogic.gdx.utils.IntFloatMap tileTreeNextHarvestAtSec = new com.badlogic.gdx.utils.IntFloatMap();

  // One-shot cleanup: if older builds spawned NODE_TREE/NODE_STUMP entities, kill them once.
  private boolean tileTreeEntitiesPurged = false;

  // Area bounds state (computed from player position)
  private boolean inRedZone = false;
// Nicht fertiges Feature:   private boolean inVoid = false;
// Nicht fertiges Feature:   private float voidTimer = 0f;
  // Void penalty stage:
  // 0 = not penalized yet
  // 1 = 50% HP penalty applied, next expiry kills player
// Nicht fertiges Feature:   private int voidStage = 0;

  // WorldMap UI (Shift+M)
  private boolean mapOpen = false;
  private float mapPanX = 0f;
  private float mapPanY = 0f;
  private boolean mapDragging = false;
  private float mapDragLastX = 0f;
  private float mapDragLastY = 0f;
  private int mapSelectedAx = 0;
  private int mapSelectedAy = 0;
// Nicht fertiges Feature:   private boolean mapZoomOpen = false;

  // Map view mode: 0 = world overview, 1 = area map (live or war-stand).
  private int mapViewMode = 0;

  // Simple transition (zoom + crossfade) between world overview and area map.
  private boolean mapTransActive = false;
  private float mapTransT = 0f;   // 0..1
  private int mapTransFrom = 0;
  private int mapTransTo = 0;

  // Snapshot invalidation: update the map UI only when something changed.
// Nicht fertiges Feature:   private boolean worldMapDirty = true;

  // Fog of War (persistent explored + dynamic visible)
  private float fowAccT = 0f;

  private final com.yourgame.survival.systems.HarvestSystem harvest = new com.yourgame.survival.systems.HarvestSystem();
  private final com.yourgame.survival.systems.BuildingSystem building = new com.yourgame.survival.systems.BuildingSystem();

  // UI state
  private boolean shopOpen = false;
  private boolean craftOpen = false;

  // Food effects (smooth over time): fill hunger first, then HP.
  private float pendingFoodHunger = 0f;
  private float pendingFoodHp = 0f;
  private boolean invOpen = false;
  // Inventory panel placement: when opened while other panels are present, snap to next free spot.
  private boolean invJustOpened = false;
  private boolean walletOpen = false;
  private int openMerchantE = -1;

  // Boot/preload overlay (covers the world at start, then fades out; blocks simulation until done)
  private static final float BOOT_OVERLAY_FILL_SEC = 8.0f;
  private static final float BOOT_OVERLAY_FADE_SEC = 1.0f;
  private boolean bootOverlayActive = true;
  private boolean bootOverlayControl = false;
  private float bootOverlayT = 0f;
  private float bootOverlayFadeT = 0f;
  private float bootOverlayFill = 0f;
  private float bootOverlayA = 1f;

  // Inventory panel drag (screen-space)
  private boolean invDrag = false;
  private float invDragDx = 0f;
  private float invDragDy = 0f;
  private float invAnchorX = Float.NaN;
  private float invAnchorY = Float.NaN;

  // Popup panels (build/craft/chest) drag + anchors (screen-space)
  private boolean buildDrag = false;
  private float buildDragDx = 0f;
  private float buildDragDy = 0f;
  private float buildAnchorX = Float.NaN;
  private float buildAnchorY = Float.NaN;

  private boolean craftDrag = false;
  private float craftDragDx = 0f;
  private float craftDragDy = 0f;
  private float craftAnchorX = Float.NaN;
  private float craftAnchorY = Float.NaN;

  private boolean chestDrag = false;
  private float chestDragDx = 0f;
  private float chestDragDy = 0f;
  private float chestAnchorX = Float.NaN;
  private float chestAnchorY = Float.NaN;

  // Block 9 economy: runtime shop offers (fixed + daily wandering)
  private final int[] shopItemId = new int[12];
  private final int[] shopBuy = new int[12];
  private final int[] shopSell = new int[12];
  private int shopOfferCount = 0;
  private float prevDayT = 0f;
  private int dayIndex = 0;

  // --- UI layout caches (for drag & drop hit tests) ---
  // Build panel
  private boolean buildLayoutValid = false;
  private float buildPanelX0, buildPanelY0, buildPanelW, buildPanelH;
  private float buildSlotsX0, buildSlotsY0, buildSlotPx, buildPadPx;
  private int buildSlotsCount = 0;
  private float shopSlotsX0, shopSlotsY0, shopSlotPx, shopPadPx;
  private final int shopCols = 6;
  private final int shopRows = 2;
  private float shopPanelX0, shopPanelY0, shopPanelW, shopPanelH;
  private boolean shopLayoutValid = false;

  private float invNormSlotsX0, invNormSlotsY0;
  private float invToolSlotsX0, invToolSlotsY0;
  private float invSlotPx, invPadPx;
  private int invNormRowsDrawn = 0;
  private int invToolRowsDrawn = 0;

  private float hotbarX0, hotbarY0, hotbarSlotPx, hotbarPadPx;
// Nicht fertiges Feature:   private boolean hotbarLayoutValid = false;

  // --- Drag & popup state ---
  private static final int DRAG_SRC_NONE = 0;
  private static final int DRAG_SRC_SHOP = 1;
  private static final int DRAG_SRC_TOOLINV = 2;
  private static final int DRAG_SRC_HOTBAR = 3;
  private static final int DRAG_SRC_NORMINV = 4;
  private static final int DRAG_SRC_BUILD = 5;

  private boolean dragArmed = false;
  private boolean dragActive = false;
  private int dragSrc = DRAG_SRC_NONE;
  private int dragItemId = -1;
  private int dragIndex = -1; // shop offer idx OR tool slot idx
  private float dragStartX, dragStartY;

  private boolean buyPopup = false;
  private int buyOfferIdx = -1;
  private int buyItemId = -1;
  private int buyPreferredSlot = -1;
  private boolean buyPreferredToolArea = false;
  private int buyAmount = 1;
  private int buyMax = 1;
  private String buyBuffer = "";
  private int buyPriceEach = 0;


  private boolean sellPopup = false;
  private int sellItemId = -1;
  private int sellAmount = 1;
  private int sellMax = 1;
// Nicht fertiges Feature:   private String sellBuffer = "";
  private int sellPriceEach = 0;
  private int sellPriceEachRaw = 0;

  // Craft UI (panel): qty input per recipe + hover requirements
  private int craftHoverIdx = -1;
  private int craftQtyFocusIdx = -1;
  private String craftQtyBuffer = "1";
  private int[] craftQtyByRecipe = new int[0];
  private float craftScroll = 0f;

  private boolean prevLmbDown = false;

  // Skill menu (P)
  private boolean skillsOpen = false;
  private int skillHover = -1;

  // resolved equipped tool each frame (tools must exist in inventory + be in hotbar)
  // Nicht fertiges Feature: unused (logic uses equippedFromHotbar() + method param instead)
  // private int equippedItemId = -1;

  private final int[] hotbar = new int[8];
  private int hotbarSel = 0;

  // Building
  private boolean buildMode = false;
  private float buildRot = 0f;
  private int buildSel = 0; // 0..4
  private final com.yourgame.survival.data.ChestStore chestStore = new com.yourgame.survival.data.ChestStore();
  private int openChestE = -1;

  private RenderPipeline renderPipeline;
  private EntityRegions entityRegions;
  private EntityRenderer entityRenderer;
  private UiRegions uiRegions;

  // Wallet coin icons (Moneda*)
  private Texture walletCoinCopperTex;
  private Texture walletCoinSilverTex;
  private Texture walletCoinGoldTex;
  private TextureRegion walletCoinCopperIcon;
  private TextureRegion walletCoinSilverIcon;
  private TextureRegion walletCoinGoldIcon;

  // Skill menu icons (loaded once; avoid loading inside render)
  private final HashMap<Integer, Texture> skillIconTex = new HashMap<>();
  private boolean skillIconsLoaded = false;

  private static final class SkillMenuRow {
    static final int HEADER1 = 1;
    static final int HEADER2 = 2;
    static final int SKILL = 3;

    final int kind;
    final String label;
    final int skillIndex; // only for SKILL
    final String catKey;  // for visibility / toggling (category)
    final String subKey;  // for visibility / toggling (subcategory)

    SkillMenuRow(int kind, String label, int skillIndex, String catKey, String subKey) {
      this.kind = kind;
      this.label = label;
      this.skillIndex = skillIndex;
      this.catKey = catKey;
      this.subKey = subKey;
    }
  }

  private final ArrayList<SkillMenuRow> skillMenuRows = new ArrayList<>(128);
  private boolean skillMenuRowsBuilt = false;
  private final HashMap<String, Boolean> skillMenuCatOpen = new HashMap<>();
  private final HashMap<String, Boolean> skillMenuSubOpen = new HashMap<>();

  // Block 11 save/load toast
  private String toast = "";
  private float toastT = 0f;

  // Minimal player state
  private float px = 0f;
  private float py = 0f;

  // Player movement smoothing (accelerate/brake; avoids abrupt stop)
  private float playerVx = 0f;
  private float playerVy = 0f;

  // Player facing smoothing: angle (radians) that we steer toward the mouse, clamped to the front hemisphere.
  private float playerAimA = 0f;
// Nicht fertiges Feature:   private boolean playerAimInit = false;

  // Progression constraints (Block 3)
  private boolean hasBoat = false;
  private boolean hasClimb = false;

  private final int streamRadiusChunks = 1;

  // Startup warmup: keep streaming radius at 0 for a short time to avoid a generation burst on "New Game".
  // This reduces immediate chunk generation from (2r+1)^2 to 1, then ramps to the configured radius.
  private int streamWarmupFrames = 45;

  // Loaded chunk rect (computed once per tick)
  private int loadedMinCx, loadedMaxCx, loadedMinCy, loadedMaxCy;

  // Base reaches (world units). Effective reach is base + EntityMetrics.radius(target).
  private static final float REACH_HARVEST = com.yourgame.survival.tuning.TuningGameplay.REACH_HARVEST;
  private static final float REACH_COMBAT = com.yourgame.survival.tuning.TuningGameplay.REACH_COMBAT;
  private static final float REACH_PICKUP = com.yourgame.survival.tuning.TuningGameplay.REACH_PICKUP;
// Nicht fertiges Feature:   private static final float REACH_BUILD_REMOVE = com.yourgame.survival.tuning.TuningGameplay.REACH_BUILD_REMOVE;
// Nicht fertiges Feature:   private static final float REACH_SHOP = com.yourgame.survival.tuning.TuningGameplay.REACH_SHOP;
// Nicht fertiges Feature:   private static final float REACH_BED = com.yourgame.survival.tuning.TuningGameplay.REACH_BED;

  // Action cone: must stay in front of the player (max +/-60° around facing => 120° total).
  private static final float ACTION_FOV_DEG = com.yourgame.survival.tuning.TuningGameplay.ACTION_FOV_DEG;

  // Purely visual: hand/tool swing animation duration (seconds).
  private static final float HAND_SWING_DUR = com.yourgame.survival.tuning.TuningGameplay.HAND_SWING_DUR;

  // Default action ring radius (world units). Individual items can override this later for balancing.
  private static final float ACTION_RADIUS_DEFAULT = com.yourgame.survival.tuning.TuningGameplay.ACTION_RADIUS_DEFAULT;

  // BLOCK B: camera zoom (performance: less visible tiles)
  private static final float ZOOM_DEFAULT = com.yourgame.survival.tuning.TuningGameplay.ZOOM_DEFAULT; // current standard
  private static final float ZOOM_MIN = com.yourgame.survival.tuning.TuningGameplay.ZOOM_MIN;
  // Max zoom-out is significantly closer than before (was 0.70).
  private static final float ZOOM_MAX = com.yourgame.survival.tuning.TuningGameplay.ZOOM_MAX;
  private static final float ZOOM_STEP_WHEEL = com.yourgame.survival.tuning.TuningGameplay.ZOOM_STEP_WHEEL;
  private static final float ZOOM_STEP_KEYS = com.yourgame.survival.tuning.TuningGameplay.ZOOM_STEP_KEYS;

  private int pendingScrollY = 0;

  // Skill menu scrolling
  private int pendingSkillScrollY = 0;
  private float skillMenuScrollPx = 0f;

  // NOTE: LibGDX calls show() again when we resume from PauseScreen via setScreen(resumeTo).
  // Guard against re-initializing and re-spawning entities on resume.
  private boolean shownOnce = false;
  private InputAdapter inputAdapter;

  // Modularization controllers (Stable 0.003)
  private WorldView worldView;
  private HudRenderer hudRenderer;
  private DebugOverlay debugOverlay;
  private CursorController cursorController;
  private CombatController combatController;
  private GameInputController inputController;

  public GameScreen(SurvivalGame game) {
    this(game, nextUniqueSeed24Long());
  }

  

  public GameScreen(SurvivalGame game, long worldSeed) {
    this.game = game;
    this.worldSeed = worldSeed;
    resetWorld(worldSeed);

    // New game start time: fixed to day so the player doesn't spawn into immediate darkness.
    // (t=0 is midnight in daylightPhased())
    dayNight.t = 0.25f;
    dnVisual = 1f;
    dnWarm = 0f;

    this.merchants = new com.yourgame.survival.systems.MerchantSystem(worldSeed);
  }

  private static String lastSeed24 = null;

  // 24 hex chars (12 random bytes) -> hashed into a long for worldgen.
  private static long nextUniqueSeed24Long() {
    java.security.SecureRandom r = new java.security.SecureRandom();
    for (int tries = 0; tries < 10; tries++) {
      byte[] b = new byte[12];
      r.nextBytes(b);
      String s = toHex24(b);
      if (lastSeed24 == null || !lastSeed24.equals(s)) {
        lastSeed24 = s;
        return seedLongFrom24(s);
      }
    }
    // fallback: time-based (still unique)
    String s = Long.toHexString(System.nanoTime()) + Long.toHexString(System.currentTimeMillis());
    if (s.length() < 24) s = ("000000000000000000000000" + s).substring(s.length());
    if (s.length() > 24) s = s.substring(0, 24);
    lastSeed24 = s;
    return seedLongFrom24(s);
  }

  private static String toHex24(byte[] b12) {
    char[] hex = "0123456789abcdef".toCharArray();
    char[] out = new char[24];
    for (int i = 0; i < 12; i++) {
      int v = b12[i] & 0xFF;
      out[i * 2] = hex[v >>> 4];
      out[i * 2 + 1] = hex[v & 15];
    }
    return new String(out);
  }

  private static long seedLongFrom24(String s24) {
    // Rule from user: seed should be 24 chars; we keep it at 24.
    try {
      java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
      byte[] h = md.digest(s24.getBytes(java.nio.charset.StandardCharsets.UTF_8));
      long v = 0L;
      for (int i = 0; i < 8; i++) v = (v << 8) | (h[i] & 0xFFL);
      return v;
    } catch (java.security.NoSuchAlgorithmException | RuntimeException e) {
      return s24.hashCode();
    }
  }

  private void resetWorld(long seed) {
    world = new World(seed);
    nodeSpawner = new WorldNodeSpawner(world, seed);
    nodeSpawner.resetSpawnedChunks();

    // Block 8: refresh sim context references
// Nicht fertiges Feature:     simContext = new com.yourgame.survival.sim.SimContext(world, entities, inv, wallet, progress, needs, priceBook);
  }

  // Nicht fertiges Feature: commented out unused method
  /*
  private void preloadChunksBlocking(int radiusChunks, int timeoutMs) {
    if (world == null) return;

    int r = Math.max(0, radiusChunks);
    long t0 = System.currentTimeMillis();

    world.requestAroundWorld(px, py, r);

    for (;;) {
      // Commit everything that's ready right now.
      world.tickStreaming(10_000);

      // Check if all chunks in the preload square are available.
      int ccx = (int) Math.floor((px / World.TILE_WORLD) / World.CHUNK_SIZE);
      int ccy = (int) Math.floor((py / World.TILE_WORLD) / World.CHUNK_SIZE);
      boolean ok = true;
      for (int dy = -r; dy <= r && ok; dy++) {
        for (int dx = -r; dx <= r; dx++) {
          if (world.peekChunk(ccx + dx, ccy + dy) == null) { ok = false; break; }
        }
      }
      if (ok) return;

      if (timeoutMs > 0 && (System.currentTimeMillis() - t0) > timeoutMs) return;

      try { Thread.sleep(2); } catch (InterruptedException ignored) {}

      // Keep requesting (in case something got evicted/never queued).
      world.requestAroundWorld(px, py, r);
    }
  }
  */

  private void sanitizeSpawnForWorld() {
    // Only adjust if the tile is not walkable.
    // IMPORTANT: must NOT generate chunks (use peek queries).
    try {
      boolean w0 = world.isWaterAtWorldPeek(px, py, true);
      boolean b0 = world.isBlockedAtWorldPeek(px, py, true);
      int id0 = world.biomeIdAtWorldPeek(px, py, Biome.GRASSLAND.id & 0xff);
      if (!w0 && !b0 && Biome.byId(id0) != Biome.LAVA) return;

      final float step = World.TILE_WORLD; // tile-sized steps
      final int maxR = 64; // search radius in tiles

      // Perimeter scan for first valid tile.
      for (int r = 1; r <= maxR; r++) {
        // top/bottom edges
        for (int dx = -r; dx <= r; dx++) {
          float x1 = px + dx * step;
          float yTop = py + r * step;
          boolean wTop = world.isWaterAtWorldPeek(x1, yTop, true);
          boolean bTop = world.isBlockedAtWorldPeek(x1, yTop, true);
          int idTop = world.biomeIdAtWorldPeek(x1, yTop, Biome.GRASSLAND.id & 0xff);
          if (!wTop && !bTop && Biome.byId(idTop) != Biome.LAVA) { px = x1; py = yTop; return; }

          float yBot = py - r * step;
          boolean wBot = world.isWaterAtWorldPeek(x1, yBot, true);
          boolean bBot = world.isBlockedAtWorldPeek(x1, yBot, true);
          int idBot = world.biomeIdAtWorldPeek(x1, yBot, Biome.GRASSLAND.id & 0xff);
          if (!wBot && !bBot && Biome.byId(idBot) != Biome.LAVA) { px = x1; py = yBot; return; }
        }
        // left/right edges (skip corners already checked)
        for (int dy = -r + 1; dy <= r - 1; dy++) {
          float y1 = py + dy * step;
          float xRight = px + r * step;
          boolean wR = world.isWaterAtWorldPeek(xRight, y1, true);
          boolean bR = world.isBlockedAtWorldPeek(xRight, y1, true);
          int idR = world.biomeIdAtWorldPeek(xRight, y1, Biome.GRASSLAND.id & 0xff);
          if (!wR && !bR && Biome.byId(idR) != Biome.LAVA) { px = xRight; py = y1; return; }

          float xLeft = px - r * step;
          boolean wL = world.isWaterAtWorldPeek(xLeft, y1, true);
          boolean bL = world.isBlockedAtWorldPeek(xLeft, y1, true);
          int idL = world.biomeIdAtWorldPeek(xLeft, y1, Biome.GRASSLAND.id & 0xff);
          if (!wL && !bL && Biome.byId(idL) != Biome.LAVA) { px = xLeft; py = y1; return; }
        }
      }
    } catch (Throwable ignored) {
      // If anything goes wrong, keep the original spawn.
    }
  }

  private void spawnInitialEncounters(int orcsTarget, int deerTarget, int streamRadius) {
    // IMPORTANT (FUSA / Areas-only): entity streaming + culling must be based on the CAMERA center,
    // not the player position.
    // Reason: in AREA_MODE the camera is clamped near edges, so cam.center != player.
    // If we stream/cull around the player we can end up with "no trees visible" near borders.
    float camCenterX = px;
    float camCenterY = py;
    if (AREA_MODE) {
      float tw = World.TILE_WORLD;
      float areaW = com.yourgame.survival.tuning.TuningAreas.AREA_W_TILES * tw;
      float areaH = com.yourgame.survival.tuning.TuningAreas.AREA_H_TILES * tw;

      float halfW = (cam.viewportWidth * cam.zoom) * 0.5f;
      float halfH = (cam.viewportHeight * cam.zoom) * 0.5f;

      camCenterX = MathUtils.clamp(px, halfW, areaW - halfW);
      camCenterY = MathUtils.clamp(py, halfH, areaH - halfH);
    }

    int ccx = (int) Math.floor((camCenterX / World.TILE_WORLD) / World.CHUNK_SIZE);
    int ccy = (int) Math.floor((camCenterY / World.TILE_WORLD) / World.CHUNK_SIZE);

    int r = Math.max(0, streamRadius);
    int minCx = ccx - r;
    int maxCx = ccx + r;
    int minCy = ccy - r;
    int maxCy = ccy + r;

    spawnMany(EntityType.ORK_GRUNT, orcsTarget, minCx, maxCx, minCy, maxCy);
    spawnMany(EntityType.ANIMAL_DEER, deerTarget, minCx, maxCx, minCy, maxCy);
  }

  private void spawnMany(EntityType t, int target, int minCx, int maxCx, int minCy, int maxCy) {
    // Keep spawns away from the player.
    float minPlayerDist = com.yourgame.survival.tuning.TuningEncounters.ENCOUNTER_MIN_PLAYER_DIST_WU;
    float min2 = minPlayerDist * minPlayerDist;

    // Default: avoid stacking encounter entities.
    // NOTE: for orks we deliberately allow tighter clustering (requested) via pack spawning below.
    float minEntityDist = com.yourgame.survival.tuning.TuningEncounters.ENCOUNTER_MIN_ENTITY_DIST_WU;
    float minE2 = minEntityDist * minEntityDist;

    int spawned = 0;
    int attempts = 0;
    int maxAttempts = Math.max(400, target * 80);

    final boolean isOrk = (t == EntityType.ORK_GRUNT);

    while (spawned < target && attempts < maxAttempts) {
      attempts++;

      int cx = randRange(minCx, maxCx);
      int cy = randRange(minCy, maxCy);

      int tx = cx * World.CHUNK_SIZE + randRange(0, World.CHUNK_SIZE - 1);
      int ty = cy * World.CHUNK_SIZE + randRange(0, World.CHUNK_SIZE - 1);

      float wx = (tx + 0.5f) * World.TILE_WORLD;
      float wy = (ty + 0.5f) * World.TILE_WORLD;

      // MUST NOT generate chunks for encounter placement.
      if (world.isWaterAtWorldPeek(wx, wy, true)) continue;
      if (world.isBlockedAtWorldPeek(wx, wy, true)) continue;
      int bid = world.biomeIdAtWorldPeek(wx, wy, Biome.GRASSLAND.id & 0xff);
      if (Biome.byId(bid) == Biome.LAVA) continue;

      float dx = wx - px;
      float dy = wy - py;
      if (dx * dx + dy * dy < min2) continue;

      if (!isOrk) {
        // Deer etc: keep them spread out.
        boolean nearOther = false;
        for (int k = 0; k < Entities.MAX; k++) {
          if (!entities.alive[k]) continue;
          EntityType ot = entities.type[k];
          if (ot != EntityType.ORK_GRUNT && ot != EntityType.ANIMAL_DEER) continue;
          float ox = entities.x[k] - wx;
          float oy = entities.y[k] - wy;
          if (ox * ox + oy * oy < minE2) { nearOther = true; break; }
        }
        if (nearOther) continue;

        if (entities.spawn(t, wx, wy) >= 0) spawned++;
        continue;
      }

      // Orks: spawn in small packs around a valid center point (more "gebndelt").
      // Do NOT change ork stats/AI; only initial spatial distribution.
      int pack = 3 + randRange(0, 3); // 3..6
      float packR = com.yourgame.survival.tuning.TuningEncounters.ORK_PACK_RADIUS_WU; // tight radius
      float minPackDist = com.yourgame.survival.tuning.TuningEncounters.ORK_PACK_MIN_DIST_WU; // avoid exact stacking
      float minPackDist2 = minPackDist * minPackDist;

      for (int i = 0; i < pack && spawned < target; i++) {
        float ox = (randRange(-1000, 1000) / 1000f) * packR;
        float oy = (randRange(-1000, 1000) / 1000f) * packR;
        float sx = wx + ox;
        float sy = wy + oy;

        if (world.isWaterAtWorldPeek(sx, sy, true)) continue;
        if (world.isBlockedAtWorldPeek(sx, sy, true)) continue;
        int bid2 = world.biomeIdAtWorldPeek(sx, sy, Biome.GRASSLAND.id & 0xff);
        if (Biome.byId(bid2) == Biome.LAVA) continue;

        // avoid placing on top of existing encounter entities
        boolean tooClose = false;
        for (int k = 0; k < Entities.MAX; k++) {
          if (!entities.alive[k]) continue;
          EntityType ot = entities.type[k];
          if (ot != EntityType.ORK_GRUNT && ot != EntityType.ANIMAL_DEER) continue;
          float dx2 = entities.x[k] - sx;
          float dy2 = entities.y[k] - sy;
          if (dx2 * dx2 + dy2 * dy2 < minPackDist2) { tooClose = true; break; }
        }
        if (tooClose) continue;

        if (entities.spawn(t, sx, sy) >= 0) {
          spawned++;
        }
      }

      // If nothing could be placed, keep trying other centers.
      // (No-op: this loop proceeds to the next center anyway; keep flag for clarity.)
      // if (!placedAny) continue;
    }
  }

  @Override
  public void show() {
    if (shownOnce) {
      if (inputAdapter != null) Gdx.input.setInputProcessor(inputAdapter);
      // Ensure cameras match current window size on resume.
      resize(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
      game.audio.applySettings(game.settings);
      return;
    }
    shownOnce = true;

    // Areas-only: do NOT preload/stream procedural chunks here.
    // Area content is loaded explicitly via JsonAreaWorldLoader (ground layer applied into fixed area chunks).

    cam = new OrthographicCamera();
    cam.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());

    uiCam = new OrthographicCamera();
    uiCam.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
    uiCam.update();

    // BLOCK 3: fix camera at maximal zoom-out (30% less than previous standard)
    cam.zoom = ZOOM_MAX;

    batch = new SpriteBatch();
    font = new BitmapFont();
    font.getData().setScale(UI_FONT_SCALE);
    font.setColor(0f, 0f, 0f, 1f);
    shape = new ShapeRenderer();

    // Day/Night overlay texture
    try {
      Pixmap pm = new Pixmap(1, 1, Pixmap.Format.RGBA8888);
      pm.setColor(Color.WHITE);
      pm.fill();
      dayNight1x1 = new Texture(pm);
      pm.dispose();
    } catch (Throwable ignored) {
      dayNight1x1 = null;
    }

    // Day/Night debug lamp texture (radial gradient)
    try {
      final int sz = 128;
      Pixmap pm = new Pixmap(sz, sz, Pixmap.Format.RGBA8888);
      pm.setBlending(Pixmap.Blending.None);
      for (int y = 0; y < sz; y++) {
        for (int x = 0; x < sz; x++) {
          float dx = (x + 0.5f) - sz * 0.5f;
          float dy = (y + 0.5f) - sz * 0.5f;
          float d = (float)Math.sqrt(dx * dx + dy * dy) / (sz * 0.5f);
          float a = 1f - d;
          if (a < 0f) a = 0f;
          // softer falloff
          a = a * a;
          pm.setColor(1f, 1f, 1f, a);
          pm.drawPixel(x, y);
        }
      }
      dnLightTex = new Texture(pm);
      pm.dispose();
    } catch (Throwable ignored) {
      dnLightTex = null;
    }

    // Recreate Day/Night mask framebuffer
    rebuildDnMaskFbo(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());

    // Start day music immediately (night starts when it becomes night)
    dayBgIdx = 0;
    nightBgIdx = 0;
    dnSideDay = (dnVisual >= DN_MIDPOINT);
    dnSwitching = false;
    dnSwitchT = 0f;
    dnSwitchToDay = dnSideDay;
    playDayBg(true);
    // nightBgMusic stays null until needed

    // Boot/preload overlay state (covers world initially and then fades out; blocks control until done)
    bootOverlayActive = true;
    bootOverlayControl = false;
    bootOverlayT = 0f;
    bootOverlayFadeT = 0f;
    bootOverlayFill = 0f;
    bootOverlayA = 1f;

    // BLOCK B: capture mouse wheel for zoom + pricing editor numeric input
    inputAdapter = new InputAdapter() {
      @Override
      public boolean scrolled(float amountX, float amountY) {
        // amountY: positive usually = scroll down
        if (craftOpen) {
          // scroll craft list (do not zoom while craft panel is open)
          craftScroll += (float) Math.signum(amountY) * 90f;
          return true;
        }
        if (skillsOpen) {
          pendingSkillScrollY += (int) Math.signum(amountY);
        } else {
          // Invert wheel so "scroll up" zooms IN (closer) and "scroll down" zooms OUT.
          pendingScrollY -= (int) Math.signum(amountY);
        }
        return true;
      }

      @Override
      public boolean keyTyped(char character) {
        // Buy popup numeric input (quantity)
        if (buyPopup) {
          if (character >= '0' && character <= '9') {
            if (buyBuffer.length() < 5) {
              buyBuffer += character;
              buyApplyBuffer();
            }
            return true;
          }
          return false;
        }

        // Craft panel qty input
        if (craftOpen && craftQtyFocusIdx >= 0) {
          if (character >= '0' && character <= '9') {
            if (craftQtyBuffer.length() < 5) {
              // avoid leading zeros
              if (craftQtyBuffer.equals("0")) craftQtyBuffer = "";
              craftQtyBuffer += character;
              craftApplyQtyBuffer();
            }
            return true;
          }
          return false;
        }

        // Pricing editor numeric input
        if (!pricingOpen) return false;
        if (pricingPresetPopup) return false;

        if (character >= '0' && character <= '9') {
          if (pricingEditBuffer.length() < 9) {
            pricingEditBuffer += character;
            pricingApplyBufferToSelected();
          }
          return true;
        }
        return false;
      }

      @Override
      public boolean keyDown(int keycode) {
        if (buyPopup) {
          if (keycode == Input.Keys.BACKSPACE) {
            if (!buyBuffer.isEmpty()) {
              buyBuffer = buyBuffer.substring(0, buyBuffer.length() - 1);
              buyApplyBuffer();
            }
            return true;
          }
          if (keycode == Input.Keys.ENTER) {
            buyConfirm();
            return true;
          }
          return false;
        }

        // Craft qty editing
        if (craftOpen && craftQtyFocusIdx >= 0) {
          if (keycode == Input.Keys.BACKSPACE) {
            if (!craftQtyBuffer.isEmpty()) {
              craftQtyBuffer = craftQtyBuffer.substring(0, craftQtyBuffer.length() - 1);
              if (craftQtyBuffer.isEmpty()) craftQtyBuffer = "0";
              craftApplyQtyBuffer();
            }
            return true;
          }
          if (keycode == Input.Keys.ENTER) {
            craftApplyQtyBuffer();
            craftQtyFocusIdx = -1;
            return true;
          }
          if (keycode == Input.Keys.ESCAPE) {
            craftQtyFocusIdx = -1;
            return true;
          }
          return false;
        }

        if (!pricingOpen) return false;

        if (!pricingPresetPopup) {
          if (keycode == Input.Keys.BACKSPACE) {
            if (!pricingEditBuffer.isEmpty()) {
              pricingEditBuffer = pricingEditBuffer.substring(0, pricingEditBuffer.length() - 1);
              pricingApplyBufferToSelected();
            }
            return true;
          }
          if (keycode == Input.Keys.ENTER) {
            pricingApplyBufferToSelected();
            return true;
          }
        }

        return false;
      }
    };
    // Wrap input adapter into modular controller (no behavior change)
    inputController = new GameInputController(inputAdapter);
    inputAdapter = inputController;
    Gdx.input.setInputProcessor(inputAdapter);

    renderPipeline = new RenderPipeline();

    tiles = new TilesetRegions();
    chunkRenderer = new ChunkRenderer(tiles);

    entityRegions = new EntityRegions();
    entityRenderer = new EntityRenderer(entityRegions);
    uiRegions = new UiRegions();

    // (obsolete POI sprite setup removed)

    // Controllers (wrappers; keep behavior identical)
    worldView = new WorldView(this);
    hudRenderer = new HudRenderer(this);
    debugOverlay = new DebugOverlay(this);
    cursorController = new CursorController(this);
    combatController = new CombatController(this);

    // Wallet coin icons (Moneda*)
    walletCoinCopperTex = new Texture(Gdx.files.internal("usable assets/Coin_Gems/MonedaR.png"));
    walletCoinSilverTex = new Texture(Gdx.files.internal("usable assets/Coin_Gems/MonedaD.png"));
    walletCoinGoldTex = new Texture(Gdx.files.internal("usable assets/Coin_Gems/MonedaP.png"));
    // each source is 80x16 strip; use first 16x16 coin
    walletCoinCopperIcon = new TextureRegion(walletCoinCopperTex, 0, 0, 16, 16);
    walletCoinSilverIcon = new TextureRegion(walletCoinSilverTex, 0, 0, 16, 16);
    walletCoinGoldIcon = new TextureRegion(walletCoinGoldTex, 0, 0, 16, 16);

    data.loadAll();

    // Craft UI: init qty defaults per recipe
    craftQtyByRecipe = new int[data.recipes.size()];
    for (int i = 0; i < craftQtyByRecipe.length; i++) craftQtyByRecipe[i] = 1;
    craftQtyFocusIdx = -1;
    craftQtyBuffer = "1";
    craftScroll = 0f;

    // Inventory needs item definitions for stackMax + tool routing
    inv.setItemDefs(data.items);
    chestStore.setItemDefs(data.items);

    // Pricing defaults from items.json + override by persisted current pricing
    priceBook.setDefaultsFromItems(data.items);
    priceBook.loadCurrentIfExists();
    priceBook.copyTo(pricingEditCopper);
    pricingSel = 0;
    pricingScroll = 0;
    pricingEditBuffer = String.valueOf(pricingEditCopper[0]);

    // Block 12 audio
    // IMPORTANT: do not start the global AudioBus music here; in-game music is handled exclusively
    // by dayBgMusic/nightBgMusic to avoid overlaps with menu music and double playback.
    game.audio.stopMusic();
    game.audio.applySettings(game.settings);

    // Block 9: init legacy shop offers (kept for now; per-merchant offers override this on open)
    regenShopOffers();
    prevDayT = dayNight.t;

    // Singleplayer spawn rule: never spawn on lava, water, or rock/collision.
    // (Uses peek queries; must not generate chunks.)
    if (true) {
      sanitizeSpawnForWorld();
    }

    // WorldMap (alpha scaffolding): ensure we always have a consistent map state.
    // Decision:
    // - We bootstrap from save-state ONLY.
    // - If the save was created before worldMap existed (old version), we treat it as a new game
    //   and create the mandatory Home area at (0,0).
    // - We do NOT attempt to auto-travel/switch tilemaps yet; this is only the persistence + rules layer.
    worldMapRt.bootstrapIfEmpty(worldMap);

    // FUSA Story: start a NEW game in the authored Forest area (keep HOME; only move spawn/current area).
    // Guardrail: do not override existing savegames that already discovered/traveled.
    if (AREA_MODE) {
      try {
        boolean looksNew = false;
        if (worldMap != null) {
          // After bootstrap, a fresh save has exactly one known area: HOME at (0,0), and current is HOME.
          looksNew = (worldMap.knownAreas.size() == 1)
              && "HOME".equals(worldMap.curTemplateId)
              && worldMap.knownAreas.containsKey(new com.yourgame.survival.worldmap.AreaCoord(0, 0));
        }

        if (looksNew) {
          // Put FOREST_01 one step north of HOME.
          int fax = 0;
          int fay = 1;
          String ftid = com.yourgame.survival.worldmap.WorldMapRuntime.T_FOREST;

          worldMap.knownAreas.put(new com.yourgame.survival.worldmap.AreaCoord(fax, fay), ftid);
          worldMap.setCurrent(fax, fay, ftid);

          // Add connectivity edge (optional UI).
          worldMap.edges.add(new com.yourgame.survival.worldmap.WorldMapState.Edge(0, 0, fax, fay, "road"));

          // Ensure exits exist for both.
          com.yourgame.survival.worldmap.AreaCoord h0 = new com.yourgame.survival.worldmap.AreaCoord(0, 0);
          if (!worldMap.exitsByArea.containsKey(h0)) {
            worldMap.exitsByArea.put(h0, new com.yourgame.survival.worldmap.WorldMapState.AreaExits(true, true, true, true));
          }
          com.yourgame.survival.worldmap.AreaCoord f0 = new com.yourgame.survival.worldmap.AreaCoord(fax, fay);
          if (!worldMap.exitsByArea.containsKey(f0)) {
            worldMap.exitsByArea.put(f0, new com.yourgame.survival.worldmap.WorldMapState.AreaExits(true, true, true, true));
          }

          // Recompute frontier so UI is consistent.
          worldMapRt.rebuildFrontier(worldMap);
        }
      } catch (Throwable ignored) {}
    }

    // FUSA Areas-only mode: load the current area into the world BEFORE spawning the player.
    // This prevents any background biome/procedural world from being used as the visible world.
    if (AREA_MODE) {
      try {
        // Ensure alpha exits exist for current (currently every side is an exit).
        com.yourgame.survival.worldmap.AreaCoord c0 = new com.yourgame.survival.worldmap.AreaCoord(worldMap.curAx, worldMap.curAy);
        if (!worldMap.exitsByArea.containsKey(c0)) {
          worldMap.exitsByArea.put(c0, new com.yourgame.survival.worldmap.WorldMapState.AreaExits(true, true, true, true));
        }
        new com.yourgame.survival.worldmap.JsonAreaWorldLoader().loadInto(this, worldMap.curTemplateId, null);
      } catch (Throwable ignored) {}
    }

    // Spawn player
    playerE = entities.spawn(EntityType.PLAYER, px, py);
    entities.setAlwaysActive(playerE, true);

    int r0 = (streamWarmupFrames > 0) ? 0 : streamRadiusChunks;

    // Singleplayer-only: merchants + procedural nodes + encounters + starter items are not authoritative in MP.
    if (true) {
      // Areas-only mode requirement (FUSA):
      // - Do NOT run background biome/procedural systems (merchants/nodes/encounters) unless ordered.
      if (!AREA_MODE) {
        // Merchants: keep 6 inside the currently rendered/loaded area (3 fixed + 3 wandering)
        // During warmup we keep streaming radius at 0; merchants/nodes will populate after a few frames.
        merchants.ensureMerchantsAround(entities, world, px, py, r0, 3, 3, data, priceBook, progress);

        // BLOCK D: procedural nodes (trees/rocks/ores) spawn deterministically per chunk
        nodeSpawner.ensureAround(entities, worldNodes, px, py, r0);

        // Start-of-game encounters: ensure a populated area immediately.
        // During warmup keep this small to avoid a generation burst.
        //
        // IMPORTANT RULE (user requirement): HOME area must spawn NO enemies.
        boolean isHomeArea = (worldMap != null && "HOME".equals(worldMap.curTemplateId));
        spawnInitialEncounters(
            isHomeArea ? 0 : com.yourgame.survival.tuning.TuningEncounters.INITIAL_ORC_CAP,
            isHomeArea ? 0 : com.yourgame.survival.tuning.TuningEncounters.INITIAL_DEER_CAP,
            r0);
      }

      // Starter items (DEV): add 1 of every defined item so you can inspect sprites one by one.
      // (Tools/weapons have stackMax=1, normal items stack.)
      if (data != null && data.items != null) {
        for (int itemId = 0; itemId < data.items.length; itemId++) {
          if (data.items[itemId] == null) continue;
          inv.add(itemId, 1);
        }
      }

      // DEV CHEAT (requested): set sprint skill to level 20 if present.
      if (SK_SPRINTING >= 0 && SK_SPRINTING < progress.skillLv.length) {
        progress.skillLv[SK_SPRINTING] = 20;
      }
    }

    // Hotbar defaults
    for (int i=0;i<hotbar.length;i++) hotbar[i] = -1;
    // Start with Axe equipped, Pickaxe next to it.
    hotbar[0] = 14;
    hotbar[1] = 15;
    hotbarSel = 0;
  }

  @Override
  public void render(float delta) {
    // (obsolete debug counters removed)

    tickBootOverlay(delta);

    // Controls/input are blocked while the boot overlay is active.
    if (!bootOverlayControl) {
      // Still render the world + UI (overlay covers it), but do not process inputs.
      int selectedTool = equippedFromHotbar();
      if (playerE >= 0) entities.data0[playerE] = selectedTool; // equipped tool/weapon for rendering

      /* ===== SIMULATION TICK ===== */
      updateScheduler(delta);

      // (obsolete client-sync notes removed)

      /* ===== WORLD DRAW ===== */
      worldView.renderWorld(delta, selectedTool);

      // (obsolete rendering removed)

      // (obsolete night-skip overlay removed)

      // Day/Night visuals target + smoothing (never instant, even via debug)
      {
        float rawLight;
        float rawWarm;
        switch (dnDebugMode) {
          case 1 -> {
            rawLight = 1f;
            rawWarm = 0f;
          }
          case 2 -> {
            rawLight = 0f;
            rawWarm = 0f;
          }
          default -> {
            rawLight = dayNight.daylightPhased();
            rawWarm = dayNight.warmTwilight();
          }
        }
        dnTarget = rawLight;
        dnWarmTarget = rawWarm;

        float k = 1f - (float)Math.exp(-delta / 2.5f); // ~2.5s smoothing
        dnVisual += (dnTarget - dnVisual) * k;
        dnWarm += (dnWarmTarget - dnWarm) * k;
      }

      // Day/Night BG music: crossfade day<->night based on dnVisual.
      updateDayNightMusic(delta);

      // Day/Night mask for debug lamp (must run outside UI batch)
      updateDnMask();

      // World-space action overlay (ring + FOV cone)
      // NOTE: boot overlay path runs before fovFx/fovFy are computed in the normal input path.
      // Controls are blocked anyway, so we skip drawing the action overlay here.

      /* ===== UI DRAW ===== */
      hudRenderer.renderUI();
      return;
    }

    if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
      if (buyPopup) {
        buyPopup = false;
        buyBuffer = "";
        dragArmed = false;
        dragActive = false;
      } else if (pricingOpen) {
        pricingOpen = false;
        pricingPresetPopup = false;
      } else if (walletOpen) {
        walletOpen = false;
      } else {
        game.setScreen(new PauseScreen(game, this));
        return;
      }
    }

    // Skill menu: apply scroll wheel to menu (disable zoom while menu is open)
    if (skillsOpen && pendingSkillScrollY != 0) {
      float step = 48f * UI_FONT_SCALE;
      skillMenuScrollPx += pendingSkillScrollY * step;
      if (skillMenuScrollPx < 0f) skillMenuScrollPx = 0f;
      pendingSkillScrollY = 0;
    }

    // BLOCK B: zoom controls
    if (!skillsOpen && pendingScrollY != 0) {
      cam.zoom = MathUtils.clamp(cam.zoom + pendingScrollY * ZOOM_STEP_WHEEL, ZOOM_MIN, ZOOM_MAX);
      pendingScrollY = 0;
    }
    if (Gdx.input.isKeyJustPressed(Input.Keys.PLUS) || Gdx.input.isKeyJustPressed(Input.Keys.EQUALS)) {
      cam.zoom = MathUtils.clamp(cam.zoom - ZOOM_STEP_KEYS, ZOOM_MIN, ZOOM_MAX);
    }
    if (Gdx.input.isKeyJustPressed(Input.Keys.MINUS)) {
      cam.zoom = MathUtils.clamp(cam.zoom + ZOOM_STEP_KEYS, ZOOM_MIN, ZOOM_MAX);
    }

    // Debug toggles for constraints
    if (Gdx.input.isKeyJustPressed(Input.Keys.F1)) hasBoat = !hasBoat;
    if (Gdx.input.isKeyJustPressed(Input.Keys.F2)) hasClimb = !hasClimb;

    // (DBG TileTrees hotkey handled in tick(); render() input can be blocked by the boot overlay.)

    // SHIFT helper (used by multiple debug/editor hotkeys below)
    boolean shiftHeld = Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT) || Gdx.input.isKeyPressed(Input.Keys.SHIFT_RIGHT);

    // ===== Area travel (Shift+T) =====
    // Rule:
    // - Crossing into VOID does NOT auto-travel.
    // - Travel is only possible when holding SHIFT+T while in red zone OR already in void.
    // - Penalties only apply while standing in void.
    // Areas-only: travel can be triggered only while standing in the red zone (still inside the area).
    if (AREA_MODE && shiftHeld && Gdx.input.isKeyJustPressed(Input.Keys.T) && inRedZone) {
      int tx = (int) Math.floor(px / World.TILE_WORLD);
      int ty = (int) Math.floor(py / World.TILE_WORLD);
      int w = com.yourgame.survival.tuning.TuningAreas.AREA_W_TILES;
      int h = com.yourgame.survival.tuning.TuningAreas.AREA_H_TILES;

      com.yourgame.survival.worldmap.Dir4 dir;
      // Areas-only: we never allow stepping outside the area, so direction is always chosen from inside.
      // Choose the nearest edge.
      {
        int distL = tx;
        int distR = (w - 1) - tx;
        int distB = ty;
        int distT = (h - 1) - ty;
        int minD = Math.min(Math.min(distL, distR), Math.min(distB, distT));
        if (minD == distL) dir = com.yourgame.survival.worldmap.Dir4.W;
        else if (minD == distR) dir = com.yourgame.survival.worldmap.Dir4.E;
        else if (minD == distB) dir = com.yourgame.survival.worldmap.Dir4.S;
        else dir = com.yourgame.survival.worldmap.Dir4.N;
      }

      boolean ok = areaTryTravelAtEdge(dir);
      if (ok) {
// Nicht fertiges Feature:         inVoid = false;
// Nicht fertiges Feature:         voidTimer = 0f;
// Nicht fertiges Feature:         voidStage = 0;
      }
    }

    // ===== WorldMap UI (Shift+M) =====
    if (shiftHeld && Gdx.input.isKeyJustPressed(Input.Keys.M)) {
      mapOpen = !mapOpen;
      mapDragging = false;

      if (mapOpen) {
        // Open: start in world overview.
        mapViewMode = 0;
// Nicht fertiges Feature:         mapZoomOpen = false;
        mapTransActive = false;
        mapTransT = 0f;
// Nicht fertiges Feature:         worldMapDirty = false;
        mapSelectedAx = worldMap.curAx;
        mapSelectedAy = worldMap.curAy;
      } else {
        // Close: reset.
        mapViewMode = 0;
// Nicht fertiges Feature:         mapZoomOpen = false;
        mapTransActive = false;
        mapTransT = 0f;
      }
    }

    // Back from area map to world map (ESC while map is open)
    if (mapOpen && mapViewMode == 1 && Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
      mapTransActive = true;
      mapTransT = 0f;
      mapTransFrom = 1;
      mapTransTo = 0;
    }

    // Map panning (drag)
    if (mapOpen) {
      float mx = Gdx.input.getX();
      float my = Gdx.input.getY();
      if (Gdx.input.isButtonPressed(Input.Buttons.LEFT)) {
        if (!mapDragging) {
          mapDragging = true;
          mapDragLastX = mx;
          mapDragLastY = my;
        } else {
          float dx = mx - mapDragLastX;
          float dy = my - mapDragLastY;
          mapPanX += dx;
          mapPanY -= dy;
          mapDragLastX = mx;
          mapDragLastY = my;
        }
      } else {
        mapDragging = false;
      }

      // Map click select + zoom
      if (Gdx.input.justTouched()) {
        float sx = mx;
        float sy = (Gdx.graphics.getHeight() - my);
        float cx0 = (Gdx.graphics.getWidth() * 0.5f) + mapPanX;
        float cy0 = (Gdx.graphics.getHeight() * 0.5f) + mapPanY;
        float cell = 40f;

        for (java.util.Map.Entry<com.yourgame.survival.worldmap.AreaCoord, String> e : worldMap.knownAreas.entrySet()) {
          com.yourgame.survival.worldmap.AreaCoord c = e.getKey();
          float bx = cx0 + c.ax * cell;
          float by = cy0 + c.ay * cell;
          if (sx >= bx - cell * 0.5f && sx <= bx + cell * 0.5f && sy >= by - cell * 0.5f && sy <= by + cell * 0.5f) {
            mapSelectedAx = c.ax;
            mapSelectedAy = c.ay;
// Nicht fertiges Feature:             mapZoomOpen = true;

            // Transition to area map (war-stand or live if current).
            mapTransActive = true;
            mapTransT = 0f;
            mapTransFrom = 0;
            mapTransTo = 1;
            break;
          }
        }
      }
    }

    // ===== WorldMap (alpha scaffolding) debug travel =====
    // Decision:
    // - We add travel triggers behind SHIFT + function keys so normal gameplay controls are not disturbed.
    // - This is NOT the final travel UX. Final travel will be triggered by reaching an exit at an area edge
    //   (or via the WorldMap UI).
    //
    // Why wire it now?
    // - It lets us validate save/load + discovery logic early, even before real area tilemaps exist.
    // - Loader is currently NOOP, so this only mutates WorldMapState and will not change the world.
    // Debug travel hotkeys (kept, but made harder to trigger accidentally while sprinting).
    boolean ctrlHeld = Gdx.input.isKeyPressed(Input.Keys.CONTROL_LEFT) || Gdx.input.isKeyPressed(Input.Keys.CONTROL_RIGHT);
    boolean altHeld = Gdx.input.isKeyPressed(Input.Keys.ALT_LEFT) || Gdx.input.isKeyPressed(Input.Keys.ALT_RIGHT);
    if (shiftHeld && ctrlHeld && altHeld && !shopOpen && !craftOpen && !invOpen && !buildMode && openChestE < 0) {
      if (Gdx.input.isKeyJustPressed(Input.Keys.F6)) debugWorldMapTravel(com.yourgame.survival.worldmap.Dir4.N);
      if (Gdx.input.isKeyJustPressed(Input.Keys.F7)) debugWorldMapTravel(com.yourgame.survival.worldmap.Dir4.E);
      if (Gdx.input.isKeyJustPressed(Input.Keys.F8)) debugWorldMapTravel(com.yourgame.survival.worldmap.Dir4.S);
      if (Gdx.input.isKeyJustPressed(Input.Keys.F9)) debugWorldMapTravel(com.yourgame.survival.worldmap.Dir4.W);
    }

    // Sneak (hold MMB). On release, sneaking ends immediately.
    boolean sneakAllowed = (!shopOpen && !craftOpen && !invOpen && !buildMode && openChestE < 0);
    sneaking = sneakAllowed && Gdx.input.isButtonPressed(Input.Buttons.MIDDLE);
    if (sneaking != sneakingPrev) {
      toast = sneaking ? "Schleichen: AN" : "Schleichen: AUS";
      toastT = 1.2f;
      sneakingPrev = sneaking;
    }

    // Wallet
    if (Gdx.input.isKeyJustPressed(Input.Keys.G)) {
      walletOpen = !walletOpen;
      if (walletOpen) {
        shopOpen = false;
        craftOpen = false;
        invOpen = false;
        buildMode = false;
        openChestE = -1;
        pricingOpen = false;
        pricingPresetPopup = false;
      }
    }

    // Pricing editor
    if (shiftHeld && Gdx.input.isKeyJustPressed(Input.Keys.F12)) {
      pricingOpen = !pricingOpen;
      pricingPresetPopup = false;
      // entering: sync edit buffer
      if (pricingOpen) {
        walletOpen = false;
        pricingClampSelection();
        pricingEditBuffer = String.valueOf(pricingEditCopper[pricingSel]);
      }
    }

    // Toggle UI
    if (!pricingOpen && !walletOpen && Gdx.input.isKeyJustPressed(Input.Keys.B)) {
      buildMode = !buildMode;
      if (buildMode) { invOpen = false; craftOpen = false; shopOpen = false; openChestE = -1; }
    }

    if (!pricingOpen && !walletOpen && Gdx.input.isKeyJustPressed(Input.Keys.I)) {
      invOpen = !invOpen;
      if (invOpen) {
        // Allow inventory to be opened together with other panels.
        // If it would overlap, it will snap to the next free spot on first draw.
        buildMode = false;
        openChestE = -1;
        invJustOpened = true;
        // Force re-placement on first draw (panel size is computed there).
        invAnchorX = Float.NaN;
        invAnchorY = Float.NaN;
      } else {
        invDrag = false;
      }
    }
    if (!pricingOpen && !walletOpen && Gdx.input.isKeyJustPressed(Input.Keys.C)) {
      craftOpen = !craftOpen;
      if (craftOpen) { invOpen = false; shopOpen = false; buildMode = false; openChestE = -1; }
    }

    if (pricingOpen) {
      pricingHandleInput();
    }

    // Build selection + rotation
    if (buildMode) {
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_1)) buildSel = 0;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_2)) buildSel = 1;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_3)) buildSel = 2;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_4)) buildSel = 3;
      if (Gdx.input.isKeyJustPressed(Input.Keys.Q)) buildRot -= 15f;
      if (Gdx.input.isKeyJustPressed(Input.Keys.E)) buildRot += 15f;
    }

    // Interact (E)
    // (obsolete netcode interaction stub removed)

    // Hotbar select 1..8
    if (!shopOpen && !craftOpen && !invOpen && !buildMode && openChestE < 0) {
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_1)) hotbarSel = 0;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_2)) hotbarSel = 1;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_3)) hotbarSel = 2;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_4)) hotbarSel = 3;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_5)) hotbarSel = 4;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_6)) hotbarSel = 5;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_7)) hotbarSel = 6;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_8)) hotbarSel = 7;
    }

    int selectedTool = equippedFromHotbar();
    if (playerE >= 0) entities.data0[playerE] = selectedTool; // equipped tool/weapon for rendering

    // Eat meat: fills Hunger first (+50 per meat, smooth), then when Hunger is full it heals HP (+25 per meat, smooth).
    boolean shiftPressed = Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT) || Gdx.input.isKeyPressed(Input.Keys.SHIFT_RIGHT);
    boolean wantEat = (!shopOpen && !craftOpen && !invOpen && !buildMode && openChestE < 0) &&
        ((shiftPressed && Gdx.input.isKeyJustPressed(Input.Keys.J)) || Gdx.input.isKeyJustPressed(Input.Keys.H));

    if (wantEat) {
      if (inv.spend(28, 1)) {
        pendingFoodHunger += 50f;
        pendingFoodHp += 25f;
        game.audio.sfx("audio/sfx/eat.wav", game.audio.sfxVolume(game.settings));
      } else {
        game.audio.sfx("audio/sfx/ui_error.wav", game.audio.sfxVolume(game.settings));
      }
    }

    // Skill menu (P) – pauses simulation
    if (!shopOpen && !craftOpen && !invOpen && !buildMode && openChestE < 0 && Gdx.input.isKeyJustPressed(Input.Keys.P)) {
      skillsOpen = !skillsOpen;
      if (skillsOpen) {
        skillMenuScrollPx = 0f;
        preloadSkillIcons();
        buildSkillMenuRows();
      }
    }

    // Sleep / bed (SHIFT+P)
    if (!shopOpen && !craftOpen && !invOpen && !buildMode && openChestE < 0 && shiftPressed && Gdx.input.isKeyJustPressed(Input.Keys.P)) {
       
    }

    // When a modal UI is open, do NOT warp/clamp the OS cursor.
    updateMouseWorld(!shopOpen && !craftOpen && !invOpen && !buildMode && !walletOpen && openChestE < 0 && !skillsOpen);

    // Cursor mode:
    // - Default: small crosshair (set in SurvivalGame)
    // - Inside the action ring (non-modal): hide hardware cursor so the in-world aim UI is clean
    {
      boolean modal = shopOpen || craftOpen || invOpen || buildMode || pricingOpen || walletOpen || openChestE >= 0 || skillsOpen;
      boolean wantHidden = false;
      drawUnarmedDotCursor = false;
      if (!modal) {
        float r = actionReach(selectedTool);
        float dx = mouseWorldX - px;
        float dy = mouseWorldY - py;
        if (dx * dx + dy * dy <= r * r + 0.001f) {
          wantHidden = true;
          if (selectedTool < 0) drawUnarmedDotCursor = true;
        }
      }
      if (wantHidden != lastCursorHidden) {
        if (wantHidden) game.setCursorHidden();
        else game.setCursorCrosshair();
        lastCursorHidden = wantHidden;
      }
    }

    // FOV forward vector follows mouse direction, but never into the player's back.
    // Requested: ONLY PLAYER should smoothly face toward the mouse (relative) to avoid stiff snapping.
    byte facingDir = (playerE >= 0) ? entities.dir[playerE] : (byte)2;
    Vector2 baseF = scratch.v2a;
    facingVec(facingDir, baseF);

    // Desired aim dir: mouse direction, but clamped to the front hemisphere (keep "nothing in my back" rule).
    float desiredFx = baseF.x;
    float desiredFy = baseF.y;
    float mdx = mouseWorldX - px;
    float mdy = mouseWorldY - py;
    float ml2 = mdx * mdx + mdy * mdy;
    if (ml2 > 1e-6f) {
      float invLen = (float) (1.0 / Math.sqrt(ml2));
      float ax = mdx * invLen;
      float ay = mdy * invLen;
      if (baseF.x * ax + baseF.y * ay >= 0f) {
        desiredFx = ax;
        desiredFy = ay;
      }
    }

    // Aim angle: hard face toward desired direction (no smoothing) as requested.
    float desiredA = (float) Math.atan2(desiredFy, desiredFx);
    playerAimA = desiredA;
// Nicht fertiges Feature:     playerAimInit = true;

    float fovFx = desiredFx;
    float fovFy = desiredFy;

    // Equipped-in-hand follows mouse (only when no UI/modes are open).
    if (!shopOpen && !craftOpen && !invOpen && !buildMode && openChestE < 0 && playerE >= 0) {
      entities.dir[playerE] = dirFromVel(fovFx, fovFy, entities.dir[playerE]);
    }

    // LMB: build place / remove OR harvest OR interact (all world actions are LMB)
    // Holding LMB emulates repeated click (press/release) at fixed cadence.
    // Damage/work is only applied during the hit window, not during the pause.
    final boolean rmbAllowed = (!shopOpen && !craftOpen && !invOpen && !walletOpen && !pricingOpen && !skillsOpen && !mapOpen && openChestE < 0);
    final boolean rmbPhysJust = rmbAllowed && Gdx.input.isButtonJustPressed(Input.Buttons.LEFT);
    final boolean rmbPhysDown = rmbAllowed && Gdx.input.isButtonPressed(Input.Buttons.LEFT);

    // Merchant/chest interaction on click (must happen before harvest/combat).
    boolean lmbClickHandled = false;
    if (rmbPhysJust) {
      if (tryInteractAtMouse(fovFx, fovFy)) {
        lmbClickHandled = true;
        rmbHoldActive = false;
        rmbPulseT = 0f;
        rmbHitT = 0f;
      }
    }

    boolean rmbJust = false;
    boolean rmbDown = false;
    if (rmbPhysJust && !lmbClickHandled) {
      rmbHoldActive = true;
      rmbPulseT = RMB_PULSE_PERIOD;
      rmbHitT = RMB_HIT_WINDOW;
      rmbJust = true;
      rmbDown = true;
    } else if (rmbPhysDown && !lmbClickHandled) {
      if (!rmbHoldActive) {
        rmbHoldActive = true;
        rmbPulseT = RMB_PULSE_PERIOD;
        rmbHitT = RMB_HIT_WINDOW;
        rmbJust = true;
        rmbDown = true;
      } else {
        rmbPulseT -= delta;
        rmbHitT -= delta;
        if (rmbPulseT <= 0f) {
          // Start next virtual click.
          do {
            rmbPulseT += RMB_PULSE_PERIOD;
          } while (rmbPulseT <= 0f);
          rmbHitT = RMB_HIT_WINDOW;
          rmbJust = true;
        }
        rmbDown = (rmbHitT > 0f);
      }
    } else {
      rmbHoldActive = false;
      rmbPulseT = 0f;
      rmbHitT = 0f;
    }
    if (!lmbClickHandled && (rmbJust || rmbDown)) {
      if (buildMode) {
        if (rmbJust) {
          boolean shift = Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT) || Gdx.input.isKeyPressed(Input.Keys.SHIFT_RIGHT);
          if (shift) {
             
          } else {
            if (!isInsideFov(px, py, mouseWorldX, mouseWorldY, fovFx, fovFy, ACTION_FOV_DEG)) {
              game.audio.sfx("audio/sfx/ui_error.wav", game.audio.sfxVolume(game.settings));
            } else {
              placeBuildAtMouse(mouseWorldX, mouseWorldY);
            }
          }
        }
      } else {
        if (rmbDown) {
          // Skill-based harvest speed: +5% per level (Woodcutting for trees, Mining for rocks/ore)
          int wcLv = (SK_WOODCUTTING >= 0 && SK_WOODCUTTING < progress.skillLv.length) ? progress.skillLv[SK_WOODCUTTING] : 1;
          int miningLv = (SK_MINING >= 0 && SK_MINING < progress.skillLv.length) ? progress.skillLv[SK_MINING] : 1;
          float speedMul = 1f;
          if (selectedTool == 14) speedMul = SkillEffects.mul5(wcLv);
          if (selectedTool == 15) speedMul = SkillEffects.mul5(miningLv);
          float harvestDt = delta * speedMul;
          // If out of stamina, you can't keep harvesting.
          if ((selectedTool == 14 || selectedTool == 15) && needs.stamina <= 0.01f) {
            harvestDt = 0f;
          }

          // Continuous harvest tick (LMB hold). If we hit nothing, only 10% stamina cost.
          if (harvestDt > 0f) {
            float fovDeg = actionFovDeg();
            // Areas-only: tile-trees are NOT Entities (prevents hitting Entities.MAX=2048).
            // Try harvesting a tile-tree first; if none is hit, fall back to entity-based harvesting.
            com.yourgame.survival.systems.HarvestSystem.HarvestTick ht = null;
            if (AREA_MODE && selectedTool == 14) {
              ht = tryHarvestTileTreeFov(
                  px, py,
                  mouseWorldX, mouseWorldY,
                  fovFx, fovFy,
                  fovDeg,
                  REACH_HARVEST,
                  selectedTool,
                  harvestDt);
            }
            if (ht == null || !ht.didWork()) {
              ht = harvest.tickHarvestFov(
                  entities,
                  px, py,
                  mouseWorldX, mouseWorldY,
                  fovFx, fovFy,
                  fovDeg,
                  REACH_HARVEST,
                  selectedTool,
                  harvestDt);
            }

            boolean didWork = (ht != null && ht.didWork());

            // If we didn't hit a harvest-node, allow mining ROCK ground tiles with Pickaxe.
            if (!didWork && selectedTool == 15) {
              if (tryMineRockTile(mouseWorldX, mouseWorldY, REACH_HARVEST, selectedTool)) {
                didWork = true;
              }
            }

            // Stamina: full cost if we did work; 10% if we swung into empty.
            if (selectedTool == 14 || selectedTool == 15) {
              float baseCostPerSec = 6.0f;
              float cost = baseCostPerSec * harvestDt;
              if (!didWork) cost *= 0.10f;
              needs.stamina = Math.max(0f, needs.stamina - cost);
            }

            if (ht != null && ht.event() != null) {
              var ev = ht.event();
              entities.spawnDrop(ev.dropItemId(), ev.dropAmount(), ev.x(), ev.y());

              // FUSA Story: tile-tree persistence (optional)
              try {
                if (AREA_MODE && areaTreePresentBits != null && areaTreeCutBits != null && areaTreeW > 0 && areaTreeH > 0) {
                  EntityType htType = ev.harvestedType();
                  if (TILE_TREES_FELL_ON_HARVEST && htType == EntityType.NODE_TREE && ev.replaceWithStump()) {
                    // NOTE: tile-tree events use a custom Y anchor (ty*TILE_WORLD + 34) so the sprite foot sits on the tile.
                    // If we floor(y / TILE_WORLD) we'd mark the wrong tile (typically +2 tiles).
                    int tx = (int) Math.floor(ev.x() / World.TILE_WORLD);

                    int ty = (int) Math.floor((ev.y() - 34.0f) / World.TILE_WORLD);
                    // Fallback (safety) if the adjusted form produces nonsense.
                    if (ty < 0 || ty >= areaTreeH) {
                      ty = (int) Math.floor(ev.y() / World.TILE_WORLD);
                    }
                    if (tx >= 0 && ty >= 0 && tx < areaTreeW && ty < areaTreeH) {
                      int bit = bitIndex(tx, ty, areaTreeW);
                      if (bitGet(areaTreePresentBits, bit)) {
                        bitSet(areaTreeCutBits, bit, true);
                      }
                    }
                  }
                }
              } catch (Throwable ignored) {}

              game.audio.sfx("audio/sfx/pickup.wav", game.audio.sfxVolume(game.settings));
            }
          }

        } else if (rmbJust) {
// Nicht fertiges Feature:           hackSfxT = 0f;
          game.audio.sfx("audio/sfx/ui_error.wav", game.audio.sfxVolume(game.settings));
        }
      }
    }

    if (!rmbDown) {
      // release stops hack loop immediately
// Nicht fertiges Feature:       hackSfxT = 0f;
    }

    // Combat (LMB)
    // Tools (axe/pickaxe) are reserved for harvesting on LMB.
    // If the click was used for interaction (merchant/chest), do not attack.
    if (!lmbClickHandled && !shopOpen && !craftOpen && !invOpen && !buildMode && openChestE < 0 && Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)
        && selectedTool != 14 && selectedTool != 15) {
      // Visual: trigger hand swing on any attack/use attempt.
      // Requested: NO swing animation for Bow (it shoots an arrow).
      if (playerE >= 0 && selectedTool != 22) {
        entities.aiF0[playerE] = HAND_SWING_DUR;
      }
      // Weapon handling
      if (selectedTool >= 20 && selectedTool <= 27) {
        // Bow (ID 22): uses arrows as ammo.
        if (selectedTool == 22) {
          if (bowCooldownT <= 0f) {
            // Bow: do not spend stamina if no arrows.
            if (inv.countsById[ITEM_ARROW] <= 0) {
              game.audio.sfx("audio/sfx/ui_error.wav", game.audio.sfxVolume(game.settings));
            } else {
              // Spend one arrow.
              inv.spend(ITEM_ARROW, 1);

              // Only now spend stamina.
              if (needs.stamina < 6.0f) {
                game.audio.sfx("audio/sfx/ui_error.wav", game.audio.sfxVolume(game.settings));
              } else {
                needs.stamina = Math.max(0f, needs.stamina - 6.0f);

                int rangedLv = (SK_COMBAT_RANGED >= 0 && SK_COMBAT_RANGED < progress.skillLv.length) ? progress.skillLv[SK_COMBAT_RANGED] : 1;
                float mul = SkillEffects.mul5(rangedLv);
                float baseReload = 0.75f;
                float reload = baseReload / mul;

                // Fire projectile
                float dmg = 12f * mul;
                float speed = 620f;
                float range = 1200f;
                float spread = 0.06f / Math.max(1e-3f, mul);
                if (fireBowArrow(px, py, mouseWorldX, mouseWorldY, fovFx, fovFy, actionFovDeg(), speed, range, dmg, spread)) {
                  bowCooldownT = reload;
                  game.audio.sfx("audio/sfx/attack_ranged.wav", game.audio.sfxVolume(game.settings));
                }
              }
            }
          }
        } else {
        // Melee weapons: simple dmg/range tuning by weapon id.
        float dmg = switch (selectedTool) {
          case 20 -> 14f; // Sword
          case 21 -> 12f; // Spear
          case 23 -> 10f; // Dagger
          case 24 -> 15f; // Mace
          case 25 -> 18f; // Battle Axe
          case 26 -> 13f; // Crystal Staff
          case 27 -> 16f; // Crossbow (fallback melee)
          default -> 12f;
        };
        float range = switch (selectedTool) {
          case 21 -> REACH_COMBAT * 1.25f; // Spear longer
          case 23 -> REACH_COMBAT * 0.85f; // Dagger shorter
          default -> REACH_COMBAT;
        };

        int meleeLv = (SK_COMBAT_MELEE >= 0 && SK_COMBAT_MELEE < progress.skillLv.length) ? progress.skillLv[SK_COMBAT_MELEE] : 1;
        float meleeMul = SkillEffects.mul5(meleeLv);
        dmg *= meleeMul;
        // Note: requested extra range mainly for fists/knife, but applying mildly to melee keeps it consistent.
        range *= meleeMul;

        // Execute melee attack.
        var k = combat.meleeFov(entities, px, py, mouseWorldX, mouseWorldY, fovFx, fovFy, actionFovDeg(), range, dmg);
        if (k != null) onKill(k);
        if (playerE >= 0) entities.aiF0[playerE] = HAND_SWING_DUR;

        game.audio.sfx("audio/sfx/attack_melee.wav", game.audio.sfxVolume(game.settings));
      }
      } else {
        // Unarmed melee (uses the same CombatMelee scaling).
        int meleeLv = (SK_COMBAT_MELEE >= 0 && SK_COMBAT_MELEE < progress.skillLv.length) ? progress.skillLv[SK_COMBAT_MELEE] : 1;
        float meleeMul = SkillEffects.mul5(meleeLv);
        float dmg = 10f * meleeMul;
        float range = REACH_COMBAT * meleeMul;

        var k = combat.meleeFov(entities, px, py, mouseWorldX, mouseWorldY, fovFx, fovFy, actionFovDeg(), range, dmg);
        if (k != null) onKill(k);
        if (playerE >= 0) entities.aiF0[playerE] = HAND_SWING_DUR;

        game.audio.sfx("audio/sfx/attack_melee.wav", game.audio.sfxVolume(game.settings));
      }
    }

    // Bow special: allow a melee shove/smack on RIGHT CLICK while holding the bow.
    if (!shopOpen && !craftOpen && !invOpen && !buildMode && openChestE < 0 && selectedTool == 22
        && Gdx.input.isButtonJustPressed(Input.Buttons.RIGHT)) {
      // small melee hit
      float dmg = 6f;
      float range = REACH_COMBAT * 0.75f;
      var k = combat.meleeFov(entities, px, py, mouseWorldX, mouseWorldY, fovFx, fovFy, actionFovDeg(), range, dmg);
      if (k != null) onKill(k);
      game.audio.sfx("audio/sfx/attack_melee.wav", game.audio.sfxVolume(game.settings));
      if (playerE >= 0) entities.aiF0[playerE] = HAND_SWING_DUR;
    }

    // Debug cursor IDs toggle (F3)
    if (Gdx.input.isKeyJustPressed(Input.Keys.F3)) {
      debugHoverIds = !debugHoverIds;
      toast = (debugHoverIds ? "DEBUG: Hover IDs ON" : "DEBUG: Hover IDs OFF");
      toastT = 2.0f;
    }

    // Day/Night debug toggle (F4): AUTO -> FORCE DAY -> FORCE NIGHT
    if (Gdx.input.isKeyJustPressed(Input.Keys.F4)) {
      dnDebugMode = (dnDebugMode + 1) % 3;
      toast = switch (dnDebugMode) {
        case 1 -> "DEBUG: Day/Night -> FORCE DAY";
        case 2 -> "DEBUG: Day/Night -> FORCE NIGHT";
        default -> "DEBUG: Day/Night -> AUTO";
      };
      toastT = 2.0f;
    }

    // Day/Night debug lamp (F5)
    if (Gdx.input.isKeyJustPressed(Input.Keys.F5)) {
      dnLightOn = !dnLightOn;
      toast = (dnLightOn ? "DEBUG: Lamp ON" : "DEBUG: Lamp OFF");
      toastT = 2.0f;
    }

    // F8 reserved (no fog of war)

    // Day/Night debug lamp (Shift+L) - extra large copy
    if (Gdx.input.isKeyJustPressed(Input.Keys.L)
      && (Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT) || Gdx.input.isKeyPressed(Input.Keys.SHIFT_RIGHT))) {
      dnLightXLOn = !dnLightXLOn;
      toast = (dnLightXLOn ? "DEBUG: Lamp XL ON" : "DEBUG: Lamp XL OFF");
      toastT = 2.0f;
    }

    // DEBUG (Shift+Q): make ROAD tiles blocking so we can "feel" invisible roads.
    if (Gdx.input.isKeyJustPressed(Input.Keys.Q)
      && (Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT) || Gdx.input.isKeyPressed(Input.Keys.SHIFT_RIGHT))) {
      debugRoadBlocksMovement = !debugRoadBlocksMovement;
      toast = (debugRoadBlocksMovement ? "DEBUG: Road blocks movement ON" : "DEBUG: Road blocks movement OFF");
      toastT = 2.0f;
    }

    // Interact / pickup (E)
    if (!pricingOpen && !walletOpen && Gdx.input.isKeyJustPressed(Input.Keys.E)) {
      if (tryToggleShop()) {
        // handled
      } else {
        pickupNearby();
      }
    }

    // UI interactions: shop buy/sell + drag-to-buy + tool->hotbar drag + hotbar reordering + buy popup
    float uiMx = Gdx.input.getX();
    float uiMy = uiMouseYUp();
    boolean hoverHotbar = (hotbarHit(uiMx, uiMy) >= 0);
    if (shopOpen || invOpen || buildMode || buyPopup || sellPopup || dragArmed || dragActive || hoverHotbar) {
      uiHandleDragDropAndPopup();
    }

    // Craft shortcut: craft workbench (key 1) / axe (2) / pickaxe (3)
    if (craftOpen) {
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_1)) craftByOutput(40);
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_2)) craftByOutput(14);
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_3)) craftByOutput(15);
    }

    // Chest transfer shortcuts
    if (openChestE >= 0) {
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_1)) chestStoreFromPlayer(0, 5);
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_2)) chestStoreFromPlayer(1, 5);
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_3)) chestStoreFromPlayer(31, 5);
      if (Gdx.input.isKeyJustPressed(Input.Keys.F)) chestTakeAll();
    }
    collectInputSnapshot(delta, inputState);
    applyCommands(commandQueue);

    /* ===== SIMULATION TICK ===== */
    // Simulation must keep running during the boot overlay to hide initial load spikes.
    updateScheduler(delta);

    // Smoothing must run in the normal gameplay path as well (not only during boot overlay).
    

    // Debug: one compact line/sec for MP position + camera + entity coupling.
    

    /* ===== WORLD DRAW ===== */
    worldView.renderWorld(delta, selectedTool);

    // Day/Night visuals target + smoothing (never instant, even via debug)
    {
      float rawLight;
      float rawWarm;
      switch (dnDebugMode) {
        case 1 -> {
          rawLight = 1f;
          rawWarm = 0f;
        }
        case 2 -> {
          rawLight = 0f;
          rawWarm = 0f;
        }
        default -> {
          rawLight = dayNight.daylightPhased();
          rawWarm = dayNight.warmTwilight();
        }
      }
      dnTarget = rawLight;
      dnWarmTarget = rawWarm;

      float k = 1f - (float)Math.exp(-delta / 2.5f); // ~2.5s smoothing
      dnVisual += (dnTarget - dnVisual) * k;
      dnWarm += (dnWarmTarget - dnWarm) * k;
    }

    // Day/Night BG music: crossfade day<->night based on dnVisual.
    updateDayNightMusic(delta);

    // Day/Night mask for debug lamp (must run outside UI batch)
    updateDnMask();

    // World-space action overlay (ring + FOV cone)
    if (!shopOpen && !craftOpen && !invOpen && !walletOpen) {
      drawActionOverlay(fovFx, fovFy);
    }

    /* ===== UI DRAW ===== */
    hudRenderer.renderUI();

  }

  private void updateScheduler(float delta) {
    // Pause simulation when a modal menu is open (skill + craft).
    if (!skillsOpen && !craftOpen) {
      scheduler.update(delta, this::tick);
    }
  }
  void renderWorld(float delta, int selectedTool) {
    Gdx.gl.glClearColor(0f, 0f, 0f, 1f);
    Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

    // Camera clamp inside the current Area (player cannot enter VOID).
    if (AREA_MODE) {
      float tw = World.TILE_WORLD;
      float areaW = com.yourgame.survival.tuning.TuningAreas.AREA_W_TILES * tw;
      float areaH = com.yourgame.survival.tuning.TuningAreas.AREA_H_TILES * tw;

      float halfW = (cam.viewportWidth * cam.zoom) * 0.5f;
      float halfH = (cam.viewportHeight * cam.zoom) * 0.5f;

      float cx = MathUtils.clamp(px, halfW, areaW - halfW);
      float cy = MathUtils.clamp(py, halfH, areaH - halfH);
      cam.position.set(cx, cy, 0f);
    } else {
      cam.position.set(px, py, 0f);
    }
    cam.update();

    batch.setProjectionMatrix(cam.combined);
    batch.begin();
    // Guardrail: ensure batch state is sane. Some render paths (entities/fog) change blending/color.
    batch.enableBlending();
    batch.setColor(1f, 1f, 1f, 1f);
    // Areas-only: always draw enough chunks to fully cover the camera viewport (+margin).
    float chunkWorld = World.TILE_WORLD * World.CHUNK_SIZE;
    float halfW = (cam.viewportWidth * cam.zoom) * 0.5f;
    float halfH = (cam.viewportHeight * cam.zoom) * 0.5f;
    int rx = (int) Math.ceil(halfW / chunkWorld) + 2;
    int ry = (int) Math.ceil(halfH / chunkWorld) + 2;
    int r = Math.max(rx, ry);
    // IMPORTANT: draw around the camera center (camera is clamped near edges).
    chunkRenderer.draw(batch, world, cam.position.x, cam.position.y, r);
    entityRenderer.tick(delta);

    // FUSA Story: dense forests are drawn from tile bitmasks (NOT as Entities).
    // Layering policy:
    // - Stumps: draw BELOW entities (player should not be hidden by stumps).
    // - Trees: draw ABOVE entities (player walks "under" the canopy).
    if (AREA_MODE && areaTreePresentBits != null && areaTreeCutBits != null && areaTreeW > 0 && areaTreeH > 0) {
      entityRenderer.drawTileTrees(batch, world, areaTreePresentBits, areaTreeCutBits, areaTreeW, areaTreeH,
          cam.position.x, cam.position.y, r,
          false, true,
          !TILE_TREES_FELL_ON_HARVEST);
    }

    boolean uiBlocksHand = shopOpen || craftOpen || invOpen || buildMode || pricingOpen || walletOpen || openChestE >= 0;
    entityRenderer.setPlayerHandVisible(!uiBlocksHand);
    entityRenderer.draw(batch, entities, loadedMinCx, loadedMaxCx, loadedMinCy, loadedMaxCy);

    if (AREA_MODE && areaTreePresentBits != null && areaTreeCutBits != null && areaTreeW > 0 && areaTreeH > 0) {
      entityRenderer.drawTileTrees(batch, world, areaTreePresentBits, areaTreeCutBits, areaTreeW, areaTreeH,
          cam.position.x, cam.position.y, r,
          true, false,
          !TILE_TREES_FELL_ON_HARVEST);
    }
    batch.end();

    // ============================================================
    // Story world: Fog of War overlay in the PLAYFIELD
    // ============================================================
    // Variant 2 (as requested):
    // - Unknown = black
    // - Explored = dark fog overlay (content stays visible)
    // - Visible now = clear, with soft edge
    if (AREA_MODE && shape != null) {
      renderFogOfWarOverlayWorld();
    }

    // ============================================================
    // Area bounds: red border veil (10 tiles wide)
    // ============================================================
    if (AREA_MODE && shape != null && inRedZone) {
      try {
        shape.setProjectionMatrix(cam.combined);
        shape.begin(com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType.Filled);
        shape.setColor(1f, 0f, 0f, 0.22f);

        float tw = com.yourgame.survival.world.World.TILE_WORLD;
        float w = com.yourgame.survival.tuning.TuningAreas.AREA_W_TILES * tw;
        float h = com.yourgame.survival.tuning.TuningAreas.AREA_H_TILES * tw;
        float rz = com.yourgame.survival.tuning.TuningAreas.RED_ZONE_TILES * tw;

        shape.rect(0f, 0f, rz, h);
        shape.rect(w - rz, 0f, rz, h);
        shape.rect(0f, 0f, w, rz);
        shape.rect(0f, h - rz, w, rz);

        shape.end();
      } catch (Throwable ignored) {
        try { shape.end(); } catch (Throwable ignored2) {}
      }
    }

    // World overlays (health bars + projectiles)
    combatController.renderWorldOverlays();

    // Custom cursor (unarmed): visible point cursor, hardware cursor is hidden.
    if (drawUnarmedDotCursor) {
      cursorController.renderWorldCursor(mouseWorldX, mouseWorldY);
    }
  }
  void renderUI() {
    // UI overlay (screen space) — keep it independent from world camera
    batch.setProjectionMatrix(uiCam.combined);
    batch.begin();
    batch.setColor(1f, 1f, 1f, 1f);

    // UI only (no text HUD): draw compact stat panel bottom-left.
    drawStatsPanel();

    // ============================================================
    // Area bounds warning UI (FUSA)
    // ============================================================
    if (AREA_MODE) {
      if (inRedZone) {
        font.setColor(1f, 0.2f, 0.2f, 1f);
        font.getData().setScale(1.0f * UI_FONT_SCALE);
        font.draw(batch, "Gebietsende, wechseln oder zurück gehen!", 20, Gdx.graphics.getHeight() - 80);
        font.setColor(0f, 0f, 0f, 1f);
      }
      // VOID removed: player cannot enter the black outside-of-area strip.

      // Direction arrows (only while in red zone; alpha: all sides are exits)
      if (inRedZone) {
        try {
          com.badlogic.gdx.math.Vector3 v = new com.badlogic.gdx.math.Vector3(px, py, 0f);
          cam.project(v);
          float sy = Math.max(24f, Math.min(Gdx.graphics.getHeight() - 24f, v.y));

          int tx = (int) Math.floor(px / World.TILE_WORLD);
          int ty = (int) Math.floor(py / World.TILE_WORLD);
          int w = com.yourgame.survival.tuning.TuningAreas.AREA_W_TILES;
          int h = com.yourgame.survival.tuning.TuningAreas.AREA_H_TILES;
          int rz = com.yourgame.survival.tuning.TuningAreas.RED_ZONE_TILES;

          boolean exitN = true, exitE = true, exitS = true, exitW = true;

          font.setColor(1f, 1f, 1f, 1f);
          font.getData().setScale(1.1f * UI_FONT_SCALE);

          if (exitW && tx < rz) font.draw(batch, "<", 10, sy);
          if (exitE && tx >= (w - rz)) font.draw(batch, ">", Gdx.graphics.getWidth() - 20, sy);
          if (exitS && ty < rz) font.draw(batch, "v", (Gdx.graphics.getWidth() * 0.5f), 28);
          if (exitN && ty >= (h - rz)) font.draw(batch, "^", (Gdx.graphics.getWidth() * 0.5f), Gdx.graphics.getHeight() - 28);

          font.setColor(0f, 0f, 0f, 1f);
        } catch (Throwable ignored) {}
      }
    }

    // ============================================================
    // WorldMap UI (Shift+M) (FUSA)
    // ============================================================
    if (mapOpen) {
      // Update transition
      if (mapTransActive) {
        mapTransT += Gdx.graphics.getDeltaTime() / 0.25f; // 250ms
        if (mapTransT >= 1f) {
          mapTransT = 1f;
          mapTransActive = false;
          mapViewMode = mapTransTo;
// Nicht fertiges Feature:           mapZoomOpen = (mapViewMode == 1);
        }
      }

      // Render either world overview or area map (with optional transition).
      float t = mapTransActive ? smooth01(mapTransT) : 1f;

      if (mapTransActive) {
        // Crossfade+zoom between two modes.
        if (mapTransFrom == 0 && mapTransTo == 1) {
          drawWorldMapOverview(1f - t, 1.0f + 0.30f * t);
          drawSelectedAreaMap(t, 0.85f + 0.15f * t);
        } else if (mapTransFrom == 1 && mapTransTo == 0) {
          drawSelectedAreaMap(1f - t, 1.0f + 0.30f * t);
          drawWorldMapOverview(t, 0.85f + 0.15f * t);
        }
      } else {
        if (mapViewMode == 0) {
          drawWorldMapOverview(1f, 1f);
        } else {
          drawSelectedAreaMap(1f, 1f);
        }
      }
    }

    // Toast stays (short, contextual).
    if (toastT > 0f) {
      font.setColor(0f, 0f, 0f, 1f);
      font.getData().setScale(1.0f * UI_FONT_SCALE);
      font.draw(batch, toast, 20, Gdx.graphics.getHeight() - 24);
      font.setColor(0f, 0f, 0f, 1f);
    }

    drawHotbarHud();

    if (buildMode) {
      drawBuildPanel();
    }

    if (invOpen) {
      drawInventoryGrid();
    }

    if (pricingOpen) {
      drawPricingMenu();
    }

    if (walletOpen) {
      drawWalletMenu();
    }

    if (shopOpen) {
      drawShopMenuAtMerchant();
    }
    if (craftOpen) {
      drawCraftPanel();
    }

    if (openChestE >= 0) {
      drawChestPanel();
    }

    // Top-most UI: drag ghost + buy popup
    drawDragGhostAndBuyPopup();

    // Debug overlay at cursor (IDs)
    debugOverlay.render(batch);

    // Skill menu overlay (P)
    if (skillsOpen) {
      if (!skillMenuRowsBuilt) buildSkillMenuRows();
      drawSkillMenu();
    }

    // Day/Night fullscreen overlay (over everything)
    if (dayNight1x1 != null) {
      // Base darkness (night stronger)
      float nightA = 1.00f; // deeper into black
      float gamma = 1.7f;   // stronger darkening curve
      float aBase = (float)Math.pow(1f - dnVisual, gamma) * nightA;
      if (aBase > 1f) aBase = 1f;

      // base night color (black-ish, but NOT more transparent)
      float r = 0.040f;
      float g = 0.040f;
      float b = 0.080f;

      // warm twilight tint (sunrise/sunset)
      float w = dnWarm;
      r = r + 0.35f * w;
      g = g + 0.12f * w;
      b = b - 0.10f * w;

      if (aBase > 0.001f) {
        batch.setColor(r, g, b, aBase);

        // If debug lamp is on, draw darkness with an alpha-mask (so area becomes truly brighter)
        if ((dnLightOn || dnLightXLOn) && dnMaskRegion != null && dnLampScreenValid) {
          batch.draw(dnMaskRegion, 0f, 0f, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        } else {
          batch.draw(dayNight1x1, 0f, 0f, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        }

        batch.setColor(1f, 1f, 1f, 1f);
      }
    }

    // Boot/preload overlay (covers the world until it fades out; shows a small progress bar)
    if (bootOverlayActive && dayNight1x1 != null) {
      Gdx.gl.glEnable(GL20.GL_BLEND);
      Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);

      // Fullscreen dark overlay
      batch.setColor(0f, 0f, 0f, bootOverlayA);
      batch.draw(dayNight1x1, 0f, 0f, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());

      // Progress bar (UI space, bottom-center)
      float w = 420f * UI_FONT_SCALE;
      float h = 18f * UI_FONT_SCALE;
      float x = (Gdx.graphics.getWidth() - w) * 0.5f;
      float y = 70f * UI_FONT_SCALE;

      // Track
      batch.setColor(0f, 0f, 0f, Math.min(1f, bootOverlayA + 0.25f));
      batch.draw(dayNight1x1, x - 3f, y - 3f, w + 6f, h + 6f);
      batch.setColor(1f, 1f, 1f, Math.min(1f, bootOverlayA));
      batch.draw(dayNight1x1, x, y, w, h);

      // Fill
      float fillW = w * bootOverlayFill;
      if (fillW > 0.5f) {
        batch.setColor(0.15f, 0.85f, 0.25f, Math.min(1f, bootOverlayA));
        batch.draw(dayNight1x1, x, y, fillW, h);
      }

      batch.setColor(1f, 1f, 1f, 1f);
      Gdx.gl.glDisable(GL20.GL_BLEND);
    }

    batch.end();
  }

  private void tickBootOverlay(float delta) {
    if (!bootOverlayActive) {
      bootOverlayControl = true;
      bootOverlayFill = 1f;
      bootOverlayA = 0f;
      return;
    }

    // Fill phase
    bootOverlayT += delta;
    float f = bootOverlayT / BOOT_OVERLAY_FILL_SEC;
    if (f < 0f) f = 0f;
    if (f > 1f) f = 1f;
    bootOverlayFill = f;

    // Fade-out phase after fully filled
    if (bootOverlayFill >= 0.999f) {
      bootOverlayFadeT += delta;
      float k = 1f - (bootOverlayFadeT / BOOT_OVERLAY_FADE_SEC);
      if (k < 0f) k = 0f;
      if (k > 1f) k = 1f;
      bootOverlayA = k;

      if (bootOverlayFadeT >= BOOT_OVERLAY_FADE_SEC || bootOverlayA <= 0.001f) {
        bootOverlayActive = false;
        bootOverlayControl = true;
        bootOverlayFill = 1f;
        bootOverlayA = 0f;
      }
    } else {
      bootOverlayA = 1f;
      bootOverlayControl = false;
      bootOverlayFadeT = 0f;
    }
  }

  private void updateDayNightMusic(float delta) {
    // Rules:
    // - Crossfade is ONLY allowed on the day<->night switch.
    // - The switch happens once when dnVisual crosses the midpoint (50%).

    // Midpoint side (>= 0.5 = day side)
    boolean sideDay = dnVisual >= DN_MIDPOINT;

    // Start a switch only when the side changes (once per cycle)
    if (sideDay != dnSideDay) {
      dnSideDay = sideDay;
      dnSwitching = true;
      dnSwitchT = 0f;
      dnSwitchToDay = sideDay;
    }

    float targetDay;
    float targetNight;

    if (dnSwitching) {
      dnSwitchT += delta;
      float a = dnSwitchT / DN_SWITCH_SEC;
      if (a < 0f) a = 0f;
      if (a > 1f) a = 1f;

      if (dnSwitchToDay) {
        // night -> day
        targetDay = a;
        targetNight = 1f - a;
      } else {
        // day -> night
        targetDay = 1f - a;
        targetNight = a;
      }

      if (a >= 1f) {
        dnSwitching = false;
      }
    } else {
      targetDay = sideDay ? 1f : 0f;
      targetNight = sideDay ? 0f : 1f;
    }

    // Ensure required tracks are playing.
    if (dnSwitching) {
      ensureDayBgPlaying();
      ensureNightBgPlaying();
    } else {
      if (targetDay > 0.5f) ensureDayBgPlaying();
      if (targetNight > 0.5f) ensureNightBgPlaying();
    }

    // Track fade-in (for playlist transitions; no cross-over between tracks)
    if (dayBgMusic != null) {
      dayTrackFadeInT += delta;
      if (dayTrackFadeInT > TRACK_FADE_IN_SEC) dayTrackFadeInT = TRACK_FADE_IN_SEC;
    }
    if (nightBgMusic != null) {
      nightTrackFadeInT += delta;
      if (nightTrackFadeInT > TRACK_FADE_IN_SEC) nightTrackFadeInT = TRACK_FADE_IN_SEC;
    }

    float inDay = dayTrackFadeInT / TRACK_FADE_IN_SEC;
    float inNight = nightTrackFadeInT / TRACK_FADE_IN_SEC;
    if (inDay < 0f) inDay = 0f;
    if (inDay > 1f) inDay = 1f;
    if (inNight < 0f) inNight = 0f;
    if (inNight > 1f) inNight = 1f;

    dayBgVol = targetDay;
    nightBgVol = targetNight;

    float base = game.settings.masterVolume * game.settings.musicVolume;
    if (base < 0f) base = 0f;
    if (base > 1f) base = 1f;

    if (dayBgMusic != null) {
      float v = dayBgVol * base * inDay;
      dayBgMusic.setVolume(v);
      if (!dnSwitching && dayBgVol <= 0.001f) {
        try { dayBgMusic.pause(); } catch (Throwable ignored) {}
      }
    }

    if (nightBgMusic != null) {
      float v = nightBgVol * base * inNight;
      nightBgMusic.setVolume(v);
      if (!dnSwitching && nightBgVol <= 0.001f) {
        try { nightBgMusic.pause(); } catch (Throwable ignored) {}
      }
    }
  }

  private void updateDnMask() {
    dnLampScreenValid = false;

    // Only build mask when lamp is on and it's not full day.
    if (!dnLightOn && !dnLightXLOn) return;
    float nightFactor = 1f - dnVisual;
    if (nightFactor <= 0.02f) return;

    if (dnMaskFbo == null || dnMaskRegion == null) {
      rebuildDnMaskFbo(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
      if (dnMaskFbo == null || dnMaskRegion == null) return;
    }

    // Compute lamp screen position (player + offset toward mouse)
    Vector3 sp = new Vector3(px, py, 0f);
    cam.project(sp);

    float dx = mouseWorldX - px;
    float dy = mouseWorldY - py;
    float len = (float)Math.sqrt(dx * dx + dy * dy);
    float ox = 0f, oy = 0f;
    if (len > 0.001f) {
      ox = (dx / len) * 30f;
      oy = (dy / len) * 30f;
    }

    dnLampScreenX = sp.x + ox;
    dnLampScreenY = sp.y + oy;
    dnLampScreenValid = true;

    // Render mask into FBO: start with alpha=1 everywhere, then reduce alpha around lamp.
    dnMaskFbo.begin();
    Gdx.gl.glClearColor(1f, 1f, 1f, 1f);
    Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

    if (dnLightTex != null) {
      batch.setProjectionMatrix(uiCam.combined);
      batch.begin();

      // Only affect ALPHA: RGB stays 1.0 so the texture doesn't tint the darkness color.
      batch.flush();
      batch.setBlendFunctionSeparate(GL20.GL_ZERO, GL20.GL_ONE, GL20.GL_ZERO, GL20.GL_ONE_MINUS_SRC_ALPHA);

      // Fixed tuned strength (alpha reduction) scaled by nightFactor.
      float strength = 0.2625f * nightFactor;
      if (strength < 0f) strength = 0f;
      if (strength > 1f) strength = 1f;

      if (dnLightOn) {
        float radiusPx = 300f;
        float size = radiusPx * 2f;
        batch.setColor(1f, 1f, 1f, strength);
        batch.draw(dnLightTex, dnLampScreenX - radiusPx, dnLampScreenY - radiusPx, size, size);
      }

      if (dnLightXLOn) {
        // Exact copy of lamp, but +300% size => 4x radius (300 -> 1200)
        float radiusPx = 1200f;
        float size = radiusPx * 2f;
        batch.setColor(1f, 1f, 1f, strength);
        batch.draw(dnLightTex, dnLampScreenX - radiusPx, dnLampScreenY - radiusPx, size, size);
      }

      batch.flush();
      batch.setBlendFunction(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
      batch.setColor(1f, 1f, 1f, 1f);

      batch.end();
    }

    dnMaskFbo.end();
  }

  private void rebuildDnMaskFbo(int w, int h) {
    try { if (dnMaskFbo != null) dnMaskFbo.dispose(); } catch (Throwable ignored) {}
    dnMaskFbo = null;
    dnMaskRegion = null;

    if (w <= 0 || h <= 0) return;

    try {
      dnMaskFbo = new FrameBuffer(Pixmap.Format.RGBA8888, w, h, false);
      Texture t = dnMaskFbo.getColorBufferTexture();
      dnMaskRegion = new TextureRegion(t);
      dnMaskRegion.flip(false, true); // FBO texture is Y-flipped
    } catch (Throwable ignored) {
      dnMaskFbo = null;
      dnMaskRegion = null;
    }
  }

  private void ensureDayBgPlaying() {
    if (dayBgTracks.length == 0) return;
    if (dayBgMusic == null) {
      playDayBg(true);
      return;
    }
    try {
      if (!dayBgMusic.isPlaying()) dayBgMusic.play();
    } catch (Throwable ignored) {}
  }

  private void ensureNightBgPlaying() {
    if (nightBgTracks.length == 0) return;
    if (nightBgMusic == null) {
      playNightBg(true);
      return;
    }
    try {
      if (!nightBgMusic.isPlaying()) nightBgMusic.play();
    } catch (Throwable ignored) {}
  }

  private void playDayBg(boolean fromStart) {
    if (dayBgTracks.length == 0) return;
    if (dayBgIdx < 0 || dayBgIdx >= dayBgTracks.length) dayBgIdx = 0;

    try { if (dayBgMusic != null) dayBgMusic.dispose(); } catch (Throwable ignored) {}
    dayBgMusic = null;

    String p = dayBgTracks[dayBgIdx];
    try {
      FileHandle fh = Gdx.files.absolute(p);
      dayBgMusic = Gdx.audio.newMusic(fh);
      dayBgMusic.setLooping(false);
      float base = game.settings.masterVolume * game.settings.musicVolume;
      if (base < 0f) base = 0f;
      if (base > 1f) base = 1f;
      dayTrackFadeInT = 0f;
      dayBgMusic.setVolume(0f * base);
      dayBgMusic.setOnCompletionListener(m -> {
        dayBgIdx = (dayBgIdx + 1) % dayBgTracks.length;
        playDayBg(true);
      });
      if (fromStart) dayBgMusic.setPosition(0f);
      dayBgMusic.play();
    } catch (Throwable ignored) {
      dayBgMusic = null;
    }
  }

  private void playNightBg(boolean fromStart) {
    if (nightBgTracks.length == 0) return;
    if (nightBgIdx < 0 || nightBgIdx >= nightBgTracks.length) nightBgIdx = 0;

    try { if (nightBgMusic != null) nightBgMusic.dispose(); } catch (Throwable ignored) {}
    nightBgMusic = null;

    String p = nightBgTracks[nightBgIdx];
    try {
      FileHandle fh = Gdx.files.absolute(p);
      nightBgMusic = Gdx.audio.newMusic(fh);
      nightBgMusic.setLooping(false);
      float base = game.settings.masterVolume * game.settings.musicVolume;
      if (base < 0f) base = 0f;
      if (base > 1f) base = 1f;
      nightTrackFadeInT = 0f;
      nightBgMusic.setVolume(0f * base);
      nightBgMusic.setOnCompletionListener(m -> {
        nightBgIdx = (nightBgIdx + 1) % nightBgTracks.length;
        playNightBg(true);
      });
      if (fromStart) nightBgMusic.setPosition(0f);
      nightBgMusic.play();
    } catch (Throwable ignored) {
      nightBgMusic = null;
    }
  }

  @SuppressWarnings("unused")
  private void collectInputSnapshot(float delta, InputState out) {
    // Block 8 scaffolding: a single place to sample inputs and (later) produce commands.
    // Keep it minimal for now (behavior stays as-is).

    // Nicht fertiges Feature: sampled input values are currently never read
    // out.delta = delta;
    // out.mx = Gdx.input.getX();
    // out.my = Gdx.input.getY();

    // Command queue is currently unused (gameplay still executes immediately), but we clear it
    // so it can be safely filled later without leaking old data.
    commandQueue.clear();
  }

  @SuppressWarnings("unused")
  private void applyCommands(com.yourgame.survival.sim.CommandQueue commands) {
    // Block 8 scaffolding: command queue exists for future deterministic simulation.
    // For now, gameplay is still executed immediately at input sites.
  }

  /** Base action radius (coupled for mouse constraint + interaction reach). Skill hook goes here. */
  private float actionReach(int equippedItemId) {
    // NOTE: keep values centralized so we can individualize tools/weapons later.

    float base = ACTION_RADIUS_DEFAULT;
    if (equippedItemId < 0) {
      // Unarmed: affected by CombatMelee range.
      int meleeLv = (SK_COMBAT_MELEE >= 0 && SK_COMBAT_MELEE < progress.skillLv.length) ? progress.skillLv[SK_COMBAT_MELEE] : 1;
      float mul = SkillEffects.mul5(meleeLv);
      return base * mul;
    }

    // For now: everything is clamped to the same ring radius, but per-item (not a global toggle).
    float r = switch (equippedItemId) {
      // Tools
      case 14, 15, 16, 17, 18, 19, 36 -> base;

      // Weapons
      case 20, 21, 22, 23, 24, 25, 26, 27 -> base;

      default -> base;
    };

    // Requested: CombatMelee increases action zone / reach especially for fist + knife.
    if (equippedItemId == 23) { // dagger as "messer"
      int meleeLv = (SK_COMBAT_MELEE >= 0 && SK_COMBAT_MELEE < progress.skillLv.length) ? progress.skillLv[SK_COMBAT_MELEE] : 1;
      float mul = SkillEffects.mul5(meleeLv);
      r *= mul;
    }

    return r;
  }

  /** Tools/weapons are only usable when they're on the hotbar AND you actually own at least 1 in inventory. */
  private int equippedFromHotbar() {
    if (hotbarSel < 0 || hotbarSel >= hotbar.length) return -1;
    int id = hotbar[hotbarSel];
    if (id < 0) return -1;
    if (!inv.isToolItem(id)) return -1;
    if (!inv.hasItem(id)) return -1;
    return id;
  }

  private static void facingVec(byte facingDir, Vector2 out) {
    switch (facingDir) {
      case 0 -> { out.x = 0f; out.y = 1f; }  // N
      case 1 -> { out.x = 1f; out.y = 0f; }  // E
      case 2 -> { out.x = 0f; out.y = -1f; } // S
      default -> { out.x = -1f; out.y = 0f; } // W
    }
  }

  private static boolean isInsideFov(float ox, float oy, float tx, float ty, float fwdX, float fwdY, float fovDeg) {
    float dx = tx - ox;
    float dy = ty - oy;
    float len2 = dx*dx + dy*dy;
    if (len2 <= 1e-6f) return true;

    float inv = (float)(1.0 / Math.sqrt(len2));
    float ax = dx * inv;
    float ay = dy * inv;

    float cosHalf = (float) Math.cos(Math.toRadians(fovDeg * 0.5));
    return (fwdX * ax + fwdY * ay) >= cosHalf;
  }

  private static final int REMOVED_KIND_MINED_ROCK_TILE = 255;

  /** Pickaxe-only: mine a ROCK ground tile into GRASS and drop 1x Stone. */
  private boolean tryMineRockTile(float aimWx, float aimWy, float range, int toolItemId) {
    if (toolItemId != 15) return false; // Pickaxe only
    if (world == null) return false;

    // Must be in reach.
    float dx = aimWx - px;
    float dy = aimWy - py;
    if (dx * dx + dy * dy > range * range) return false;

    // Tile coords
    int tx = (int) Math.floor(aimWx / World.TILE_WORLD);
    int ty = (int) Math.floor(aimWy / World.TILE_WORLD);

    // Areas-only mode uses non-negative tiles; keep it safe anyway.
    if (tx < 0 || ty < 0) return false;

    int cx = tx / World.CHUNK_SIZE;
    int cy = ty / World.CHUNK_SIZE;

    // Do NOT generate chunks while mining.
    com.yourgame.survival.world.Chunk c = world.peekChunk(cx, cy);
    if (c == null || c.layers == null) return false;

    int lx = tx - cx * World.CHUNK_SIZE;
    int ly = ty - cy * World.CHUNK_SIZE;
    if (lx < 0 || ly < 0 || lx >= World.CHUNK_SIZE || ly >= World.CHUNK_SIZE) return false;
    int idx = lx + ly * World.CHUNK_SIZE;

    if (c.layers.groundId[idx] != TileIds.GROUND_ROCK) return false;

    // Mine it: rock -> grass, remove collision.
    c.layers.groundId[idx] = TileIds.GROUND_GRASS;
    c.layers.collisionMask[idx] = 0;

    // Persist: remember this tile was mined (saved via SaveManager's removedNodes).
    worldNodes.removed.add(com.yourgame.survival.world.WorldNodes.keyRaw(REMOVED_KIND_MINED_ROCK_TILE, tx, ty));

    // 1 stone per tile.
    float dropX = (tx + 0.5f) * World.TILE_WORLD;
    float dropY = (ty + 0.5f) * World.TILE_WORLD;
    entities.spawnDrop(1, 1, dropX, dropY); // itemId 1 = Stone
    game.audio.sfx("audio/sfx/pickup.wav", game.audio.sfxVolume(game.settings));
    return true;
  }

  /** Re-apply mined rock tiles after loading a save (world was rebuilt). */
  private void applyMinedRockTilesFromSave() {
    try {
      if (world == null || worldNodes == null || worldNodes.removed == null) return;
      com.badlogic.gdx.utils.LongArray ks = worldNodes.removed.keys();
      if (ks == null) return;

      for (int i = 0; i < ks.size; i++) {
        long k = ks.get(i);
        if (com.yourgame.survival.world.WorldNodes.rawTypeId(k) != REMOVED_KIND_MINED_ROCK_TILE) continue;
        int tx = com.yourgame.survival.world.WorldNodes.rawTx(k);
        int ty = com.yourgame.survival.world.WorldNodes.rawTy(k);
        if (tx < 0 || ty < 0) continue;

        int cx = tx / World.CHUNK_SIZE;
        int cy = ty / World.CHUNK_SIZE;
        com.yourgame.survival.world.Chunk c = world.chunk(cx, cy); // OK to create on load/apply
        int lx = tx - cx * World.CHUNK_SIZE;
        int ly = ty - cy * World.CHUNK_SIZE;
        if (lx < 0 || ly < 0 || lx >= World.CHUNK_SIZE || ly >= World.CHUNK_SIZE) continue;
        int idx = lx + ly * World.CHUNK_SIZE;
        if (c.layers == null) continue;

        c.layers.groundId[idx] = TileIds.GROUND_GRASS;
        c.layers.collisionMask[idx] = 0;
      }
    } catch (Throwable ignored) {}
  }

  /** Updates mouseWorldX/Y and optionally clamps the OS cursor to the action ring (player-centered). */
  private void updateMouseWorld(boolean clampToRing) {
    Vector3 v = scratch.v3a;
    v.set(Gdx.input.getX(), Gdx.input.getY(), 0f);
    cam.unproject(v);

    float wx = v.x;
    float wy = v.y;

    if (clampToRing) {
      float r = actionReach(equippedFromHotbar());
      float dx = wx - px;
      float dy = wy - py;
      float d2 = dx*dx + dy*dy;
      float r2 = r * r;
      if (d2 > r2 && d2 > 1e-6f) {
        float invLen = (float)(1.0 / Math.sqrt(d2));
        wx = px + dx * invLen * r;
        wy = py + dy * invLen * r;

        // Warp cursor back onto the ring so the player can never "aim" outside.
        Vector3 p = scratch.v3b;
        p.set(wx, wy, 0f);
        cam.project(p);
        int sx = (int)p.x;
        int sy = (int)(Gdx.graphics.getHeight() - p.y);
        Gdx.input.setCursorPosition(sx, sy);
      }
    }

    mouseWorldX = wx;
    mouseWorldY = wy;
  }
  void drawEntityHealthBarsWorld() {
    // Draw simple health bars + numeric hp over each entity.
    shape.setProjectionMatrix(cam.combined);

    Gdx.gl.glEnable(GL20.GL_BLEND);
    Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);

    // 1) bars (filled)
    shape.begin(ShapeRenderer.ShapeType.Filled);

    // Tile-tree harvest HP bar (AREA_MODE)
    try {
      if (AREA_MODE && tileTreeHitUiT > 0f && tileTreeHitHp > 0f && tileTreeHitTx >= 0 && tileTreeHitTy >= 0) {
        float hpMax = 20f;
        float p = MathUtils.clamp(tileTreeHitHp / hpMax, 0f, 1f);

        float x = (tileTreeHitTx + 0.5f) * World.TILE_WORLD;
        float y = (tileTreeHitTy * World.TILE_WORLD) + 34.0f;
        float w = com.yourgame.survival.entity.EntityMetrics.drawW(EntityType.NODE_TREE);
        float h = com.yourgame.survival.entity.EntityMetrics.drawH(EntityType.NODE_TREE);

        float barW = Math.max(10f, w * 0.85f);
        float barH = 3f;
        float bx = x - barW * 0.5f;
        float by = y + h * 0.5f + 6f;

        shape.setColor(0f, 0f, 0f, 0.65f);
        shape.rect(bx - 1f, by - 1f, barW + 2f, barH + 2f);

        float rr = (1f - p);
        float gg = p;
        shape.setColor(rr, gg, 0.1f, 0.90f);
        shape.rect(bx, by, barW * p, barH);
      }
    } catch (Throwable ignored) {}

    for (int e = 0; e < Entities.MAX; e++) {
      if (!entities.alive[e]) continue;
      float hpMax = entities.hpMax[e];
      if (hpMax <= 0f) continue;

      // Only moving entities should show health bars (player always shows).
      // Exception: show bars for damaged orcs/deer even when idle (so combat feedback is reliable).
      EntityType t0 = entities.type[e];
      if (t0 != EntityType.PLAYER) {
        float mv2 = entities.vx[e] * entities.vx[e] + entities.vy[e] * entities.vy[e];
        boolean damaged = entities.hp[e] < entities.hpMax[e] - 0.01f;
        boolean important = (t0 == EntityType.ORK_GRUNT || t0 == EntityType.ANIMAL_DEER);
        if (!damaged && !important) {
          if (mv2 <= (5f * 5f)) continue;
        }
      }

      float hp = Math.max(0f, entities.hp[e]);
      float p = MathUtils.clamp(hp / hpMax, 0f, 1f);

      EntityType t = entities.type[e];
      float w = com.yourgame.survival.entity.EntityMetrics.drawW(t);
      float h = com.yourgame.survival.entity.EntityMetrics.drawH(t);

      float x = entities.x[e];
      float y = entities.y[e];

      // Only show bars when reasonably near the camera/player to reduce clutter.
      if (Math.abs(x - px) > 700f || Math.abs(y - py) > 520f) continue;

      float barW = Math.max(10f, w * 0.85f * 1.15f); // +15% wider
      float barH = (t == EntityType.ANIMAL_DEER) ? 2f : 3f; // deer: extra slim
      float bx = x - barW * 0.5f;
      float by = y + h * 0.5f + 6f;

      // background
      shape.setColor(0f, 0f, 0f, 0.65f);
      shape.rect(bx - 1f, by - 1f, barW + 2f, barH + 2f);

      // fill (green->red)
      float r = (1f - p);
      float g = p;
      shape.setColor(r, g, 0.1f, 0.90f);
      shape.rect(bx, by, barW * p, barH);
    }
    shape.end();

    // 2) numeric hp text (disabled: bars only)
    // Intentionally not drawing numbers to reduce clutter.

    Gdx.gl.glDisable(GL20.GL_BLEND);
  }

  private boolean fireBowArrow(
      float ox, float oy,
      float aimX, float aimY,
      float fwdX, float fwdY,
      float fovDeg,
      float speed,
      float maxRange,
      float dmg,
      float spreadRad
  ) {
    // Aim dir
    float dx = aimX - ox;
    float dy = aimY - oy;
    float len2 = dx * dx + dy * dy;
    if (len2 <= 1e-6f) return false;

    float invLen = (float) (1.0 / Math.sqrt(len2));
    float ax = dx * invLen;
    float ay = dy * invLen;

    // FOV check against facing
    float cosHalf = (float) Math.cos(Math.toRadians(fovDeg * 0.5));
    if (fwdX * ax + fwdY * ay < cosHalf) return false;

    // Spread (precision): rotate by random angle in [-spreadRad, +spreadRad]
    if (spreadRad > 1e-6f) {
      float ang = (MathUtils.random() * 2f - 1f) * spreadRad;
      float c = (float) Math.cos(ang);
      float s = (float) Math.sin(ang);
      float rx = ax * c - ay * s;
      float ry = ax * s + ay * c;
      ax = rx;
      ay = ry;
    }

    // Find free arrow slot
    int slot = -1;
    for (int i = 0; i < ARROW_MAX; i++) {
      if (!arrowAlive[i]) { slot = i; break; }
    }
    if (slot < 0) return true; // silently drop (no alloc)

    arrowAlive[slot] = true;
    arrowX[slot] = ox;
    arrowY[slot] = oy;
    arrowVx[slot] = ax * speed;
    arrowVy[slot] = ay * speed;
    arrowTravel[slot] = 0f;
    arrowRange[slot] = maxRange;
    arrowDmg[slot] = dmg;
    return true;
  }

  private void tickArrows(float dt) {
    // Sub-step to avoid tunneling at high arrow speed.
    final float maxStep = 14f;

    for (int i = 0; i < ARROW_MAX; i++) {
      if (!arrowAlive[i]) continue;

      float x = arrowX[i];
      float y = arrowY[i];

      float vx = arrowVx[i];
      float vy = arrowVy[i];
      float spd = (float) Math.sqrt(vx * vx + vy * vy);
      if (spd <= 1e-6f) { arrowAlive[i] = false; continue; }

      float total = spd * dt;
      int steps = Math.max(1, (int) Math.ceil(total / maxStep));
      float sdt = dt / steps;

      for (int s = 0; s < steps; s++) {
        float x2 = x + vx * sdt;
        float y2 = y + vy * sdt;

        arrowLastKill = null;
        int hitE = arrowHitSegment(x, y, x2, y2, arrowDmg[i]);
        if (hitE >= 0) {
          // Arrow disappears on ANY hit (even if target survives)
          arrowAlive[i] = false;
          game.audio.sfx("audio/sfx/ork_hit.wav", game.audio.sfxVolume(game.settings));
          if (arrowLastKill != null) {
            onKill(arrowLastKill);
          }
          break;
        }

        // advance
        arrowTravel[i] += spd * sdt;
        if (arrowTravel[i] >= arrowRange[i]) {
          arrowAlive[i] = false;
          break;
        }

        x = x2;
        y = y2;
      }

      if (!arrowAlive[i]) continue;
      arrowX[i] = x;
      arrowY[i] = y;
    }
  }

  private CombatSystem.Kill arrowLastKill = null;

  /**
   * @return hit entity index, or -1 if no hit. If a kill happens, arrowLastKill is set.
   */
  private int arrowHitSegment(float x0, float y0, float x1, float y1, float dmg) {
    // Visual-only arrows use dmg=0; they must never collide with local mobs.
    if (dmg <= 0f) return -1;
    // segment direction + length
    float dx = x1 - x0;
    float dy = y1 - y0;
    float len2 = dx * dx + dy * dy;
    if (len2 <= 1e-6f) return -1;

    float invLen = (float) (1.0 / Math.sqrt(len2));
    float ax = dx * invLen;
    float ay = dy * invLen;
    float segLen = (float) Math.sqrt(len2);

    int best = -1;
    float bestT = Float.POSITIVE_INFINITY;

    for (int e = 0; e < Entities.MAX; e++) {
      if (!entities.alive[e]) continue;
      EntityType t = entities.type[e];
      if (t != EntityType.ORK_GRUNT && t != EntityType.ANIMAL_DEER) continue;

      float cx = entities.x[e] - x0;
      float cy = entities.y[e] - y0;

      float proj = cx * ax + cy * ay;
      if (proj < 0f || proj > segLen) continue;

      float closest2 = cx * cx + cy * cy - proj * proj;
      // Effective hit radius = target body hit radius + projectile thickness.
      float r = com.yourgame.survival.entity.EntityMetrics.hitRadius(t) + ARROW_HIT_RADIUS;
      if (closest2 > r * r) continue;

      if (proj < bestT) { bestT = proj; best = e; }
    }

    if (best < 0) return -1;

    EntityType t = entities.type[best];
    entities.hp[best] -= dmg;
    if (entities.hp[best] <= 0f) {
      float ex = entities.x[best];
      float ey = entities.y[best];
      entities.kill(best);
      arrowLastKill = new CombatSystem.Kill(t, ex, ey);
    }

    return best;
  }
  void drawArrowsWorld() {
    // Minimal world-space arrow visualization (line). No ammo system.
    shape.setProjectionMatrix(cam.combined);
    Gdx.gl.glEnable(GL20.GL_BLEND);
    Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);

    // Initial (small) projectile visualization
    float tail = 10f;

    shape.begin(ShapeRenderer.ShapeType.Line);
    shape.setColor(0.95f, 0.95f, 0.95f, 0.95f);
    for (int i = 0; i < ARROW_MAX; i++) {
      if (!arrowAlive[i]) continue;
      float x = arrowX[i];
      float y = arrowY[i];
      float vx = arrowVx[i];
      float vy = arrowVy[i];
      float invLen = 1.0f / Math.max(1e-6f, (float) Math.sqrt(vx * vx + vy * vy));
      float nx = vx * invLen;
      float ny = vy * invLen;
      shape.line(x, y, x - nx * tail, y - ny * tail);
    }
    shape.end();

    Gdx.gl.glDisable(GL20.GL_BLEND);
  }

  private void drawActionOverlay(float fwdX, float fwdY) {
    float r = actionReach(equippedFromHotbar());

    float baseAng = (float)Math.atan2(fwdY, fwdX);

    float half = (float)Math.toRadians(ACTION_FOV_DEG * 0.5f);
    float a0 = baseAng - half;
    float a1 = baseAng + half;

    // Filled FOV sector (blue, half-transparent)
    Gdx.gl.glEnable(GL20.GL_BLEND);
    Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);

    shape.setProjectionMatrix(cam.combined);
    shape.begin(ShapeRenderer.ShapeType.Filled);
    shape.setColor(new Color(0.10f, 0.55f, 1.0f, 0.35f));

    int seg = 28; // smooth enough
    float da = (a1 - a0) / seg;
    for (int i=0;i<seg;i++) {
      float aa0 = a0 + da * i;
      float aa1 = a0 + da * (i+1);
      float x0 = px + (float)Math.cos(aa0) * r;
      float y0 = py + (float)Math.sin(aa0) * r;
      float x1 = px + (float)Math.cos(aa1) * r;
      float y1 = py + (float)Math.sin(aa1) * r;
      shape.triangle(px, py, x0, y0, x1, y1);
    }
    shape.end();

    // Action ring outline (red)
    shape.begin(ShapeRenderer.ShapeType.Line);
    shape.setColor(new Color(1f, 0.15f, 0.15f, 0.95f));
    shape.circle(px, py, r, 64);
    shape.end();

    Gdx.gl.glDisable(GL20.GL_BLEND);
  }
  void drawDotCursorWorld(float x, float y) {
    // White point cursor (visible, not tiny)
    shape.setProjectionMatrix(cam.combined);

    Gdx.gl.glEnable(GL20.GL_BLEND);
    Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);

    float rOuter = 4.0f;
    float rInner = 2.6f;

    // outline
    shape.begin(ShapeRenderer.ShapeType.Filled);
    shape.setColor(0f, 0f, 0f, 0.85f);
    shape.circle(x, y, rOuter, 18);
    shape.setColor(1f, 1f, 1f, 0.95f);
    shape.circle(x, y, rInner, 18);
    shape.end();

    Gdx.gl.glDisable(GL20.GL_BLEND);
  }

  /* ===== SIMULATION TICK ===== */
  private void tick(float dt) {
    // toast
    if (toastT > 0f) toastT -= dt;

    runtimeSec += dt;

    if (tileTreeHitUiT > 0f) tileTreeHitUiT = Math.max(0f, tileTreeHitUiT - dt);

    // Debug: tile-tree streaming (F10)
    // NOTE: This MUST live in tick(), because the boot overlay can block input handling in render().
    if (Gdx.input.isKeyJustPressed(Input.Keys.F10)) {
      dbgTileTrees = !dbgTileTrees;
      toast = "DBG TileTrees=" + (dbgTileTrees ? "ON" : "OFF") + " (F10)";
      toastT = 2.5f;
      dbgTileTreesToastCooldown = 0f;
    }

    // Streaming warmup: defer heavy chunk generation for a few frames right after entering gameplay.
    if (streamWarmupFrames > 0) streamWarmupFrames--;
    final int streamR = AREA_MODE ? 0 : ((streamWarmupFrames > 0) ? 0 : streamRadiusChunks);

    // Player hand swing FX timer (purely visual; rendered by EntityRenderer).
    if (playerE >= 0) {
      // Reuse aiF0[] for PLAYER as "swing remaining seconds".
      entities.aiF0[playerE] = Math.max(0f, entities.aiF0[playerE] - dt);
    }

    // Day/Night + needs
    dayNight.tick(dt);

    // Skill-based needs modifiers (cheap: just a few multipliers)
    int healthLv = (SK_HEALTH >= 0 && SK_HEALTH < progress.skillLv.length) ? progress.skillLv[SK_HEALTH] : 1;
    int staminaLv = (SK_STAMINA >= 0 && SK_STAMINA < progress.skillLv.length) ? progress.skillLv[SK_STAMINA] : 1;
    int hungerCtrlLv = (SK_HUNGER_CTRL >= 0 && SK_HUNGER_CTRL < progress.skillLv.length) ? progress.skillLv[SK_HUNGER_CTRL] : 1;
    int sleepCtrlLv = (SK_SLEEP_CTRL >= 0 && SK_SLEEP_CTRL < progress.skillLv.length) ? progress.skillLv[SK_SLEEP_CTRL] : 1;

    // Align core baselines with current feel, but keep skill effects consistent.
    final float HP_BASE = 500f;
    final float STAM_BASE = 100f;
    final float HUNGER_BASE = 200f;

    needs.hpMax = HP_BASE * SkillEffects.mul5(healthLv);
    needs.staminaMax = STAM_BASE * SkillEffects.mul5(staminaLv);
    needs.hungerMax = HUNGER_BASE;

    // New game: once per fresh start, snap to full needs after max values are defined.
    // Requirement: must start at 100% hunger when starting a new game.
    if (forceFullHpOnce) {
      needs.hp = needs.hpMax;
      needs.stamina = needs.staminaMax;
      needs.mana = needs.manaMax;
      needs.hunger = needs.hungerMax;
      needs.sleep = needs.sleepMax;
      forceFullHpOnce = false;
    }

    // Drains remain skill-modified (Singleplayer progression keeps working).
    needs.hungerDrainMul = SkillEffects.drainMul5(hungerCtrlLv, 0.10f);
    needs.sleepDrainMul = SkillEffects.drainMul5(sleepCtrlLv, 0.10f);

    if (needs.hp > needs.hpMax) needs.hp = needs.hpMax;
    if (needs.stamina > needs.staminaMax) needs.stamina = needs.staminaMax;

    needs.tick(dt);

    // Apply smooth food effects AFTER drains for this tick.
    if (pendingFoodHunger > 0f || pendingFoodHp > 0f) {
      final float HUNGER_FILL_PER_SEC = 38f; // 50 hunger in ~1.3s
      final float HP_FILL_PER_SEC = 28f;     // 25 hp in <1s

      // 1) Hunger first
      if (pendingFoodHunger > 0f && needs.hunger < needs.hungerMax - 1e-3f) {
        float want = Math.min(pendingFoodHunger, HUNGER_FILL_PER_SEC * dt);
        float space = (needs.hungerMax - needs.hunger);
        float give = Math.min(want, space);
        needs.hunger += give;
        pendingFoodHunger -= give;
      }

      // If hunger is full, discard any remaining hunger gain (can't apply) and allow HP heal.
      if (needs.hunger >= needs.hungerMax - 1e-3f) {
        pendingFoodHunger = 0f;
      }

      // 2) HP only after hunger is full
      if (pendingFoodHp > 0f && needs.hunger >= needs.hungerMax - 1e-3f && needs.hp < needs.hpMax - 1e-3f) {
        float want = Math.min(pendingFoodHp, HP_FILL_PER_SEC * dt);
        float space = (needs.hpMax - needs.hp);
        float give = Math.min(want, space);
        needs.hp += give;
        pendingFoodHp -= give;
      }

      if (pendingFoodHunger < 0f) pendingFoodHunger = 0f;
      if (pendingFoodHp < 0f) pendingFoodHp = 0f;
    }

    // Respawn on death: always return to full HP + full hunger.
    // Requirement: must respawn at 100% hunger.
    if (needs.hp <= 0f) {
      needs.hp = needs.hpMax;
      needs.hunger = needs.hungerMax;
      toast = "Respawn";
      toastT = 1.6f;
    }

    // new day rollover => refresh wandering shop offers
    if (dayNight.t < prevDayT) {
      dayIndex++;
      regenShopOffers();
    }
    prevDayT = dayNight.t;

    // Biome damage (Cold/Heat) + mitigation (MUST NOT generate chunks)
    //
    // Requirement (FUSA Areas-only mode): biomes must not drive gameplay by default.
    if (!AREA_MODE) {
      int hereBiomeId = world.biomeIdAtWorldPeek(px, py, Biome.GRASSLAND.id & 0xff);
      Biome hb = Biome.byId(hereBiomeId);

      float coldDps = (hb == Biome.SNOWHIGHLAND) ? 0.35f : (hb == Biome.MOUNTAIN ? 0.15f : 0f);
      float heatDps = (hb == Biome.VOLCANIC) ? 0.30f : (hb == Biome.ASHFIELD ? 0.12f : 0f);

      if (coldDps > 0f) {
        int coldLv = (SK_COLD_RES >= 0 && SK_COLD_RES < progress.skillLv.length) ? progress.skillLv[SK_COLD_RES] : 1;
        float mul = SkillEffects.drainMul5(coldLv, 0.15f);
        needs.hp -= coldDps * dt * mul;
      }
      if (heatDps > 0f) {
        int heatLv = (SK_HEAT_RES >= 0 && SK_HEAT_RES < progress.skillLv.length) ? progress.skillLv[SK_HEAT_RES] : 1;
        float mul = SkillEffects.drainMul5(heatLv, 0.15f);
        needs.hp -= heatDps * dt * mul;
      }
      if (needs.hp < 0f) needs.hp = 0f;
    }

    float ix = 0f;
    float iy = 0f;

    // Player movement (always allowed)
    if (Gdx.input.isKeyPressed(Input.Keys.W)) iy += 1f;
    if (Gdx.input.isKeyPressed(Input.Keys.S)) iy -= 1f;
    if (Gdx.input.isKeyPressed(Input.Keys.A)) ix -= 1f;
    if (Gdx.input.isKeyPressed(Input.Keys.D)) ix += 1f;

    // Diagonal movement: reduce only lateral (X) component for better control feel.
    if (ix != 0f && iy != 0f) ix *= 0.70f;

    // Movement speed tuning:
    // Old values (Base 200 +60/level) were way too fast and felt like "perma sprint".
    // Baseline movement speed (Navigation).
    // Requested: normal walk speed at skill level 1 should be 60.
    int speedLv = (SK_SPEED >= 0 && SK_SPEED < progress.skillLv.length) ? progress.skillLv[SK_SPEED] : 1;
    float baseSpeed = 60f + 12f * Math.max(0, speedLv - 1);

    // Sneak: hard override to 30 (toggle V)
    if (sneaking) {
      baseSpeed = 30f;
    }

    float speed = baseSpeed;

    // Sprint: +5% over base. Additional +3% per level of the sprint-related skill (we use Stamina).
    boolean sprintKey = (Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT) || Gdx.input.isKeyPressed(Input.Keys.SHIFT_RIGHT));
    boolean moving = (ix != 0f || iy != 0f);
    boolean sprinting = (!sneaking && sprintKey && moving && needs.stamina > 0f);
    if (sprinting) {
      int sprintLv = (SK_SPRINTING >= 0 && SK_SPRINTING < progress.skillLv.length) ? progress.skillLv[SK_SPRINTING] : 1;
      float sprintBonus = 0.05f + 0.03f * Math.max(0, sprintLv - 1);
      speed *= (1f + sprintBonus);
      needs.stamina = Math.max(0f, needs.stamina - 8.0f * dt);
    }

    // NOTE: traversal skills (Climbing/Boating) currently gate access, not movement speed.

    // Local movement + collision.
    // Smooth accel/brake (both sides): blend current velocity toward desired.
    float desiredVx = ix * speed;
    float desiredVy = iy * speed;
    float accel = 15.0f;
    float a = MathUtils.clamp(accel * dt, 0f, 1f);
    playerVx = MathUtils.lerp(playerVx, desiredVx, a);
    playerVy = MathUtils.lerp(playerVy, desiredVy, a);

    float nx = px + playerVx * dt;
    float ny = py + playerVy * dt;

    // Story world (Areas-only): player must NOT leave the Area bounds.
    // (No walking into the black VOID strip.)

    // Collision constraints (MUST NOT generate chunks).
    //
    // Areas-only requirement:
    // - No background generation.
    // - Player movement is clamped to the Area bounds (no VOID walking).
    //
    // We use *peek* queries with safe defaults.
    boolean coll;

    // Areas-only: use *peek* queries.
    // Outside loaded chunks => defaults are NOT blocking.
    coll = world.isBlockedAtWorldPeek(nx, ny, false);

    // DEBUG: optionally treat roadMask as blocking to visualize (in movement) where roads exist.
    if (!coll && debugRoadBlocksMovement) {
      int tx = (int) Math.floor(nx / World.TILE_WORLD);
      int ty = (int) Math.floor(ny / World.TILE_WORLD);
      com.yourgame.survival.world.Chunk c = world.peekChunk(tx / World.CHUNK_SIZE, ty / World.CHUNK_SIZE);
      if (c != null && c.layers != null) {
        int lx = tx - (tx / World.CHUNK_SIZE) * World.CHUNK_SIZE;
        int ly = ty - (ty / World.CHUNK_SIZE) * World.CHUNK_SIZE;
        if (lx >= 0 && ly >= 0 && lx < World.CHUNK_SIZE && ly < World.CHUNK_SIZE) {
          int idx = lx + ly * World.CHUNK_SIZE;
          if (c.layers.roadMask[idx] != 0) coll = true;
        }
      }
    }

    boolean blocked = false;
    if (coll) blocked = true;

    // Story world (Areas-only): hard block stepping outside the Area.
    if (AREA_MODE) {
      float tw = World.TILE_WORLD;
      float areaW = com.yourgame.survival.tuning.TuningAreas.AREA_W_TILES * tw;
      float areaH = com.yourgame.survival.tuning.TuningAreas.AREA_H_TILES * tw;
      boolean outside = (nx < 0f || ny < 0f || nx >= areaW || ny >= areaH);
      if (outside) blocked = true;
    }
    // Procedural biome constraints removed (Areas-only mode).

    if (!blocked) {
      px = nx;
      py = ny;
      // keep entity player position + motion hint synced
      if (playerE >= 0) {
        entities.x[playerE] = px;
        entities.y[playerE] = py;
        entities.vx[playerE] = playerVx;
        entities.vy[playerE] = playerVy;
        // Facing is controlled by mouse/FOV aim (not by movement direction).
      }
    } else {
      // blocked: brake quickly
      playerVx = MathUtils.lerp(playerVx, 0f, a);
      playerVy = MathUtils.lerp(playerVy, 0f, a);
      if (playerE >= 0) {
        entities.vx[playerE] = playerVx;
        entities.vy[playerE] = playerVy;
      }
    }

    int ccx = (int) Math.floor((px / World.TILE_WORLD) / World.CHUNK_SIZE);
    int ccy = (int) Math.floor((py / World.TILE_WORLD) / World.CHUNK_SIZE);

    // In story-world (area) we still want ALL entities in the visible screen area rendered,
    // so we use a view-based radius here.
    int viewR = streamR;
    if (AREA_MODE) {
      float chunkWorld = World.TILE_WORLD * World.CHUNK_SIZE;
      float halfW = (cam.viewportWidth * cam.zoom) * 0.5f;
      float halfH = (cam.viewportHeight * cam.zoom) * 0.5f;
      // Keep in sync with renderWorld() chunk draw radius (+margin), plus one extra chunk
      // so tile-tree streaming doesn't lag behind camera motion.
      int rx = (int) Math.ceil(halfW / chunkWorld) + 2;
      int ry = (int) Math.ceil(halfH / chunkWorld) + 2;
      viewR = Math.max(rx, ry) + 1;
    }

    loadedMinCx = ccx - viewR;
    loadedMaxCx = ccx + viewR;
    loadedMinCy = ccy - viewR;
    loadedMaxCy = ccy + viewR;

    // (Entity pool guardrails: tree entities are no longer spawned; drops are capped elsewhere if needed.)

    // ============================================================
    // Area bounds logic: red zone + void timer + penalties
    // ============================================================
    if (AREA_MODE) {
      int tx = (int) Math.floor(px / World.TILE_WORLD);
      int ty = (int) Math.floor(py / World.TILE_WORLD);

      // Areas-only: player can never step into VOID.
// Nicht fertiges Feature:       inVoid = false;
// Nicht fertiges Feature:       voidTimer = 0f;
// Nicht fertiges Feature:       voidStage = 0;

      // Red zone warning: within N tiles of any area edge.
      int w = com.yourgame.survival.tuning.TuningAreas.AREA_W_TILES;
      int h = com.yourgame.survival.tuning.TuningAreas.AREA_H_TILES;
      int rz = com.yourgame.survival.tuning.TuningAreas.RED_ZONE_TILES;
      int distL = tx;
      int distR = (w - 1) - tx;
      int distB = ty;
      int distT = (h - 1) - ty;
      int minD = Math.min(Math.min(distL, distR), Math.min(distB, distT));
      inRedZone = (minD >= 0) && (minD < rz);

      // Fog of War: persistently reveal explored area while playing.
      areaFogRevealTick(dt);
    } else {
// Nicht fertiges Feature:       inVoid = false;
      inRedZone = false;
// Nicht fertiges Feature:       voidTimer = 0f;
// Nicht fertiges Feature:       voidStage = 0;
    }

    // Areas-only: no background chunk streaming here.

    // AI updates (slightly stronger at night)
    int stealthLv = (SK_STEALTH >= 0 && SK_STEALTH < progress.skillLv.length) ? progress.skillLv[SK_STEALTH] : 1;
    float stealthMul = SkillEffects.drainMul5(stealthLv, 0.25f);

    int intLv = (SK_INTIMIDATION >= 0 && SK_INTIMIDATION < progress.skillLv.length) ? progress.skillLv[SK_INTIMIDATION] : 1;
    float intimidateChance = Math.min(0.90f, 0.05f * Math.max(0, intLv - 1));

    ai.tick(entities, playerE, world, loadedMinCx, loadedMaxCx, loadedMinCy, loadedMaxCy, dt, stealthMul, intimidateChance, sneaking, moving, sprinting);

    // Prevent player/orc/animal overlap (simple separation)
    entityCollision.resolve(entities, loadedMinCx, loadedMaxCx, loadedMinCy, loadedMaxCy);

    // Tile-tree trunk collision (AREA_MODE): prevent entities from sliding into the trunk while allowing
    // walking "under" the canopy. (Stumps are excluded.)
    if (AREA_MODE) {
      resolveTileTreeTrunksInLoadedWindow();
    }
    if (playerE >= 0) {
      px = entities.x[playerE];
      py = entities.y[playerE];
    }

    // Auto-close merchant popup when leaving the action radius.
    if (shopOpen && openMerchantE >= 0 && openMerchantE < Entities.MAX && entities.alive[openMerchantE]
        && (entities.type[openMerchantE] == EntityType.MERCHANT_ELF || entities.type[openMerchantE] == EntityType.MERCHANT_WANDERING)) {
      float eff = actionReach(equippedFromHotbar()) + com.yourgame.survival.entity.EntityMetrics.radius(entities.type[openMerchantE]);
      float dx = entities.x[openMerchantE] - px;
      float dy = entities.y[openMerchantE] - py;
      if (dx * dx + dy * dy > eff * eff) {
        shopOpen = false;
        openMerchantE = -1;
        buyPopup = false;
        buyBuffer = "";
        dragArmed = false;
        dragActive = false;
      }
    }

    // Areas-only: no background procedural node spawning.

    // Areas-only: merchant simulation/spawn removed from this tick path.
    // TODO (story): if merchants exist in area JSON later, tick them here explicitly.

    // Bow cooldown + arrows
    if (bowCooldownT > 0f) bowCooldownT = Math.max(0f, bowCooldownT - dt);
    tickArrows(dt);

    // Areas-only: procedural encounter respawn removed.
    // TODO (story): spawn encounters via area templates or scripted events.

    // Authored enemy zones (FUSA Story)
    areaEnemyZonesTick(dt);

    // Authored tile-tree streaming (FUSA Story)
    areaTileTreesTick(dt);
  }

  private static int clampInt(int v, int lo, int hi) {
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
  }

  /** Tile-tree harvest (AREA_MODE): apply DPS to the focused tree tile and produce a HarvestEvent when felled. */
  private com.yourgame.survival.systems.HarvestSystem.HarvestTick tryHarvestTileTreeFov(
      float px, float py,
      float aimX, float aimY,
      float fwdX, float fwdY,
      float fovDeg,
      float range,
      int toolItemId,
      float dt
  ) {
    if (!AREA_MODE) return null;
    if (toolItemId != 14) return null; // Axe only
    if (dt <= 0f) return null;
    if (areaTreePresentBits == null || areaTreeCutBits == null || areaTreeW <= 0 || areaTreeH <= 0) return null;

    // FOV gate (same principle as HarvestSystem)
    float adx = aimX - px;
    float ady = aimY - py;
    float al2 = adx * adx + ady * ady;
    if (al2 <= 1e-6f) return null;
    float ainv = (float) (1.0 / Math.sqrt(al2));
    float ax = adx * ainv;
    float ay = ady * ainv;
    float cosHalf = (float) Math.cos(Math.toRadians(fovDeg * 0.5));
    if (fwdX * ax + fwdY * ay < cosHalf) return null;

    // Target tile at aim point.
    int tx = (int) Math.floor(aimX / World.TILE_WORLD);
    int ty = (int) Math.floor(aimY / World.TILE_WORLD);
    if (tx < 0 || ty < 0 || tx >= areaTreeW || ty >= areaTreeH) return null;

    int bit = bitIndex(tx, ty, areaTreeW);
    if (!bitGet(areaTreePresentBits, bit)) return null;
    if (TILE_TREES_FELL_ON_HARVEST && bitGet(areaTreeCutBits, bit)) return null;

    // Cooldown: limit how often a single tile-tree can yield drops.
    float nextAt = tileTreeNextHarvestAtSec.get(bit, -1f);
    if (nextAt > 0f && runtimeSec < nextAt) return null;

    // Range gate
    float treeX = (tx + 0.5f) * World.TILE_WORLD;
    float treeY = (ty * World.TILE_WORLD) + 34.0f;
    float dx = treeX - px;
    float dy = treeY - py;
    float eff = range + com.yourgame.survival.entity.EntityMetrics.radius(EntityType.NODE_TREE);
    if (dx * dx + dy * dy > eff * eff) return null;

    // "Below" + "near trunk" gate (mirrors HarvestSystem feel)
    float treeW = com.yourgame.survival.entity.EntityMetrics.drawW(EntityType.NODE_TREE);
    float treeH = com.yourgame.survival.entity.EntityMetrics.drawH(EntityType.NODE_TREE);
    boolean below = py <= (treeY - treeH * 0.10f);
    boolean nearTrunk = Math.abs(dx) <= (treeW * 0.35f);
    if (!below || !nearTrunk) return null;

    // DPS + HP model (simple, tile-local cache)
    float dps = com.yourgame.survival.tuning.TuningGameplay.DPS_TREE_AXE;
    float maxHp = 20f; // matches Entities.defaultHp(NODE_TREE)

    if (tileTreeHitTx != tx || tileTreeHitTy != ty || tileTreeHitHp <= 0f) {
      tileTreeHitTx = tx;
      tileTreeHitTy = ty;
      tileTreeHitHp = maxHp;
    }

    tileTreeHitHp -= dps * dt;
    if (tileTreeHitHp > 0f) {
      tileTreeHitUiT = 0.55f;
      return new com.yourgame.survival.systems.HarvestSystem.HarvestTick(true, null);
    }

    // Harvest complete:
    // - If TILE_TREES_FELL_ON_HARVEST=false: tree stays, no stump, yields drops on cooldown.
    // - If true: caller will mark cutBit and render stump.
    tileTreeHitHp = 0f;
    tileTreeHitUiT = 0.75f;
    tileTreeNextHarvestAtSec.put(bit, runtimeSec + TILE_TREE_HARVEST_COOLDOWN_SEC);

    com.yourgame.survival.systems.HarvestSystem.HarvestEvent ev =
        new com.yourgame.survival.systems.HarvestSystem.HarvestEvent(0, 5, TILE_TREES_FELL_ON_HARVEST, EntityType.NODE_TREE, treeX, treeY);
    return new com.yourgame.survival.systems.HarvestSystem.HarvestTick(true, ev);
  }

  private void areaEnemyZonesTick(float dt) {
    if (enemyZones.size == 0) return;

    final float tw = World.TILE_WORLD;

    for (int zi = 0; zi < enemyZones.size; zi++) {
      EnemyZone z = enemyZones.get(zi);
      if (z == null) continue;

      // Count orks currently inside (loose: within radius+2 tiles)
      float cx = (z.cxTile + 0.5f) * tw;
      float cy = (z.cyTile + 0.5f) * tw;
      float rr = (z.rTiles + 2.0f) * tw;
      float rr2 = rr * rr;

      int count = 0;
      for (int e = 0; e < Entities.MAX; e++) {
        if (!entities.alive[e]) continue;
        if (entities.type[e] != EntityType.ORK_GRUNT) continue;
        float dx = entities.x[e] - cx;
        float dy = entities.y[e] - cy;
        if (dx * dx + dy * dy <= rr2) count++;
      }

      if (dayIndex < z.nextRespawnDayIndex) {
        // Also keep orks pulled inside the zone boundary.
        clampOrksTowardZone(cx, cy, z.rTiles * tw);
        continue;
      }

      int want = Math.max(0, z.targetCount - count);
      if (want <= 0) {
        clampOrksTowardZone(cx, cy, z.rTiles * tw);
        continue;
      }

      java.util.Random r = new java.util.Random(z.seed ^ (long) dayIndex * 0xD1B54A32D192ED03L);

      // Spawn missing orks.
      for (int k = 0; k < want; k++) {
        // random point in circle
        float ang = (float) (r.nextFloat() * Math.PI * 2.0);
        float rad = (float) Math.sqrt(r.nextFloat()) * (z.rTiles * tw * 0.88f);
        float wx = cx + (float) Math.cos(ang) * rad;
        float wy = cy + (float) Math.sin(ang) * rad;

        // Skip if blocked/water.
        if (world.isWaterAtWorldPeek(wx, wy, true)) continue;
        if (world.isBlockedAtWorldPeek(wx, wy, true)) continue;

        entities.spawn(EntityType.ORK_GRUNT, wx, wy);
      }

      // Schedule next respawn window: 1..2 days (random)
      int daysSpan = z.respawnDaysMin + (z.respawnDaysMax > z.respawnDaysMin ? r.nextInt(z.respawnDaysMax - z.respawnDaysMin + 1) : 0);
      z.nextRespawnDayIndex = dayIndex + Math.max(1, daysSpan);

      clampOrksTowardZone(cx, cy, z.rTiles * tw);
    }
  }

  private void clampOrksTowardZone(float cx, float cy, float r) {
    if (r <= 1e-3f) return;
    float pullR = r * 1.06f;
    float pullR2 = pullR * pullR;

    for (int e = 0; e < Entities.MAX; e++) {
      if (!entities.alive[e]) continue;
      if (entities.type[e] != EntityType.ORK_GRUNT) continue;

      float dx = entities.x[e] - cx;
      float dy = entities.y[e] - cy;
      float d2 = dx * dx + dy * dy;

      if (d2 <= pullR2) continue;

      // If the orc is currently alert/chasing the player, do NOT override its AI velocity.
      // Requirement: stop wandering/clamping while chasing; resume wandering when shaken off.
      if (entities.aiF1[e] > 0.15f) continue;

      float inv = 1.0f / (float) Math.sqrt(Math.max(1e-6f, d2));
      float vx = -dx * inv;
      float vy = -dy * inv;

      // Force a gentle pull back inside the zone.
      float spd = 60f;
      entities.vx[e] = vx * spd;
      entities.vy[e] = vy * spd;
      entities.rot[e] = (float) Math.atan2(entities.vy[e], entities.vx[e]);
    }
  }

  /**
   * Tile-tree streaming (FUSA Story):
   * - Trees/stumps are NOT spawned as Entities (prevents Entities.MAX exhaustion).
   * - Instead, we update tile collision based on presence/cut bits.
   * - Rendering uses EntityRenderer.drawTileTrees() directly from bitmasks.
   */
  private void areaTileTreesTick(float dt) {
    if (!AREA_MODE) return;
    if (areaTreePresentBits == null || areaTreeCutBits == null) {
      areaDebugToastOnce("TileTrees tick: missing bits (present=" + (areaTreePresentBits != null) + ", cut=" + (areaTreeCutBits != null) + ")");
      return;
    }
    if (areaTreeW <= 0 || areaTreeH <= 0) {
      areaDebugToastOnce("TileTrees tick: invalid size w=" + areaTreeW + " h=" + areaTreeH);
      return;
    }

    // One-shot purge: older versions spawned NODE_TREE/NODE_STUMP as Entities and could hit Entities.MAX.
    if (!tileTreeEntitiesPurged) {
      for (int e = 0; e < Entities.MAX; e++) {
        if (!entities.alive[e]) continue;
        EntityType t = entities.type[e];
        if (t == EntityType.NODE_TREE || t == EntityType.NODE_STUMP) {
          entities.kill(e);
        }
      }
      tileTreeEntitiesPurged = true;
    }

    // Debug telemetry (cheap counters; shown via toast)
    int dbgPresentTiles = 0;
    int dbgSkipRoad = 0;
    int dbgSkipWater = 0;
    int dbgBlockTiles = 0;
    int dbgCutTiles = 0;

    // Update collision mask for visible tiles.
    for (int cy = loadedMinCy; cy <= loadedMaxCy; cy++) {
      for (int cx = loadedMinCx; cx <= loadedMaxCx; cx++) {
        com.yourgame.survival.world.Chunk c = world.peekChunk(cx, cy);
        if (c == null || c.layers == null) continue;

        int baseTx = cx * World.CHUNK_SIZE;
        int baseTy = cy * World.CHUNK_SIZE;

        for (int ly = 0; ly < World.CHUNK_SIZE; ly++) {
          int ty = baseTy + ly;
          if (ty < 0 || ty >= areaTreeH) continue;
          for (int lx = 0; lx < World.CHUNK_SIZE; lx++) {
            int tx = baseTx + lx;
            if (tx < 0 || tx >= areaTreeW) continue;

            int bit = bitIndex(tx, ty, areaTreeW);
            if (!bitGet(areaTreePresentBits, bit)) continue;
            dbgPresentTiles++;

            int idx = lx + ly * World.CHUNK_SIZE;

            // Road/water tiles must stay tree-free.
            if (c.layers.roadMask[idx] != 0) {
              c.layers.collisionMask[idx] = 0;
              dbgSkipRoad++;
              continue;
            }
            if (c.layers.waterMask[idx] != 0) {
              c.layers.collisionMask[idx] = 0;
              dbgSkipWater++;
              continue;
            }

            boolean cut = bitGet(areaTreeCutBits, bit);
            // IMPORTANT: allow movement under the canopy.
            // Trunk collision is handled separately (AABB around trunk center), so we do NOT block the whole tile.
            c.layers.collisionMask[idx] = 0;
            if (cut) dbgCutTiles++; else dbgBlockTiles++;
          }
        }
      }
    }

    // Debug toast (rate-limited)
    if (dbgTileTrees) {
      dbgTileTreesToastCooldown -= dt;
      if (dbgTileTreesToastCooldown <= 0f) {
        dbgTileTreesToastCooldown = 0.75f;
        toast = "DBG TileTrees: w=" + areaTreeW + " h=" + areaTreeH
            + " presentTiles=" + dbgPresentTiles
            + " skip(road=" + dbgSkipRoad + ",water=" + dbgSkipWater + ")"
            + " coll(block=" + dbgBlockTiles + ",cut=" + dbgCutTiles + ")";
        toastT = 0.90f;
      }
    }
  }

  /**
   * Resolves trunk-only collision against tile-trees inside the loaded chunk window.
   *
   * This matches the previous feel of NODE_TREE entity collisions:
   * - only a small trunk box blocks
   * - canopy is passable (player can walk "under" it)
   */
  private void resolveTileTreeTrunksInLoadedWindow() {
    if (!AREA_MODE) return;
    if (areaTreePresentBits == null || areaTreeCutBits == null || areaTreeW <= 0 || areaTreeH <= 0) return;
    if (world == null || entities == null) return;

    final float treeTrunkHalf = com.yourgame.survival.tuning.TuningEntities.TREE_TRUNK_HALF;
    final float treeTrunkCenterFromBottom = com.yourgame.survival.tuning.TuningEntities.TREE_TRUNK_CENTER_FROM_BOTTOM_PX;
    final float treeH = com.yourgame.survival.entity.EntityMetrics.drawH(EntityType.NODE_TREE);
    final float treeBottomOffset = 34.0f - (treeH * 0.5f); // yCenter=ty*16+34

    final float stumpHalfW = com.yourgame.survival.tuning.TuningEntities.STUMP_COLLIDER_HALF_W;
    final float stumpHalfH = com.yourgame.survival.tuning.TuningEntities.STUMP_COLLIDER_HALF_H;
    final float stumpCenterFromBottom = com.yourgame.survival.tuning.TuningEntities.STUMP_COLLIDER_CENTER_FROM_BOTTOM_PX;
    final float stumpH = com.yourgame.survival.entity.EntityMetrics.drawH(EntityType.NODE_STUMP);
    final float stumpBottomOffset = 2.0f - (stumpH * 0.5f); // yCenter=ty*16+2

    for (int e = 0; e < Entities.MAX; e++) {
      if (!entities.alive[e]) continue;
      EntityType t = entities.type[e];
      if (t != EntityType.PLAYER && t != EntityType.ORK_GRUNT && t != EntityType.ANIMAL_DEER) continue;

      // Respect the loaded window for non-always-active entities.
      if (!entities.isAlwaysActive(e)) {
        int ecx = (int) Math.floor((entities.x[e] / World.TILE_WORLD) / World.CHUNK_SIZE);
        int ecy = (int) Math.floor((entities.y[e] / World.TILE_WORLD) / World.CHUNK_SIZE);
        if (ecx < loadedMinCx || ecx > loadedMaxCx || ecy < loadedMinCy || ecy > loadedMaxCy) continue;
      }

      float px = entities.x[e];
      float py = entities.y[e];
      final float ox = px;
      final float oy = py;

      float moverHalf = Math.max(3f, com.yourgame.survival.entity.EntityMetrics.collisionRadius(t));

      int tx0 = (int) Math.floor(px / World.TILE_WORLD);
      int ty0 = (int) Math.floor(py / World.TILE_WORLD);

      // Only need a tiny neighborhood (trunk extents < 1 tile).
      for (int ty = ty0 - 1; ty <= ty0 + 1; ty++) {
        if (ty < 0 || ty >= areaTreeH) continue;
        for (int tx = tx0 - 1; tx <= tx0 + 1; tx++) {
          if (tx < 0 || tx >= areaTreeW) continue;

          int bit = bitIndex(tx, ty, areaTreeW);
          if (!bitGet(areaTreePresentBits, bit)) continue;
          boolean cut = TILE_TREES_FELL_ON_HARVEST && bitGet(areaTreeCutBits, bit);

          // Ignore road/water tiles to match render/selection rules.
          int cx = tx / World.CHUNK_SIZE;
          int cy = ty / World.CHUNK_SIZE;
          com.yourgame.survival.world.Chunk c = world.peekChunk(cx, cy);
          if (c == null || c.layers == null) continue;
          int lx = tx - cx * World.CHUNK_SIZE;
          int ly = ty - cy * World.CHUNK_SIZE;
          int idx = lx + ly * World.CHUNK_SIZE;
          if (c.layers.roadMask[idx] != 0) continue;
          if (c.layers.waterMask[idx] != 0) continue;

          float colCx = (tx + 0.5f) * World.TILE_WORLD;
          float colCy;
          float halfW;
          float halfH;

          if (!cut) {
            // TREE trunk collider (small box)
            float bottom = (ty * World.TILE_WORLD) + treeBottomOffset;
            colCy = bottom + treeTrunkCenterFromBottom;
            halfW = treeTrunkHalf;
            halfH = treeTrunkHalf;
          } else {
            // STUMP silhouette collider (AABB around stump body)
            float bottom = (ty * World.TILE_WORLD) + stumpBottomOffset;
            colCy = bottom + stumpCenterFromBottom;
            halfW = stumpHalfW;
            halfH = stumpHalfH;
          }

          float dx = px - colCx;
          float dy = py - colCy;

          float overlapX = (moverHalf + halfW) - Math.abs(dx);
          if (overlapX <= 0f) continue;
          float overlapY = (moverHalf + halfH) - Math.abs(dy);
          if (overlapY <= 0f) continue;

          // Resolve along least penetration.
          if (overlapX < overlapY) {
            float sx = (dx < 0f) ? -1f : 1f;
            px += sx * overlapX;
          } else {
            float sy = (dy < 0f) ? -1f : 1f;
            py += sy * overlapY;
          }
        }
      }

      // If we got pushed by a trunk, also steer wandering orks away from the obstacle.
      // Otherwise they can "slide" along dense trunk lines and look like they march on a border.
      if (t == EntityType.ORK_GRUNT) {
        float mdx = px - ox;
        float mdy = py - oy;
        if (mdx * mdx + mdy * mdy > 1e-6f) {
          // Only apply when not actively chasing/alert.
          if (entities.aiF1[e] <= 0.15f) {
            // Force a direction refresh soon in the AI.
            entities.aiT[e] = 0f;
            // Dampen velocity so it doesn't keep pushing into the same trunk line.
            entities.vx[e] *= 0.20f;
            entities.vy[e] *= 0.20f;
            // Turn left/right deterministically.
            if (((e ^ dayIndex) & 1) == 0) {
              // left
              entities.dir[e] = (byte) switch (entities.dir[e]) {
                case 0 -> 3;
                case 1 -> 0;
                case 2 -> 1;
                default -> 2;
              };
            } else {
              // right
              entities.dir[e] = (byte) switch (entities.dir[e]) {
                case 0 -> 1;
                case 1 -> 2;
                case 2 -> 3;
                default -> 0;
              };
            }
          }
        }
      }

      entities.x[e] = px;
      entities.y[e] = py;
    }
  }

  @Override
  public void resize(int width, int height) {
    // keep current zoom; setToOrtho resets projection params
    float z = (cam != null) ? cam.zoom : ZOOM_DEFAULT;
    cam.setToOrtho(false, width, height);
    cam.zoom = MathUtils.clamp(z, ZOOM_MIN, ZOOM_MAX);

    if (uiCam != null) {
      uiCam.setToOrtho(false, width, height);
      uiCam.update();
    }

    // Recreate Day/Night mask framebuffer on resize
    rebuildDnMaskFbo(width, height);
  }

  private void onKill(CombatSystem.Kill k) {
    encounterSpawner.onKilled(k.type());
    // XP + loot on kill
    if (k.type() == EntityType.ORK_GRUNT) {
      progress.addXp(data.orkGrunt.xp);
      int coins = randRange(data.orkGrunt.coinMin, data.orkGrunt.coinMax);
      int lootingLv = (SK_LOOTING >= 0 && SK_LOOTING < progress.skillLv.length) ? progress.skillLv[SK_LOOTING] : 1;
      coins = SkillEffects.bonusAmountMul5(coins, lootingLv);
      // Drop copper coins; wallet absorbs on pickup
      entities.spawnDrop(31, coins, k.x(), k.y());
    } else if (k.type() == EntityType.ANIMAL_DEER) {
      progress.addXp(1);
      int meat = randRange(Math.max(1, data.deer.meatMin), Math.max(1, data.deer.meatMax));
      int huntingLv = (SK_HUNTING >= 0 && SK_HUNTING < progress.skillLv.length) ? progress.skillLv[SK_HUNTING] : 1;
      meat = SkillEffects.bonusAmountMul5(meat, huntingLv);
      entities.spawnDrop(28, meat, k.x(), k.y());
    }
  }

  private void pickupNearby() {
    float eff = REACH_PICKUP + com.yourgame.survival.entity.EntityMetrics.radius(EntityType.ITEM_DROP);
    float r2 = eff * eff;
    for (int i=0;i<Entities.MAX;i++) {
      if (!entities.alive[i]) continue;
      if (entities.type[i] != EntityType.ITEM_DROP) continue;
      float dx = entities.x[i] - px;
      float dy = entities.y[i] - py;
      if (dx*dx + dy*dy <= r2) {
        int id = entities.itemId[i];
        int amt = entities.itemAmount[i];

        // currency items go to wallet, not inventory
        if (id >= 31 && id <= 33) {
          int each = Math.max(0, priceBook.getBaseCopper(id));
          wallet.addCopper((long) each * Math.max(0, amt));
        } else {
          inv.add(id, amt);
        }

        entities.kill(i);
        game.audio.sfx("audio/sfx/pickup.wav", game.audio.sfxVolume(game.settings));
        return;
      }
    }
  }

  // Nicht fertiges Feature: commented out unused method
  /*
  private boolean isNearBuild(EntityType t, float range) {
    float eff = range + com.yourgame.survival.entity.EntityMetrics.radius(t);
    float r2 = eff * eff;
    for (int i=0;i<Entities.MAX;i++) {
      if (!entities.alive[i]) continue;
      if (entities.type[i] != t) continue;
      float dx = entities.x[i] - px;
      float dy = entities.y[i] - py;
      if (dx*dx + dy*dy <= r2) return true;
    }
    return false;
  }
  */

  private float actionFovDeg() {
    // NOTE: requested: skills can expand FoV/actionrange.
    // Minimal implementation: Navigation skill slightly widens the effective interaction FoV.
    int navLv = (SK_SPEED >= 0 && SK_SPEED < progress.skillLv.length) ? progress.skillLv[SK_SPEED] : 1;
    float mul = 1f + 0.01f * Math.max(0, navLv - 1);
    if (mul > 1.25f) mul = 1.25f;
    return ACTION_FOV_DEG * mul;
  }

  private boolean pointInSilhouette(int e, float wx, float wy) {
    if (e < 0 || e >= Entities.MAX) return false;
    if (!entities.alive[e]) return false;
    EntityType t = entities.type[e];
    float w = com.yourgame.survival.entity.EntityMetrics.drawW(t);
    float h = com.yourgame.survival.entity.EntityMetrics.drawH(t);
    float x0 = entities.x[e] - w * 0.5f;
    float y0 = entities.y[e] - h * 0.5f;
    return wx >= x0 && wx <= x0 + w && wy >= y0 && wy <= y0 + h;
  }

  private boolean tryInteractAtMouse(float fovFx, float fovFy) {
    // All world interactions must be within the player's action radius and inside the FoV.
    // Additionally, the target must be under the mouse cursor silhouette.
    if (walletOpen || pricingOpen || skillsOpen || mapOpen) return false;

    // Chest/merchant cannot be opened while another modal is open.
    if (craftOpen || invOpen || buildMode || openChestE >= 0) {
      // Allow closing chest by click if it's open.
      if (openChestE >= 0) {
        openChestE = -1;
        game.audio.sfx("audio/sfx/close_chest.wav", game.audio.sfxVolume(game.settings));
        return true;
      }
      return false;
    }

    float reach = actionReach(equippedFromHotbar());
    float fovDeg = actionFovDeg();

    int best = -1;
    float bestD2 = Float.POSITIVE_INFINITY;

    // Candidates: merchant + chest + item drops.
    for (int i = 0; i < Entities.MAX; i++) {
      if (!entities.alive[i]) continue;
      EntityType t = entities.type[i];
      boolean ok = (t == EntityType.MERCHANT_ELF || t == EntityType.MERCHANT_WANDERING || t == EntityType.BUILD_CHEST || t == EntityType.POI_CHEST_HIDDEN || t == EntityType.ITEM_DROP);
      if (!ok) continue;

      // Must be clickable on silhouette
      if (!pointInSilhouette(i, mouseWorldX, mouseWorldY)) continue;

      // Must be inside FoV
      if (!isInsideFov(px, py, entities.x[i], entities.y[i], fovFx, fovFy, fovDeg)) continue;

      // Must be in action radius (player range + target radius)
      float eff = reach + com.yourgame.survival.entity.EntityMetrics.radius(t);
      float dx = entities.x[i] - px;
      float dy = entities.y[i] - py;
      if (dx * dx + dy * dy > eff * eff) continue;

      // Prefer nearest to cursor
      float mx = entities.x[i] - mouseWorldX;
      float my = entities.y[i] - mouseWorldY;
      float md2 = mx * mx + my * my;
      if (md2 < bestD2) {
        bestD2 = md2;
        best = i;
      }
    }

    if (best < 0) return false;

    EntityType bt = entities.type[best];
    if (bt == EntityType.BUILD_CHEST || bt == EntityType.POI_CHEST_HIDDEN) {
      openChestE = best;
      shopOpen = false;
      craftOpen = false;
      invOpen = false;
      buildMode = false;
      game.audio.sfx("audio/sfx/open_chest.wav", game.audio.sfxVolume(game.settings));
      if (bt == EntityType.POI_CHEST_HIDDEN) {
        toast = "Hidden Chest gefunden";
        toastT = 15f;
      }
      return true;
    }

    if (bt == EntityType.MERCHANT_ELF || bt == EntityType.MERCHANT_WANDERING) {
      shopOpen = !shopOpen;
      if (shopOpen) {
        openMerchantE = best;
        craftOpen = false;
        walletOpen = false;
        syncShopFromMerchant(openMerchantE);
        if (Float.isNaN(invAnchorX) || Float.isNaN(invAnchorY)) {
          invAnchorX = 0f;
          invAnchorY = 0f;
        }
        game.audio.sfx("audio/sfx/ui_click.wav", game.audio.sfxVolume(game.settings));
      } else {
        openMerchantE = -1;
        buyPopup = false;
        buyBuffer = "";
        dragArmed = false;
        dragActive = false;
        game.audio.sfx("audio/sfx/ui_back.wav", game.audio.sfxVolume(game.settings));
      }
      return true;
    }

    if (bt == EntityType.ITEM_DROP) {
      // Click-to-pickup (within reach) like in-world interaction.
      int id = entities.itemId[best];
      int amt = entities.itemAmount[best];
      if (id >= 31 && id <= 33) {
        int each = Math.max(0, priceBook.getBaseCopper(id));
        wallet.addCopper((long) each * Math.max(0, amt));
      } else {
        inv.add(id, amt);
      }
      entities.kill(best);
      game.audio.sfx("audio/sfx/pickup.wav", game.audio.sfxVolume(game.settings));
      return true;
    }

    return false;
  }

  private boolean tryToggleShop() {
    // Wallet open blocks shop toggle
    if (walletOpen) return false;

    // Chest interaction has priority
    if (tryToggleChest()) return true;

    // Legacy toggle (keyboard): nearest merchant inside action radius AND inside FoV.
    float reach = actionReach(equippedFromHotbar());
    float fovDeg = actionFovDeg();
    // use current aim dir
    float fovFx = (float) Math.cos(playerAimA);
    float fovFy = (float) Math.sin(playerAimA);

    float eff = reach + com.yourgame.survival.entity.EntityMetrics.radius(EntityType.MERCHANT_ELF);
    float r2 = eff * eff;
    for (int i=0;i<Entities.MAX;i++) {
      if (!entities.alive[i]) continue;
      if (entities.type[i] != EntityType.MERCHANT_ELF && entities.type[i] != EntityType.MERCHANT_WANDERING) continue;
      if (!isInsideFov(px, py, entities.x[i], entities.y[i], fovFx, fovFy, fovDeg)) continue;
      float dx = entities.x[i] - px;
      float dy = entities.y[i] - py;
      if (dx*dx + dy*dy <= r2) {
        shopOpen = !shopOpen;
        if (shopOpen) {
          openMerchantE = i;
          craftOpen = false;
          walletOpen = false;
          syncShopFromMerchant(openMerchantE);
          if (Float.isNaN(invAnchorX) || Float.isNaN(invAnchorY)) {
            invAnchorX = 0f;
            invAnchorY = 0f;
          }
          game.audio.sfx("audio/sfx/ui_click.wav", game.audio.sfxVolume(game.settings));
        } else {
          openMerchantE = -1;
          buyPopup = false;
          buyBuffer = "";
          dragArmed = false;
          dragActive = false;
          game.audio.sfx("audio/sfx/ui_back.wav", game.audio.sfxVolume(game.settings));
        }
        return true;
      }
    }

    // If shop open, E closes
    if (shopOpen) {
      shopOpen = false;
      openMerchantE = -1;
      buyPopup = false;
      buyBuffer = "";
      dragArmed = false;
      dragActive = false;
      game.audio.sfx("audio/sfx/ui_back.wav", game.audio.sfxVolume(game.settings));
      return true;
    }
    return false;
  }

  private boolean tryToggleChest() {
    // E closes chest
    if (openChestE >= 0) {
      openChestE = -1;
      game.audio.sfx("audio/sfx/close_chest.wav", game.audio.sfxVolume(game.settings));
      return true;
    }

    float r = com.yourgame.survival.tuning.TuningGameplay.CHEST_OPEN_RANGE_WU;
    float r2 = r * r;
    for (int i=0;i<Entities.MAX;i++) {
      if (!entities.alive[i]) continue;
      if (entities.type[i] != EntityType.BUILD_CHEST && entities.type[i] != EntityType.POI_CHEST_HIDDEN) continue;
      float dx = entities.x[i] - px;
      float dy = entities.y[i] - py;
      if (dx*dx + dy*dy <= r2) {
        openChestE = i;
        shopOpen = false;
        craftOpen = false;
        invOpen = false;
        buildMode = false;
        game.audio.sfx("audio/sfx/open_chest.wav", game.audio.sfxVolume(game.settings));
        if (entities.type[i] == EntityType.POI_CHEST_HIDDEN) {
          toast = "Hidden Chest gefunden";
          toastT = 15f;
        }
        return true;
      }
    }

    return false;
  }

  private void regenShopOffers() {
    shopOfferCount = 0;

    // fixed offers first (prices derived from PriceBook: buy=sell*3)
    if (data.fixedShop != null) {
      for (int i=0;i<data.fixedShop.offerCount && shopOfferCount < shopItemId.length;i++) {
        int id = data.fixedShop.itemId[i];
        shopItemId[shopOfferCount] = id;
        int base = Math.max(1, priceBook.getBaseCopper(id));
        shopSell[shopOfferCount] = base;
        shopBuy[shopOfferCount] = Math.max(1, base * 3);
        shopOfferCount++;
      }
    }

    // daily wandering offers appended
    if (data.wanderingPoolItems != null && data.wanderingPoolItems.length > 0) {
      int tradingLv = (SK_TRADING >= 0 && SK_TRADING < progress.skillLv.length) ? progress.skillLv[SK_TRADING] : 1;
      int want = 3 + Math.max(0, (tradingLv - 1) / 10);
      for (int k=0;k<want && shopOfferCount < shopItemId.length;k++) {
        int tries = 0;
        int pick = -1;
        while (tries < 20) {
          int id = data.wanderingPoolItems[(int)(Math.random() * data.wanderingPoolItems.length)];
          boolean dup = false;
          for (int j=0;j<shopOfferCount;j++) {
            if (shopItemId[j] == id) { dup = true; break; }
          }
          if (!dup) { pick = id; break; }
          tries++;
        }
        if (pick < 0) break;

        int base = Math.max(1, priceBook.getBaseCopper(pick));
        shopItemId[shopOfferCount] = pick;
        shopSell[shopOfferCount] = base;
        shopBuy[shopOfferCount] = Math.max(1, base * 3);
        shopOfferCount++;
      }
    }
  }

  private void syncShopFromMerchant(int merchantE) {
    if (merchantE < 0 || merchantE >= Entities.MAX) return;
    if (!entities.alive[merchantE]) return;
    boolean wandering = entities.type[merchantE] == EntityType.MERCHANT_WANDERING;
    var s = merchants.stateFor(merchantE, wandering);
    merchants.ensureFresh(s, data, priceBook, progress);

    shopOfferCount = Math.min(shopItemId.length, s.offerCount);
    for (int i = 0; i < shopOfferCount; i++) {
      shopItemId[i] = s.itemId[i];
      shopBuy[i] = s.buy[i];
      shopSell[i] = s.sell[i];
    }
  }

  // Nicht fertiges Feature: commented out unused block
  /*
  private void shopBuyIndex(int idx, int amount) {
    if (idx < 0 || idx >= shopOfferCount) return;
    if (amount <= 0) return;
    int itemId = shopItemId[idx];
    int priceEach = shopBuy[idx];

    // Barter/Negotiation: better prices per level (5% each level)
    int barterLv = (SK_BARTER >= 0 && SK_BARTER < progress.skillLv.length) ? progress.skillLv[SK_BARTER] : 1;
    int negoLv = (SK_NEGOTIATION >= 0 && SK_NEGOTIATION < progress.skillLv.length) ? progress.skillLv[SK_NEGOTIATION] : 1;
    float buyMul = 1f;
    buyMul *= Math.max(0.20f, 1f - 0.05f * Math.max(0, barterLv - 1));
    buyMul *= Math.max(0.35f, 1f - 0.05f * Math.max(0, negoLv - 1));
    priceEach = Math.max(1, (int) Math.floor(priceEach * buyMul));

    long total = (long) priceEach * amount;
    if (total <= 0) return;

    if (wallet.spendCopper(total)) {
      inv.add(itemId, amount);
      game.audio.sfx("audio/sfx/craft.wav", game.audio.sfxVolume(game.settings));
    } else {
      game.audio.sfx("audio/sfx/ui_error.wav", game.audio.sfxVolume(game.settings));
    }
  }
  */

  /** Sell any itemId to merchant (used by inventory→shop drag). priceEachRaw is base copper before skills. */
  private void shopSellItem(int itemId, int priceEachRaw, int amount) {
    if (itemId < 0) return;
    if (amount <= 0) return;
    int priceEach = priceEachRaw;
    if (priceEach <= 0) {
      priceEach = Math.max(1, priceBook.getBaseCopper(itemId));
    }

    // Barter/Negotiation: better sell prices per level (5% each level)
    int barterLv = (SK_BARTER >= 0 && SK_BARTER < progress.skillLv.length) ? progress.skillLv[SK_BARTER] : 1;
    int negoLv = (SK_NEGOTIATION >= 0 && SK_NEGOTIATION < progress.skillLv.length) ? progress.skillLv[SK_NEGOTIATION] : 1;
    float sellMul = 1f;
    sellMul *= 1f + 0.05f * Math.max(0, barterLv - 1);
    sellMul *= 1f + 0.05f * Math.max(0, negoLv - 1);
    priceEach = Math.max(1, (int) Math.floor(priceEach * sellMul));

    int sold = 0;
    for (int i = 0; i < amount; i++) {
      if (!inv.spend(itemId, 1)) break;
      sold++;
    }
    if (sold <= 0) {
      game.audio.sfx("audio/sfx/ui_error.wav", game.audio.sfxVolume(game.settings));
      return;
    }

    wallet.addCopper((long) priceEach * sold);
    game.audio.sfx("audio/sfx/ui_click.wav", game.audio.sfxVolume(game.settings));
  }

  private void drawShopMenuAtMerchant() {
    if (openMerchantE < 0 || openMerchantE >= Entities.MAX || !entities.alive[openMerchantE] || (entities.type[openMerchantE] != EntityType.MERCHANT_ELF && entities.type[openMerchantE] != EntityType.MERCHANT_WANDERING)) {
      shopLayoutValid = false;
      // fallback: behave like old text HUD
      font.setColor(0f, 0f, 0f, 1f);
      font.getData().setScale(1.15f * UI_FONT_SCALE);
      font.draw(batch, "SHOP (drag shop→inventory = BUY | drag inventory→shop = SELL | RMB quick buy | CTRL x10 | SHIFT x100 | E close)", 20, Gdx.graphics.getHeight() - 130);
      int lines = Math.min(6, shopOfferCount);
      for (int i=0;i<lines;i++) {
        int id = shopItemId[i];
        String name = (id >= 0 && id < data.items.length && data.items[id] != null) ? data.items[id].name : ("item_" + id);
        font.draw(batch, name + "  buy=" + shopBuy[i] + " sell=" + shopSell[i], 20, Gdx.graphics.getHeight() - 150 - i*18);
      }
      font.getData().setScale(1.0f * UI_FONT_SCALE);
      font.setColor(0f, 0f, 0f, 1f);
      return;
    }

    // Merchant head position (world -> screen)

    // Merchant head position (world -> screen)
    float mxw = entities.x[openMerchantE];
    float myw = entities.y[openMerchantE];

    // Block 0: avoid per-frame allocations in render loop.
    Vector3 sp = scratch.v3a;
    sp.set(mxw, myw, 0f);
    cam.project(sp);

    float headOffset = com.yourgame.survival.entity.EntityMetrics.drawH(EntityType.MERCHANT_ELF) * 0.60f;
    Vector3 spHead = scratch.v3b;
    spHead.set(mxw, myw + headOffset, 0f);
    cam.project(spHead);

    // Layout: use inventory slot art (big & readable)
    float slot = 144f;
    float pad = 18f;

    int cols = 6;
    int rows = 2;

    float innerW = cols * slot + (cols - 1) * pad;
    float innerH = rows * slot + (rows - 1) * pad;

    float panelPad = 40f;
    float panelW = innerW + panelPad * 2f;
    float panelH = innerH + panelPad * 2f + 76f; // title

    // Anchor above merchant head
    float x0 = spHead.x - panelW * 0.5f;
    float y0 = spHead.y + 18f;

    // clamp to screen
    x0 = MathUtils.clamp(x0, 0f, Math.max(0f, Gdx.graphics.getWidth() - panelW));
    y0 = MathUtils.clamp(y0, 0f, Math.max(0f, Gdx.graphics.getHeight() - panelH));

    batch.setColor(1f, 1f, 1f, 1f);
    batch.draw(uiRegions.panelSlots, x0, y0, panelW, panelH);

    font.getData().setScale(1.6f * 1.15f);
    font.setColor(0f, 0f, 0f, 1f);
    font.draw(batch, "MERCHANT (drag shop→inventory = BUY | drag inventory→shop = SELL | RMB quick buy | CTRL x10 | SHIFT x100 | E close)", x0 + panelPad, y0 + panelH - 22f);
    font.setColor(0f, 0f, 0f, 1f);
    font.getData().setScale(1.0f * UI_FONT_SCALE);

    float sx0 = x0 + panelPad;
    float sy0 = y0 + panelPad;

    // cache for hit-tests
    shopPanelX0 = x0;
    shopPanelY0 = y0;
    shopPanelW = panelW;
    shopPanelH = panelH;
    shopSlotsX0 = sx0;
    shopSlotsY0 = sy0;
    shopSlotPx = slot;
    shopPadPx = pad;
    shopLayoutValid = true;

    int shown = Math.min(cols * rows, shopOfferCount);
    for (int i=0;i<cols*rows;i++) {
      float sx = sx0 + (i % cols) * (slot + pad);
      float sy = sy0 + (i / cols) * (slot + pad);

      batch.draw(uiRegions.slot, sx, sy, slot, slot);

      if (i < shown) {
        int itemId = shopItemId[i];
        if (itemId >= 0) {
          // icon
          TextureRegion icon = entityRegions.itemIcon(itemId);
          float iw = slot * 0.72f;
          float ih = slot * 0.72f;
          batch.draw(icon, sx + (slot - iw) * 0.5f, sy + (slot - ih) * 0.5f + 10f, iw, ih);

          // price labels (style like Chatty2: Buy (red) above, Sell (green) below)
          font.getData().setScale(1.02f * UI_FONT_SCALE);

          int row = i / cols;
          boolean topRow = row == rows - 1;

          float buyY = sy + slot + (topRow ? 22f : 2f);
          float sellY = sy - 12f;

          font.setColor(1f, 0f, 0f, 1f);
          font.draw(batch, "Buy " + shopBuy[i], sx + 8f, buyY);

          font.setColor(0.1f, 0.6f, 0.1f, 1f);
          font.draw(batch, "Sell " + shopSell[i], sx + 8f, sellY);

          font.getData().setScale(1.0f * UI_FONT_SCALE);
          font.setColor(0f, 0f, 0f, 1f);
        }
      }
    }

    // line indicator from merchant head to panel (subtle)
    batch.setColor(1f, 1f, 1f, 1f);
  }



// ---------------- Drag & Drop + Buy Popup (Merchant) ----------------

private static float uiMouseYUp() {
  return Gdx.graphics.getHeight() - Gdx.input.getY();
}
  void drawHoverIdsAtCursor() {
  // Screen-space cursor position
  float mx = Gdx.input.getX();
  float my = uiMouseYUp();

  // World-space info at cursor
  int tx = (int)Math.floor(mouseWorldX / World.TILE_WORLD);
  int ty = (int)Math.floor(mouseWorldY / World.TILE_WORLD);

  int biome = world.biomeIdAtTile(tx, ty);
  boolean water = world.isWaterAtTile(tx, ty);
  boolean blocked = world.isBlockedAtTile(tx, ty);

  int e = pickEntityNear(mouseWorldX, mouseWorldY);

  StringBuilder sb = new StringBuilder(192);
  sb.append("tile[").append(tx).append(',').append(ty).append("] biome=").append(biome);
  if (water) sb.append(" water");
  if (blocked) sb.append(" blocked");

  // FUSA Story debug: show tile-tree presence/cut state at cursor.
  if (AREA_MODE) {
    sb.append(" | tid=").append(worldMap != null ? worldMap.curTemplateId : "");
    if (areaTreePresentBits == null || areaTreeCutBits == null || areaTreeW <= 0 || areaTreeH <= 0) {
      sb.append(" | tileTrees=OFF");
    } else if (tx >= 0 && ty >= 0 && tx < areaTreeW && ty < areaTreeH) {
      int bit = bitIndex(tx, ty, areaTreeW);
      boolean presentT = bitGet(areaTreePresentBits, bit);
      boolean cutT = bitGet(areaTreeCutBits, bit);
      if (presentT) sb.append(cutT ? " | tree=STUMP" : " | tree=TREE");
      else sb.append(" | tree=none");
    } else {
      sb.append(" | tree=oob");
    }
  }

  if (e >= 0) {
    sb.append("  |  e=").append(e).append(" ").append(entities.type[e]);
    if (entities.type[e] == EntityType.ITEM_DROP) {
      sb.append(" item=").append(entities.itemId[e]).append(" x").append(entities.itemAmount[e]);
    } else if (entities.type[e] == EntityType.MERCHANT_ELF || entities.type[e] == EntityType.MERCHANT_WANDERING) {
      sb.append(" data0=").append(entities.data0[e]);
    }
  }

  // Draw slightly offset from cursor so it doesn't sit under the pointer.
  float x = mx + 14f;
  float y = my + 18f;

  // Keep inside screen bounds (roughly; we keep it simple).
  float maxX = Gdx.graphics.getWidth() - 10f;
  float maxY = Gdx.graphics.getHeight() - 10f;
  if (x > maxX) x = maxX;
  if (y > maxY) y = maxY;

  font.setColor(1f, 0f, 0f, 1f);
  font.getData().setScale(0.85f * UI_FONT_SCALE);
  font.draw(batch, sb.toString(), x, y);
  font.getData().setScale(1.0f * UI_FONT_SCALE);
  font.setColor(0f, 0f, 0f, 1f);
}

private int pickEntityNear(float wx, float wy) {
  int best = -1;
  float bestD2 = Float.POSITIVE_INFINITY;

  for (int i = 0; i < Entities.MAX; i++) {
    if (!entities.alive[i]) continue;

    float dx = entities.x[i] - wx;
    float dy = entities.y[i] - wy;

    float r = EntityMetrics.radius(entities.type[i]);
    // Make debug selection a bit more forgiving than interaction.
    float rr = (r + 10f);
    float d2 = dx*dx + dy*dy;
    if (d2 <= rr*rr && d2 < bestD2) {
      bestD2 = d2;
      best = i;
    }
  }

  return best;
}

private int shopHitSlot(float mx, float my) {
  if (!shopOpen) return -1;
  if (!shopLayoutValid) return -1;
  int cols = shopCols;
  int rows = shopRows;
  int shown = Math.min(cols * rows, shopOfferCount);
  for (int i = 0; i < shown; i++) {
    float sx = shopSlotsX0 + (i % cols) * (shopSlotPx + shopPadPx);
    float sy = shopSlotsY0 + (i / cols) * (shopSlotPx + shopPadPx);
    if (mx >= sx && mx <= sx + shopSlotPx && my >= sy && my <= sy + shopSlotPx) return i;
  }
  return -1;
}

private int invHitToolSlot(float mx, float my) {
  if (!invOpen) return -1;
  if (invSlotPx <= 0f) return -1;
  int gridW = Inventory.GRID_W;
  int rows = Math.max(0, invToolRowsDrawn);
  for (int y = 0; y < rows; y++) {
    for (int x = 0; x < gridW; x++) {
      int idx = y * gridW + x;
      float sx = invToolSlotsX0 + x * (invSlotPx + invPadPx);
      float sy = invToolSlotsY0 + y * (invSlotPx + invPadPx);
      if (mx >= sx && mx <= sx + invSlotPx && my >= sy && my <= sy + invSlotPx) return idx;
    }
  }
  return -1;
}

private int invHitNormalSlot(float mx, float my) {
  if (!invOpen) return -1;
  if (invSlotPx <= 0f) return -1;
  int gridW = Inventory.GRID_W;
  int rows = Math.max(0, invNormRowsDrawn);
  for (int y = 0; y < rows; y++) {
    for (int x = 0; x < gridW; x++) {
      int idx = y * gridW + x;
      float sx = invNormSlotsX0 + x * (invSlotPx + invPadPx);
      float sy = invNormSlotsY0 + y * (invSlotPx + invPadPx);
      if (mx >= sx && mx <= sx + invSlotPx && my >= sy && my <= sy + invSlotPx) return idx;
    }
  }
  return -1;
}

private int hotbarHit(float mx, float my) {
  // hotbar is always visible; layout is deterministic even if not cached yet
  float slot = (hotbarSlotPx > 0f) ? hotbarSlotPx : 144f;
  float pad = (hotbarPadPx > 0f) ? hotbarPadPx : 18f;
  float barW = hotbar.length * slot + (hotbar.length - 1) * pad;
  float x0 = (hotbarSlotPx > 0f) ? hotbarX0 : (Gdx.graphics.getWidth() - barW) * 0.5f;
  float y0 = (hotbarSlotPx > 0f) ? hotbarY0 : 0f;

  for (int i = 0; i < hotbar.length; i++) {
    float sx = x0 + i * (slot + pad);
    float sy = y0;
    if (mx >= sx && mx <= sx + slot && my >= sy && my <= sy + slot) return i;
  }
  return -1;
}

private int hotbarNearestSlot(float mx, float my) {
  // Choose the slot whose center is nearest at drop time.
  float slot = (hotbarSlotPx > 0f) ? hotbarSlotPx : 144f;
  float pad = (hotbarPadPx > 0f) ? hotbarPadPx : 18f;
  float barW = hotbar.length * slot + (hotbar.length - 1) * pad;
  float x0 = (hotbarSlotPx > 0f) ? hotbarX0 : (Gdx.graphics.getWidth() - barW) * 0.5f;
  float y0 = (hotbarSlotPx > 0f) ? hotbarY0 : 0f;

  int best = -1;
  float bestD2 = Float.POSITIVE_INFINITY;
  for (int i = 0; i < hotbar.length; i++) {
    float sx = x0 + i * (slot + pad);
    float sy = y0;
    float cx = sx + slot * 0.5f;
    float cy = sy + slot * 0.5f;
    float dx = mx - cx;
    float dy = my - cy;
    float d2 = dx * dx + dy * dy;
    if (d2 < bestD2) { bestD2 = d2; best = i; }
  }
  return best;
}

private void hotbarMoveWithShift(int from, int to) {
  if (from < 0 || from >= hotbar.length) return;
  if (to < 0 || to >= hotbar.length) return;
  if (from == to) return;

  int moving = hotbar[from];
  if (moving < 0) return;

  // Remove first.
  hotbar[from] = -1;

  if (hotbar[to] < 0) {
    hotbar[to] = moving;
    return;
  }

  // Prefer shifting to the right; if no free slot to the right, shift left.
  int free = -1;
  for (int i = to; i < hotbar.length; i++) {
    if (hotbar[i] < 0) { free = i; break; }
  }
  if (free >= 0) {
    for (int i = free; i > to; i--) {
      hotbar[i] = hotbar[i - 1];
    }
    hotbar[to] = moving;
    return;
  }

  for (int i = to; i >= 0; i--) {
    if (hotbar[i] < 0) { free = i; break; }
  }
  if (free >= 0) {
    for (int i = free; i < to; i++) {
      hotbar[i] = hotbar[i + 1];
    }
    hotbar[to] = moving;
    return;
  }

  // No free slot: fallback to swap (never drop/lose items).
  int tmp = hotbar[to];
  hotbar[to] = moving;
  hotbar[from] = tmp;
}

private void uiHandleDragDropAndPopup() {
  float mx = Gdx.input.getX();
  float my = uiMouseYUp();

  boolean lmbDown = Gdx.input.isButtonPressed(Input.Buttons.LEFT);
  boolean lmbJustPressed = lmbDown && !prevLmbDown;
  boolean lmbJustReleased = !lmbDown && prevLmbDown;

  // While popup is active: only popup interactions.
  if (buyPopup || sellPopup) {
    if (lmbJustReleased) {
      if (buyPopup) buyHandleMouseClick(mx, my);
      if (sellPopup) sellHandleMouseClick(mx, my);
    }
    prevLmbDown = lmbDown;
    return;
  }

  // Arm drag from shop slot OR from build slot OR from inventory slots OR from hotbar slot.
  if (lmbJustPressed) {
    int hoverShop = shopHitSlot(mx, my);
    if (hoverShop >= 0) {
      dragArmed = true;
      dragActive = false;
      dragSrc = DRAG_SRC_SHOP;
      dragIndex = hoverShop;
      dragItemId = shopItemId[hoverShop];
      dragStartX = mx;
      dragStartY = my;
    } else {
      int hoverBuild = buildHitSlot(mx, my);
      if (hoverBuild >= 0) {
        dragArmed = true;
        dragActive = false;
        dragSrc = DRAG_SRC_BUILD;
        dragIndex = hoverBuild;
        dragItemId = -1;
        dragStartX = mx;
        dragStartY = my;
      } else {
        int toolSlot = invHitToolSlot(mx, my);
        if (toolSlot >= 0) {
          int id = inv.getToolItemId(toolSlot);
          int c = inv.getToolCount(toolSlot);
          if (id >= 0 && c > 0) {
            dragArmed = true;
            dragActive = false;
            dragSrc = DRAG_SRC_TOOLINV;
            dragIndex = toolSlot;
            dragItemId = id;
            dragStartX = mx;
            dragStartY = my;
          }
        } else {
          int normalSlot = invHitNormalSlot(mx, my);
          if (normalSlot >= 0) {
            int id = inv.getNormalItemId(normalSlot);
            int c = inv.getNormalCount(normalSlot);
            if (id >= 0 && c > 0) {
              dragArmed = true;
              dragActive = false;
              dragSrc = DRAG_SRC_NORMINV;
              dragIndex = normalSlot;
              dragItemId = id;
              dragStartX = mx;
              dragStartY = my;
            }
          } else {
            int hb = hotbarHit(mx, my);
            if (hb >= 0) {
              int id = hotbar[hb];
              if (id >= 0) {
                dragArmed = true;
                dragActive = false;
                dragSrc = DRAG_SRC_HOTBAR;
                dragIndex = hb;
                dragItemId = id;
                dragStartX = mx;
                dragStartY = my;
              }
            }
          }
        }
      }
    }
  }

  // Promote armed drag into active drag if user moves far enough.
  if (lmbDown && dragArmed && !dragActive) {
    float dx = mx - dragStartX;
    float dy = my - dragStartY;
    if (dx * dx + dy * dy > 9f * 9f) {
      dragActive = true;
    }
  }

  // While dragging build icon: rotate in 8 angles with R (45° steps)
  if (dragArmed && dragActive && dragSrc == DRAG_SRC_BUILD && Gdx.input.isKeyJustPressed(Input.Keys.R)) {
    buildRot = (buildRot + 45f) % 360f;
  }

  // Drop / click resolution.
  if (lmbJustReleased && dragArmed) {
    if (dragActive) {
      switch (dragSrc) {
        case DRAG_SRC_SHOP -> {
          // Drop shop item into inventory -> open buy popup
          int normalSlot = invHitNormalSlot(mx, my);
          int toolSlot = invHitToolSlot(mx, my);
          if (normalSlot >= 0 || toolSlot >= 0) {
            openBuyPopup(dragIndex, normalSlot, toolSlot);
          } else {
            // dropped nowhere -> ignore
            game.audio.sfx("audio/sfx/ui_back.wav", game.audio.sfxVolume(game.settings));
          }
        }
        case DRAG_SRC_BUILD -> {
          // Drop build icon into world -> place
          buildSel = MathUtils.clamp(dragIndex, 0, 4);
          // Only place if not dropped inside the build panel
          if (!(buildLayoutValid && mx >= buildPanelX0 && mx <= buildPanelX0 + buildPanelW && my >= buildPanelY0 && my <= buildPanelY0 + buildPanelH)) {
            placeBuildAtMouse(mouseWorldX, mouseWorldY);
            game.audio.sfx("audio/sfx/ui_click.wav", game.audio.sfxVolume(game.settings));
          } else {
            game.audio.sfx("audio/sfx/ui_back.wav", game.audio.sfxVolume(game.settings));
          }
        }
        case DRAG_SRC_TOOLINV -> {
          // Drop inventory item onto merchant panel => SELL (popup)
          if (shopOpen && shopLayoutValid && mx >= shopPanelX0 && mx <= shopPanelX0 + shopPanelW && my >= shopPanelY0 && my <= shopPanelY0 + shopPanelH) {
            openSellPopup(dragItemId, dragSrc, dragIndex);
          } else {
            // Tool inventory: Drop tool onto hotbar OR reorder inside tool inventory.
            int hb = hotbarHit(mx, my);
            if (hb >= 0) {
              hotbar[hb] = dragItemId;
              game.audio.sfx("audio/sfx/ui_click.wav", game.audio.sfxVolume(game.settings));
            } else {
              int dropTool = invHitToolSlot(mx, my);
              if (dropTool >= 0 && dropTool != dragIndex) {
                inv.swapToolSlots(dragIndex, dropTool);
                game.audio.sfx("audio/sfx/ui_click.wav", game.audio.sfxVolume(game.settings));
              } else {
                game.audio.sfx("audio/sfx/ui_back.wav", game.audio.sfxVolume(game.settings));
              }
            }
          }
        }
        case DRAG_SRC_NORMINV -> {
          // Drop inventory item onto merchant panel => SELL (popup)
          if (shopOpen && shopLayoutValid && mx >= shopPanelX0 && mx <= shopPanelX0 + shopPanelW && my >= shopPanelY0 && my <= shopPanelY0 + shopPanelH) {
            openSellPopup(dragItemId, dragSrc, dragIndex);
          } else {
            // Normal inventory drag dropped elsewhere -> ignore
            game.audio.sfx("audio/sfx/ui_back.wav", game.audio.sfxVolume(game.settings));
          }
        }
        case DRAG_SRC_HOTBAR -> {
          // Reorder hotbar by drag&drop.
          int target = hotbarNearestSlot(mx, my);
          if (target >= 0) {
            hotbarMoveWithShift(dragIndex, target);
            game.audio.sfx("audio/sfx/ui_click.wav", game.audio.sfxVolume(game.settings));
          } else {
            game.audio.sfx("audio/sfx/ui_back.wav", game.audio.sfxVolume(game.settings));
          }
        }
        default -> {
          // ignore
        }
      }
    } else {
      // Not a drag: do nothing on LMB (avoid accidental sell/buy). RMB is quick-buy.
    }

    // reset drag state
    dragArmed = false;
    dragActive = false;
    dragSrc = DRAG_SRC_NONE;
    dragItemId = -1;
    dragIndex = -1;
  }

  prevLmbDown = lmbDown;
}

private void openBuyPopup(int offerIdx, int normalSlot, int toolSlot) {
  if (offerIdx < 0 || offerIdx >= shopOfferCount) return;
  int itemId = shopItemId[offerIdx];
  int priceEach = shopBuy[offerIdx];
  if (itemId < 0 || priceEach <= 0) return;

  boolean isTool = inv.isToolItem(itemId);

  buyPopup = true;
  buyOfferIdx = offerIdx;
  buyItemId = itemId;
  buyPriceEach = priceEach;

  // Preferred target: only meaningful in the correct area.
  if (isTool) {
    buyPreferredToolArea = true;
    buyPreferredSlot = (toolSlot >= 0) ? toolSlot : -1;
  } else {
    buyPreferredToolArea = false;
    buyPreferredSlot = (normalSlot >= 0) ? normalSlot : -1;
  }

  long affordable = wallet.copper / (long) priceEach;
  long cap = isTool ? (long) inv.maxAddable(itemId) * (long) inv.stackMax(itemId) : 9_999L;
  long max = Math.min(affordable, cap);
  if (max < 1) {
    buyPopup = false;
    game.audio.sfx("audio/sfx/ui_error.wav", game.audio.sfxVolume(game.settings));
    toast = "Not enough coins / no space";
    toastT = 3f;
    return;
  }

  buyMax = (int) Math.min(Integer.MAX_VALUE, max);
  buyAmount = MathUtils.clamp(1, 1, buyMax);
  buyBuffer = String.valueOf(buyAmount);

  game.audio.sfx("audio/sfx/ui_click.wav", game.audio.sfxVolume(game.settings));
}

private void buySetAmount(int v) {
  if (!buyPopup) return;
  v = MathUtils.clamp(v, 1, Math.max(1, buyMax));
  buyAmount = v;
  buyBuffer = String.valueOf(v);
}

private void buyApplyBuffer() {
  if (!buyPopup) return;
  if (buyBuffer == null || buyBuffer.isEmpty()) {
    buyAmount = 1;
    return;
  }
  try {
    int v = Integer.parseInt(buyBuffer);
    v = MathUtils.clamp(v, 1, Math.max(1, buyMax));
    buyAmount = v;
  } catch (NumberFormatException ignored) {
    buyAmount = 1;
  }
}

private void craftApplyQtyBuffer() {
  if (!(craftOpen && craftQtyFocusIdx >= 0)) return;
  if (craftQtyBuffer == null || craftQtyBuffer.isEmpty()) craftQtyBuffer = "1";
  try {
    int v = Integer.parseInt(craftQtyBuffer);
    v = MathUtils.clamp(v, 0, 99999);
    if (craftQtyFocusIdx >= 0 && craftQtyFocusIdx < craftQtyByRecipe.length) {
      craftQtyByRecipe[craftQtyFocusIdx] = Math.max(0, v);
    }
  } catch (NumberFormatException ignored) {
    if (craftQtyFocusIdx >= 0 && craftQtyFocusIdx < craftQtyByRecipe.length) craftQtyByRecipe[craftQtyFocusIdx] = 1;
  }
}

private void buyCancel() {
  buyPopup = false;
  buyOfferIdx = -1;
  buyItemId = -1;
  buyPreferredSlot = -1;
  buyPreferredToolArea = false;
  buyAmount = 1;
  buyMax = 1;
  buyBuffer = "";
  dragArmed = false;
  dragActive = false;
  dragSrc = DRAG_SRC_NONE;
  dragItemId = -1;
  dragIndex = -1;
}

private void buyConfirm() {
  if (!buyPopup) return;
  if (buyOfferIdx < 0 || buyOfferIdx >= shopOfferCount) { buyCancel(); return; }
  if (buyItemId < 0 || buyItemId >= 60) { buyCancel(); return; }
  if (buyPriceEach <= 0) { buyCancel(); return; }

  int want = MathUtils.clamp(buyAmount, 1, Math.max(1, buyMax));
  long affordable = wallet.copper / (long) buyPriceEach;
  if (affordable <= 0) {
    game.audio.sfx("audio/sfx/ui_error.wav", game.audio.sfxVolume(game.settings));
    toast = "Not enough coins";
    toastT = 3f;
    return;
  }

  boolean isTool = inv.isToolItem(buyItemId);
  long cap = isTool ? (long) inv.maxAddable(buyItemId) * (long) inv.stackMax(buyItemId) : 9_999L;
  int canBuy = (int) Math.min((long) want, Math.min(affordable, cap));
  if (canBuy <= 0) {
    game.audio.sfx("audio/sfx/ui_error.wav", game.audio.sfxVolume(game.settings));
    toast = "No space";
    toastT = 3f;
    return;
  }

  int added = inv.addPreferred(buyItemId, canBuy, buyPreferredToolArea, buyPreferredSlot);
  if (added <= 0) {
    game.audio.sfx("audio/sfx/ui_error.wav", game.audio.sfxVolume(game.settings));
    toast = "No space";
    toastT = 3f;
    return;
  }

  wallet.spendCopper((long) buyPriceEach * (long) added);
  game.audio.sfx("audio/sfx/craft.wav", game.audio.sfxVolume(game.settings));
  toast = (added == want) ? ("Bought x" + added) : ("Bought x" + added + " (full)");
  toastT = 3f;
  buyCancel();
}

private void buyHandleMouseClick(float mx, float my) {
  // popup layout (must match drawDragGhostAndBuyPopup)
  float w = 720f;
  float h = 360f;
  float x0 = (Gdx.graphics.getWidth() - w) * 0.5f;
  float y0 = (Gdx.graphics.getHeight() - h) * 0.5f;

  float btnW = 220f;
  float btnH = 72f;
  float pad = 28f;
  float buyX = x0 + w - pad - btnW;
  float buyY = y0 + pad;
  float cancelX = x0 + pad;
  float cancelY = y0 + pad;

  // qty buttons
  float qy = y0 + h * 0.5f - 28f;
  float qx = x0 + w * 0.5f - 220f;
  float smallW = 96f;
  float smallH = 64f;

  // -10, -1, +1, +10, MAX
  float b0x = qx;
  float b1x = qx + (smallW + 14f);
  float b2x = qx + 2f * (smallW + 14f);
  float b3x = qx + 3f * (smallW + 14f);
  float b4x = qx + 4f * (smallW + 14f);

  if (mx >= cancelX && mx <= cancelX + btnW && my >= cancelY && my <= cancelY + btnH) {
    game.audio.sfx("audio/sfx/ui_back.wav", game.audio.sfxVolume(game.settings));
    buyCancel();
    return;
  }
  if (mx >= buyX && mx <= buyX + btnW && my >= buyY && my <= buyY + btnH) {
    buyConfirm();
    return;
  }

  // Qty buttons (refactor: switch instead of if chain)
  if (my >= qy && my <= qy + smallH) {
    int btn = -1;
    if (mx >= b0x && mx <= b0x + smallW) btn = 0;
    else if (mx >= b1x && mx <= b1x + smallW) btn = 1;
    else if (mx >= b2x && mx <= b2x + smallW) btn = 2;
    else if (mx >= b3x && mx <= b3x + smallW) btn = 3;
    else if (mx >= b4x && mx <= b4x + smallW) btn = 4;

    if (btn >= 0) {
      switch (btn) {
        case 0 -> buySetAmount(buyAmount - 10);
        case 1 -> buySetAmount(buyAmount - 1);
        case 2 -> buySetAmount(buyAmount + 1);
        case 3 -> buySetAmount(buyAmount + 10);
        case 4 -> buySetAmount(buyMax);
        default -> { /* no-op */ }
      }
    }
  }
}

// --- SELL POPUP (mirror of buy popup, minimal logic for compile + functionality) ---

private void openSellPopup(int itemId, int src, int srcIndex) {
  if (itemId < 0) return;

  // Determine how many items are available in the dragged slot.
  int available = 0;
  if (src == DRAG_SRC_NORMINV) {
    available = inv.getNormalCount(srcIndex);
  } else if (src == DRAG_SRC_TOOLINV) {
    available = inv.getToolCount(srcIndex);
  }
  if (available <= 0) {
    game.audio.sfx("audio/sfx/ui_error.wav", game.audio.sfxVolume(game.settings));
    return;
  }

  sellPopup = true;
  sellItemId = itemId;
  sellPriceEachRaw = Math.max(1, priceBook.getBaseCopper(itemId));

  // Apply the same skill multiplier as shopSellItem() so UI matches actual payout.
  int barterLv = (SK_BARTER >= 0 && SK_BARTER < progress.skillLv.length) ? progress.skillLv[SK_BARTER] : 1;
  int negoLv = (SK_NEGOTIATION >= 0 && SK_NEGOTIATION < progress.skillLv.length) ? progress.skillLv[SK_NEGOTIATION] : 1;
  float sellMul = 1f;
  sellMul *= 1f + 0.05f * Math.max(0, barterLv - 1);
  sellMul *= 1f + 0.05f * Math.max(0, negoLv - 1);
  sellPriceEach = Math.max(1, (int) Math.floor(sellPriceEachRaw * sellMul));

  sellMax = Math.max(1, available);
  sellAmount = 1;
// Nicht fertiges Feature:   sellBuffer = String.valueOf(sellAmount);

  game.audio.sfx("audio/sfx/ui_click.wav", game.audio.sfxVolume(game.settings));
}

private void sellSetAmount(int v) {
  if (!sellPopup) return;
  v = MathUtils.clamp(v, 1, Math.max(1, sellMax));
  sellAmount = v;
// Nicht fertiges Feature:   sellBuffer = String.valueOf(v);
}

private void sellCancel() {
  sellPopup = false;
  sellItemId = -1;
  sellAmount = 1;
  sellMax = 1;
  sellPriceEach = 0;
  sellPriceEachRaw = 0;
// Nicht fertiges Feature:   sellBuffer = "";
  dragArmed = false;
  dragActive = false;
  dragSrc = DRAG_SRC_NONE;
  dragItemId = -1;
  dragIndex = -1;
}

private void sellConfirm() {
  if (!sellPopup) return;
  int want = MathUtils.clamp(sellAmount, 1, Math.max(1, sellMax));
  shopSellItem(sellItemId, sellPriceEachRaw, want);
  toast = "Sold x" + want;
  toastT = 3f;
  sellCancel();
}

private void sellHandleMouseClick(float mx, float my) {
  // popup layout (must match drawDragGhostAndBuyPopup)
  float w = 720f;
  float h = 360f;
  float x0 = (Gdx.graphics.getWidth() - w) * 0.5f;
  float y0 = (Gdx.graphics.getHeight() - h) * 0.5f;

  float btnW = 220f;
  float btnH = 72f;
  float pad = 28f;
  float okX = x0 + w - pad - btnW;
  float okY = y0 + pad;
  float cancelX = x0 + pad;
  float cancelY = y0 + pad;

  // qty buttons
  float qy = y0 + h * 0.5f - 28f;
  float qx = x0 + w * 0.5f - 220f;
  float smallW = 96f;
  float smallH = 64f;

  // -10, -1, +1, +10, MAX
  float b0x = qx;
  float b1x = qx + (smallW + 14f);
  float b2x = qx + 2f * (smallW + 14f);
  float b3x = qx + 3f * (smallW + 14f);
  float b4x = qx + 4f * (smallW + 14f);

  if (mx >= cancelX && mx <= cancelX + btnW && my >= cancelY && my <= cancelY + btnH) {
    game.audio.sfx("audio/sfx/ui_back.wav", game.audio.sfxVolume(game.settings));
    sellCancel();
    return;
  }
  if (mx >= okX && mx <= okX + btnW && my >= okY && my <= okY + btnH) {
    sellConfirm();
    return;
  }

  // Qty buttons (refactor: switch instead of if chain)
  if (my >= qy && my <= qy + smallH) {
    int btn = -1;
    if (mx >= b0x && mx <= b0x + smallW) btn = 0;
    else if (mx >= b1x && mx <= b1x + smallW) btn = 1;
    else if (mx >= b2x && mx <= b2x + smallW) btn = 2;
    else if (mx >= b3x && mx <= b3x + smallW) btn = 3;
    else if (mx >= b4x && mx <= b4x + smallW) btn = 4;

    if (btn >= 0) {
      switch (btn) {
        case 0 -> sellSetAmount(sellAmount - 10);
        case 1 -> sellSetAmount(sellAmount - 1);
        case 2 -> sellSetAmount(sellAmount + 1);
        case 3 -> sellSetAmount(sellAmount + 10);
        case 4 -> sellSetAmount(sellMax);
        default -> { /* no-op */ }
      }
    }
  }
}

private void drawDragGhostAndBuyPopup() {
  float mx = Gdx.input.getX();
  float my = uiMouseYUp();

  // Drag ghost
  if (dragActive) {
    TextureRegion icon = null;
    if (dragSrc == DRAG_SRC_BUILD) {
      EntityType[] buildTypes = {
          EntityType.BUILD_WORKBENCH,
          EntityType.BUILD_BED,
          EntityType.BUILD_CAMPFIRE,
          EntityType.BUILD_LAMP
      };
      int idx = MathUtils.clamp(dragIndex, 0, buildTypes.length - 1);
      icon = entityRegions.forEntity(buildTypes[idx], buildRot, -1, 0f, 0f, (byte)2);
    } else if (dragItemId >= 0) {
      icon = entityRegions.itemIcon(dragItemId);
    }

    if (icon != null) {
      float s = 128f;
      batch.setColor(1f, 1f, 1f, 0.85f);
      batch.draw(icon, mx - s * 0.5f, my - s * 0.5f, s, s);
      batch.setColor(1f, 1f, 1f, 1f);
    }
  }

  // Trade popup (modal)
  if (!buyPopup && !sellPopup) return;

  float w = 720f;
  float h = 360f;
  float x0 = (Gdx.graphics.getWidth() - w) * 0.5f;
  float y0 = (Gdx.graphics.getHeight() - h) * 0.5f;

  batch.setColor(1f, 1f, 1f, 1f);
  batch.draw(uiRegions.panelSlots, x0, y0, w, h);

  boolean tradeBuy = buyPopup;
  int itemId = tradeBuy ? buyItemId : sellItemId;
  int priceEach = tradeBuy ? buyPriceEach : sellPriceEach;
  int maxQty = tradeBuy ? buyMax : sellMax;
  int qty = tradeBuy ? buyAmount : sellAmount;

  String name = (itemId >= 0 && itemId < data.items.length && data.items[itemId] != null) ? data.items[itemId].name : ("item_" + itemId);

  // Header
  font.getData().setScale(1.7f);
  font.setColor(0f, 0f, 0f, 1f);
  font.draw(batch, (tradeBuy ? "BUY: " : "SELL: ") + name, x0 + 28f, y0 + h - 26f);
  font.getData().setScale(1.0f * UI_FONT_SCALE);
  font.setColor(0f, 0f, 0f, 1f);

  // Icon
  TextureRegion icon = entityRegions.itemIcon(itemId);
  if (icon != null) {
    float s = 140f;
    batch.draw(icon, x0 + 44f, y0 + h - 210f, s, s);
  }

  // Info
  font.setColor(0f, 0f, 0f, 1f);
  font.draw(batch, "Price each: " + priceEach + "c", x0 + 220f, y0 + h - 92f);
  if (tradeBuy) {
    font.draw(batch, "Max: " + maxQty + "    Wallet: " + wallet.copper + "c", x0 + 220f, y0 + h - 114f);
  } else {
    long total = (long) priceEach * (long) qty;
    font.draw(batch, "Max: " + maxQty + "    Total: +" + total + "c", x0 + 220f, y0 + h - 114f);
  }
  font.setColor(0f, 0f, 0f, 1f);

  // Quantity display
  font.getData().setScale(1.6f);
  font.setColor(0f, 0f, 0f, 1f);
  font.draw(batch, "QTY: " + qty, x0 + w * 0.5f - 72f, y0 + h * 0.62f);
  font.getData().setScale(1.0f * UI_FONT_SCALE);
  font.setColor(0f, 0f, 0f, 1f);

  // Buttons
  boolean lmbDown = Gdx.input.isButtonPressed(Input.Buttons.LEFT);

  float btnW = 220f;
  float btnH = 72f;
  float pad = 28f;
  float okX = x0 + w - pad - btnW;
  float okY = y0 + pad;
  float cancelX = x0 + pad;
  float cancelY = y0 + pad;

  boolean hoverOk = mx >= okX && mx <= okX + btnW && my >= okY && my <= okY + btnH;
  boolean hoverCancel = mx >= cancelX && mx <= cancelX + btnW && my >= cancelY && my <= cancelY + btnH;

  batch.draw((hoverCancel && lmbDown) ? uiRegions.buttonPressed : uiRegions.button, cancelX, cancelY, btnW, btnH);
  batch.draw((hoverOk && lmbDown) ? uiRegions.buttonPressed : uiRegions.button, okX, okY, btnW, btnH);

  font.setColor(0f, 0f, 0f, 1f);
  font.getData().setScale(1.3f);
  font.draw(batch, "CANCEL", cancelX + 48f, cancelY + 48f);
  font.draw(batch, tradeBuy ? "BUY" : "SELL", okX + 78f, okY + 48f);
  font.getData().setScale(1.0f * UI_FONT_SCALE);
  font.setColor(0f, 0f, 0f, 1f);

  // Qty +/- buttons
  float qy = y0 + h * 0.5f - 28f;
  float qx = x0 + w * 0.5f - 220f;
  float smallW = 96f;
  float smallH = 64f;
  float gap = 14f;

  String[] labs = {"-10", "-1", "+1", "+10", "MAX"};
  for (int i = 0; i < 5; i++) {
    float bx = qx + i * (smallW + gap);
    boolean hov = mx >= bx && mx <= bx + smallW && my >= qy && my <= qy + smallH;
    batch.draw((hov && lmbDown) ? uiRegions.buttonPressed : uiRegions.button, bx, qy, smallW, smallH);
    font.setColor(0f, 0f, 0f, 1f);
    font.getData().setScale(1.05f);
    font.draw(batch, labs[i], bx + 22f, qy + 42f);
    font.getData().setScale(1.0f * UI_FONT_SCALE);
    font.setColor(0f, 0f, 0f, 1f);
  }

}


private void craftByOutput(int outItemId) {
    com.yourgame.survival.data.RecipeDef r = craft.findByOutput(data.recipes, outItemId);
    if (r == null) return;
    craft.craft(inv, r);
  }

  // Nicht fertiges Feature: commented out unused method
  /*
  private void drawCraftLines(float x, float y) {
    // legacy text renderer (still used inside the craft panel)
    int[] outs = {40, 14, 15};
    for (int i=0;i<outs.length;i++) {
      com.yourgame.survival.data.RecipeDef r = craft.findByOutput(data.recipes, outs[i]);
      if (r == null) continue;
      String name = (data.items[r.outItemId] != null) ? data.items[r.outItemId].name : ("item_" + r.outItemId);
      StringBuilder req = new StringBuilder();
      for (int k=0;k<r.inItemId.length;k++) {
        int id = r.inItemId[k];
        String inName = (data.items[id] != null) ? data.items[id].name : ("item_"+id);
        if (k>0) req.append(", ");
        req.append(inName).append("x").append(r.inAmount[k]);
      }
      boolean ok = craft.canCraft(inv, r);
      font.draw(batch, (i+1) + ") " + name + (ok?" [OK] ":" [NO] ") + "<= " + req, x, y - i*22f);
    }
  }
  */

  private static boolean rectsOverlap(float ax, float ay, float aw, float ah, float bx, float by, float bw, float bh, float pad) {
    float aL = ax - pad, aR = ax + aw + pad;
    float aB = ay - pad, aT = ay + ah + pad;
    float bL = bx - pad, bR = bx + bw + pad;
    float bB = by - pad, bT = by + bh + pad;
    return (aL < bR && aR > bL && aB < bT && aT > bB);
  }

  private void placePanelAvoiding(float panelW, float panelH, float prefX, float prefY,
                                 float avoidX, float avoidY, float avoidW, float avoidH,
                                 java.util.function.BiConsumer<Float, Float> out) {
    float w = Gdx.graphics.getWidth();
    float h = Gdx.graphics.getHeight();

    // If preferred spot is fine, keep it.
    float x0 = MathUtils.clamp(prefX, 0f, Math.max(0f, w - panelW));
    float y0 = MathUtils.clamp(prefY, 0f, Math.max(0f, h - panelH));
    if (!rectsOverlap(x0, y0, panelW, panelH, avoidX, avoidY, avoidW, avoidH, 8f)) {
      out.accept(x0, y0);
      return;
    }

    // Search a grid of candidate positions and pick the closest that doesn't overlap.
    float step = 40f;
    float bestD2 = Float.POSITIVE_INFINITY;
    float bestX = x0, bestY = y0;

    for (float yy = 0f; yy <= h - panelH; yy += step) {
      for (float xx = 0f; xx <= w - panelW; xx += step) {
        if (rectsOverlap(xx, yy, panelW, panelH, avoidX, avoidY, avoidW, avoidH, 8f)) continue;
        float dx = xx - x0;
        float dy = yy - y0;
        float d2 = dx * dx + dy * dy;
        if (d2 < bestD2) { bestD2 = d2; bestX = xx; bestY = yy; }
      }
    }

    out.accept(bestX, bestY);
  }

  private void ensurePanelAnchor(float panelW, float panelH, boolean forBuild, boolean forCraft, boolean forChest) {
    float w = Gdx.graphics.getWidth();
    float h = Gdx.graphics.getHeight();

    // Pick different default spots per panel.
    float baseX = forBuild ? w * 0.06f : (forCraft ? w * 0.60f : w * 0.08f);
    float baseY = forBuild ? h * 0.62f : (forCraft ? h * 0.62f : h * 0.18f);

    // Small random-ish jitter (so panels don't stack perfectly). Deterministic enough per run.
    float jx = (float) ((Math.random() - 0.5) * 80.0);
    float jy = (float) ((Math.random() - 0.5) * 60.0);

    float x0 = MathUtils.clamp(baseX + jx, 0f, Math.max(0f, w - panelW));
    float y0 = MathUtils.clamp(baseY + jy, 0f, Math.max(0f, h - panelH));

    if (forBuild) {
      if (Float.isNaN(buildAnchorX) || Float.isNaN(buildAnchorY)) { buildAnchorX = x0; buildAnchorY = y0; }
    }
    if (forCraft) {
      if (Float.isNaN(craftAnchorX) || Float.isNaN(craftAnchorY)) { craftAnchorX = x0; craftAnchorY = y0; }
    }
    if (forChest) {
      if (Float.isNaN(chestAnchorX) || Float.isNaN(chestAnchorY)) { chestAnchorX = x0; chestAnchorY = y0; }
    }
  }

  private void handlePanelDrag(boolean want, float[] axay, boolean[] dragFlag, float[] dragDxDy, float panelW, float panelH, float headerH) {
    if (!want) {
      dragFlag[0] = false;
      return;
    }

    float mx = Gdx.input.getX();
    float my = uiMouseYUp();

    // start drag if just touched in header
    if (!dragFlag[0] && Gdx.input.justTouched()) {
      float x0 = axay[0];
      float y0 = axay[1];
      if (mx >= x0 && mx <= x0 + panelW && my >= y0 + panelH - headerH && my <= y0 + panelH) {
        dragFlag[0] = true;
        dragDxDy[0] = mx - x0;
        dragDxDy[1] = my - y0;
      }
    }

    // stop drag on release
    if (dragFlag[0] && !Gdx.input.isButtonPressed(Input.Buttons.LEFT)) {
      dragFlag[0] = false;
    }

    // update
    if (dragFlag[0]) {
      float w = Gdx.graphics.getWidth();
      float h = Gdx.graphics.getHeight();
      axay[0] = MathUtils.clamp(mx - dragDxDy[0], 0f, Math.max(0f, w - panelW));
      axay[1] = MathUtils.clamp(my - dragDxDy[1], 0f, Math.max(0f, h - panelH));
    }
  }

  private static boolean hitRect(float px, float py, float x, float y, float w, float h) {
    return px >= x && px <= x + w && py >= y && py <= y + h;
  }

  private int buildHitSlot(float mx, float my) {
    if (!buildMode) return -1;
    if (!buildLayoutValid) return -1;
    for (int i = 0; i < buildSlotsCount; i++) {
      float sx = buildSlotsX0 + i * (buildSlotPx + buildPadPx);
      float sy = buildSlotsY0;
      if (hitRect(mx, my, sx, sy, buildSlotPx, buildSlotPx)) return i;
    }
    return -1;
  }

  private void drawBuildPanel() {
    float panelW = 560f;
    float panelH = 360f;
    float headerH = 70f;

    ensurePanelAnchor(panelW, panelH, true, false, false);

    float[] axay = new float[]{buildAnchorX, buildAnchorY};
    boolean[] d = new boolean[]{buildDrag};
    float[] dd = new float[]{buildDragDx, buildDragDy};
    handlePanelDrag(true, axay, d, dd, panelW, panelH, headerH);
    buildAnchorX = axay[0]; buildAnchorY = axay[1];
    buildDrag = d[0]; buildDragDx = dd[0]; buildDragDy = dd[1];

    float x0 = buildAnchorX;
    float y0 = buildAnchorY;

    batch.setColor(1f,1f,1f,1f);
    batch.draw(uiRegions.panelSlots, x0, y0, panelW, panelH);

    font.setColor(0f,0f,0f,1f);
    font.getData().setScale(1.45f * UI_FONT_SCALE);
    font.draw(batch, "BUILD MODE", x0 + 28f, y0 + panelH - 24f);

    font.getData().setScale(1.05f * UI_FONT_SCALE);
    font.draw(batch, "B toggle | Drag icon to world = build | Q/E rotate | Shift+RMB remove", x0 + 28f, y0 + panelH - 56f);

    // Icon row (draggable)
    float slot = 92f;
    float pad = 16f;
    float sx0 = x0 + 28f;
    float sy0 = y0 + panelH - 170f;

    // cache for drag hit-tests
    buildLayoutValid = true;
    buildPanelX0 = x0;
    buildPanelY0 = y0;
    buildPanelW = panelW;
    buildPanelH = panelH;
    buildSlotsX0 = sx0;
    buildSlotsY0 = sy0;
    buildSlotPx = slot;
    buildPadPx = pad;

    EntityType[] buildTypes = {
        EntityType.BUILD_WORKBENCH,
        EntityType.BUILD_BED,
        EntityType.BUILD_CAMPFIRE,
        EntityType.BUILD_LAMP
    };

    // NOTE: selection is via drag (no click-to-select)

    buildSlotsCount = buildTypes.length;

    for (int i = 0; i < buildTypes.length; i++) {
      float sx = sx0 + i * (slot + pad);
      float sy = sy0;
      boolean selected = (i == buildSel);
      batch.setColor(1f, 1f, 1f, 1f);
      batch.draw(selected ? uiRegions.slotPressed : uiRegions.slot, sx, sy, slot, slot);

      TextureRegion icon = entityRegions.forEntity(buildTypes[i], 0f, -1, 0f, 0f, (byte)2);
      if (icon != null) {
        float iw = slot * 0.74f;
        float ih = slot * 0.74f;
        batch.draw(icon, sx + (slot - iw) * 0.5f, sy + (slot - ih) * 0.5f, iw, ih);
      }

      // Drag-only selection (handled in uiHandleDragDropAndPopup)
    }

    // Rotation + rule (still text, but now inside panel and large/black)
    font.getData().setScale(1.0f * UI_FONT_SCALE);
    font.draw(batch, "Rotation: " + (int) buildRot + "°", x0 + 28f, y0 + 120f);
    font.draw(batch, "Rule: cannot place on water.", x0 + 28f, y0 + 92f);
  }

  private void drawCraftPanel() {
    // Craft panel
    float panelW = 1230f;
    float panelH = 540f;
    float headerH = 70f;

    ensurePanelAnchor(panelW, panelH, false, true, false);

    float[] axay = new float[]{craftAnchorX, craftAnchorY};
    boolean[] d = new boolean[]{craftDrag};
    float[] dd = new float[]{craftDragDx, craftDragDy};
    handlePanelDrag(true, axay, d, dd, panelW, panelH, headerH);
    craftAnchorX = axay[0]; craftAnchorY = axay[1];
    craftDrag = d[0]; craftDragDx = dd[0]; craftDragDy = dd[1];

    float x0 = craftAnchorX;
    float y0 = craftAnchorY;

    // base panel
    batch.setColor(1f, 1f, 1f, 1f);
    batch.draw(uiRegions.panelSlots, x0, y0, panelW, panelH);

    // title
    font.setColor(0f, 0f, 0f, 1f);
    font.getData().setScale(1.55f * UI_FONT_SCALE);
    font.draw(batch, "CRAFT", x0 + 28f, y0 + panelH - 24f);

    font.getData().setScale(1.05f * UI_FONT_SCALE);
    font.draw(batch, "Scroll wheel = list | Click qty box to type | Click 'Jetzt craften'", x0 + 28f, y0 + panelH - 56f);

    // recipe grid
    float slot = 108f;
    float pad = 22f;
    int cols = 5;

    float listX0 = x0 + 28f;
    float listTopY = y0 + panelH - 110f; // top baseline

    float mx = Gdx.input.getX();
    float my = uiMouseYUp();

    // Only handle interaction when cursor is inside the craft panel.
    boolean click = Gdx.input.justTouched() && hitRect(mx, my, x0, y0, panelW, panelH);

    // Clip drawing + interaction to list area so background and interactive area match.
    float clipX = x0 + 18f;
    float clipY = y0 + 18f;
    float clipW = panelW - 36f;
    float clipH = panelH - (headerH + 28f);
    Rectangle clip = scratch.r0;
    clip.set(clipX, clipY, clipW, clipH);
    Rectangle scissors = scratch.r1;
    ScissorStack.calculateScissors(uiCam, batch.getTransformMatrix(), clip, scissors);
    batch.flush();
    ScissorStack.pushScissors(scissors);

    craftHoverIdx = -1;

    int n = data.recipes.size();
    if (craftQtyByRecipe == null || craftQtyByRecipe.length != n) {
      craftQtyByRecipe = new int[n];
      for (int i = 0; i < n; i++) craftQtyByRecipe[i] = 1;
      craftQtyFocusIdx = -1;
      craftQtyBuffer = "1";
    }

    float rowH = slot + 56f + pad; // slot + qty/button row + pad

    // clamp scroll
    int rows = (int) Math.ceil(n / (double) cols);
    float visibleH = panelH - 150f;
    float contentH = rows * rowH;
    float maxScroll = Math.max(0f, contentH - visibleH);
    craftScroll = MathUtils.clamp(craftScroll, 0f, maxScroll);

    // draw items
    int idx = 0;
    for (int r = 0; r < rows; r++) {
      float baseY = listTopY - r * rowH + craftScroll;

      // skip rows far outside
      if (baseY < y0 - 220f) { idx += cols; continue; }
      if (baseY > y0 + panelH + 220f) { idx += cols; continue; }

      for (int c = 0; c < cols && idx < n; c++, idx++) {
        var rec = data.recipes.get(idx);
        int outId = rec.outItemId;

        float sx = listX0 + c * (slot + pad);
        float sy = baseY - slot;

        boolean can1 = craft.canCraft(inv, rec);

        // slot bg
        batch.setColor(1f, 1f, 1f, 1f);
        batch.draw(uiRegions.slot, sx, sy, slot, slot);

        // output icon (dark if cannot craft)
        TextureRegion icon = entityRegions.itemIcon(outId);
        if (!can1) batch.setColor(1f, 1f, 1f, 0.30f);
        if (icon != null) {
          float iw = slot * 0.78f;
          float ih = slot * 0.78f;
          batch.draw(icon, sx + (slot - iw) * 0.5f, sy + (slot - ih) * 0.5f, iw, ih);
        }
        batch.setColor(1f, 1f, 1f, 1f);

        // hover detection
        boolean overIcon = hitRect(mx, my, sx, sy, slot, slot);
        if (overIcon) craftHoverIdx = idx;

        // qty box under icon
        float qx = sx;
        float qy = sy - 44f;
        float qw = slot * 0.58f;
        float qh = 40f;
        batch.draw((craftQtyFocusIdx == idx) ? uiRegions.slotPressed : uiRegions.slot, qx, qy, qw, qh);

        // qty text
        int qv = (idx >= 0 && idx < craftQtyByRecipe.length) ? craftQtyByRecipe[idx] : 1;
        font.setColor(0f, 0f, 0f, 1f);
        font.getData().setScale(0.95f * UI_FONT_SCALE);
        font.draw(batch, String.valueOf(qv), qx + 12f, qy + 28f);

        // craft button
        float bx = qx + qw + 10f;
        float by = qy;
        float bw = slot - (qw + 10f);
        float bh = qh;

        boolean canSome = can1; // gate button visibility
        if (!canSome) batch.setColor(1f, 1f, 1f, 0.35f);
        batch.draw(uiRegions.button, bx, by, bw, bh);
        batch.setColor(1f, 1f, 1f, 1f);

        font.setColor(0f, 0f, 0f, 1f);
        font.getData().setScale(0.85f * UI_FONT_SCALE);
        font.draw(batch, "Jetzt", bx + 10f, by + 26f);

        // click interactions (only when inside list clip)
        boolean inList = hitRect(mx, my, clipX, clipY, clipW, clipH);
        if (click && inList) {
          if (hitRect(mx, my, qx, qy, qw, qh)) {
            craftQtyFocusIdx = idx;
            craftQtyBuffer = String.valueOf(Math.max(0, qv));
            // IMPORTANT: never early-return while a scissor is pushed (would freeze the viewport/clip).
            // Consume click so it can't also trigger crafting in the same frame.
            click = false;
            continue;
          }

          if (hitRect(mx, my, bx, by, bw, bh)) {
            int want = (idx >= 0 && idx < craftQtyByRecipe.length) ? craftQtyByRecipe[idx] : 1;
            want = MathUtils.clamp(want, 1, 99999);
            int made = 0;
            for (int k = 0; k < want; k++) {
              if (!craft.craft(inv, rec)) break;
              made++;
            }
            if (made > 0) game.audio.sfx("audio/sfx/craft.wav", game.audio.sfxVolume(game.settings));
            else game.audio.sfx("audio/sfx/ui_error.wav", game.audio.sfxVolume(game.settings));
          }
        }
      }
    }

    batch.flush();
    ScissorStack.popScissors();

    // Hover requirements panel (icons only) + tooltips
    if (craftHoverIdx >= 0 && craftHoverIdx < data.recipes.size()) {
      var rec = data.recipes.get(craftHoverIdx);
      float reqW = 520f;
      float reqH = 150f;
      float rx0 = MathUtils.clamp(x0 + 24f, 0f, Math.max(0f, Gdx.graphics.getWidth() - reqW));
      float ry0 = MathUtils.clamp(y0 + panelH + 10f, 0f, Math.max(0f, Gdx.graphics.getHeight() - reqH));

      batch.setColor(1f, 1f, 1f, 1f);
      batch.draw(uiRegions.panelSlots, rx0, ry0, reqW, reqH);

      float is = 72f;
      float ip = 14f;
      float ix0 = rx0 + 22f;
      float iy0 = ry0 + reqH - 22f - is;

      // Track tooltip
      int tipItemId = -1;

      // output icon
      int outId = rec.outItemId;
      batch.draw(uiRegions.slotPressed, ix0, iy0, is, is);
      TextureRegion outIcon = entityRegions.itemIcon(outId);
      if (outIcon != null) {
        float iw = is * 0.78f;
        float ih = is * 0.78f;
        batch.draw(outIcon, ix0 + (is - iw) * 0.5f, iy0 + (is - ih) * 0.5f, iw, ih);
      }
      if (hitRect(mx, my, ix0, iy0, is, is)) tipItemId = outId;

      // arrow-ish separator
      font.setColor(0f, 0f, 0f, 1f);
      font.getData().setScale(1.2f * UI_FONT_SCALE);
      font.draw(batch, "=>", ix0 + is + 14f, iy0 + 50f);

      float inX = ix0 + is + 60f;
      for (int k = 0; k < rec.inItemId.length; k++) {
        int inId = rec.inItemId[k];
        int need = rec.inAmount[k];
        float sx = inX + k * (is + ip);
        float sy = iy0;

        batch.setColor(1f, 1f, 1f, 1f);
        batch.draw(uiRegions.slot, sx, sy, is, is);
        TextureRegion ic = entityRegions.itemIcon(inId);
        if (ic != null) {
          float iw = is * 0.78f;
          float ih = is * 0.78f;
          batch.draw(ic, sx + (is - iw) * 0.5f, sy + (is - ih) * 0.5f, iw, ih);
        }

        // count overlay (number only)
        font.setColor(0f, 0f, 0f, 1f);
        font.getData().setScale(0.95f * UI_FONT_SCALE);
        font.draw(batch, String.valueOf(need), sx + 8f, sy + 22f);

        if (hitRect(mx, my, sx, sy, is, is)) tipItemId = inId;
      }

      // Tooltip for item name (screen name)
      if (tipItemId >= 0 && tipItemId < data.items.length && data.items[tipItemId] != null) {
        String nm = data.items[tipItemId].name;
        float tw = 380f;
        float th = 56f;
        float tx = MathUtils.clamp(mx + 18f, 0f, Math.max(0f, Gdx.graphics.getWidth() - tw));
        float ty = MathUtils.clamp(my + 18f, 0f, Math.max(0f, Gdx.graphics.getHeight() - th));
        batch.setColor(1f, 1f, 1f, 1f);
        batch.draw(uiRegions.panel, tx, ty, tw, th);
        font.setColor(0f, 0f, 0f, 1f);
        font.getData().setScale(1.0f * UI_FONT_SCALE);
        font.draw(batch, nm, tx + 16f, ty + 36f);
      }
    }
  }

  private void drawChestPanel() {
    float panelW = 760f;
    float panelH = 320f;
    float headerH = 70f;

    ensurePanelAnchor(panelW, panelH, false, false, true);

    float[] axay = new float[]{chestAnchorX, chestAnchorY};
    boolean[] d = new boolean[]{chestDrag};
    float[] dd = new float[]{chestDragDx, chestDragDy};
    handlePanelDrag(true, axay, d, dd, panelW, panelH, headerH);
    chestAnchorX = axay[0]; chestAnchorY = axay[1];
    chestDrag = d[0]; chestDragDx = dd[0]; chestDragDy = dd[1];

    float x0 = chestAnchorX;
    float y0 = chestAnchorY;

    batch.setColor(1f,1f,1f,1f);
    batch.draw(uiRegions.panelSlots, x0, y0, panelW, panelH);

    font.setColor(0f,0f,0f,1f);
    font.getData().setScale(1.45f * UI_FONT_SCALE);
    font.draw(batch, "CHEST", x0 + 28f, y0 + panelH - 24f);

    font.getData().setScale(1.05f * UI_FONT_SCALE);
    font.draw(batch, "Click slots to transfer (Shift x10 | Ctrl x100) | E close | F take-all", x0 + 28f, y0 + panelH - 56f);

    if (openChestE < 0) return;
    int idx = entities.data0[openChestE];
    com.yourgame.survival.data.Inventory chest = chestStore.get(idx);
    if (chest == null) {
      font.getData().setScale(1.0f * UI_FONT_SCALE);
      font.draw(batch, "(broken chest)", x0 + 28f, y0 + panelH - 92f);
      return;
    }

    int amount = 1;
    boolean ctrl = Gdx.input.isKeyPressed(Input.Keys.CONTROL_LEFT) || Gdx.input.isKeyPressed(Input.Keys.CONTROL_RIGHT);
    boolean shift = Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT) || Gdx.input.isKeyPressed(Input.Keys.SHIFT_RIGHT);
    if (shift) amount = 10;
    if (ctrl) amount = 100;

    // Tracked resources/items for chests (includes POI Hidden Chest loot).
    // NOTE: kept fixed for UI simplicity (no scroll list yet).
    int[] ids = {0, 1, 2, 47, 31, 33, 20};
    String[] labels = {"Wood", "Stone", "Iron", "Arrows", "Copper", "Gold", "Sword"};

    float slot = 96f;
    float pad = 18f;
    float colGap = 70f;

    float leftX = x0 + 40f;
    float topY = y0 + panelH - 170f;

    // Column headers
    font.setColor(0f, 0f, 0f, 1f);
    font.getData().setScale(1.1f * UI_FONT_SCALE);
    font.draw(batch, "PLAYER", leftX, topY + 126f);
    font.draw(batch, "CHEST", leftX + slot + colGap, topY + 126f);

    float mx = Gdx.input.getX();
    float my = uiMouseYUp();
    boolean click = Gdx.input.justTouched();

    for (int i = 0; i < ids.length; i++) {
      int itemId = ids[i];
      float rowY = topY - i * (slot + pad);

      // Player slot
      float pxs = leftX;
      float pys = rowY;
      batch.setColor(1f, 1f, 1f, 1f);
      batch.draw(uiRegions.slot, pxs, pys, slot, slot);
      TextureRegion icon = entityRegions.itemIcon(itemId);
      if (icon != null) {
        float iw = slot * 0.76f;
        float ih = slot * 0.76f;
        batch.draw(icon, pxs + (slot - iw) * 0.5f, pys + (slot - ih) * 0.5f, iw, ih);
      }

      // Chest slot
      float cxs = leftX + slot + colGap;
      float cys = rowY;
      batch.setColor(1f, 1f, 1f, 1f);
      batch.draw(uiRegions.slot, cxs, cys, slot, slot);
      if (icon != null) {
        float iw = slot * 0.76f;
        float ih = slot * 0.76f;
        batch.draw(icon, cxs + (slot - iw) * 0.5f, cys + (slot - ih) * 0.5f, iw, ih);
      }

      // Counts + label
      font.setColor(0f, 0f, 0f, 1f);
      font.getData().setScale(1.0f * UI_FONT_SCALE);
      font.draw(batch, labels[i], leftX + slot * 2f + colGap + 18f, rowY + 66f);
      font.draw(batch, String.valueOf(inv.countsById[itemId]), pxs + 10f, pys + 22f);
      font.draw(batch, String.valueOf(chest.countsById[itemId]), cxs + 10f, cys + 22f);

      if (click) {
        // Click player slot => move to chest
        if (hitRect(mx, my, pxs, pys, slot, slot)) {
          int have = inv.countsById[itemId];
          int a = Math.min(amount, have);
          if (a > 0 && inv.spend(itemId, a)) {
            chest.add(itemId, a);
            game.audio.sfx("audio/sfx/ui_click.wav", game.audio.sfxVolume(game.settings));
          } else {
            game.audio.sfx("audio/sfx/ui_error.wav", game.audio.sfxVolume(game.settings));
          }
        }
        // Click chest slot => move to player
        if (hitRect(mx, my, cxs, cys, slot, slot)) {
          int have = chest.countsById[itemId];
          int a = Math.min(amount, have);
          if (a > 0 && chest.spend(itemId, a)) {
            inv.add(itemId, a);
            game.audio.sfx("audio/sfx/ui_click.wav", game.audio.sfxVolume(game.settings));
          } else {
            game.audio.sfx("audio/sfx/ui_error.wav", game.audio.sfxVolume(game.settings));
          }
        }
      }
    }

    // POI Hidden Chest: if empty after transfers, remove permanently.
    if (openChestE >= 0 && entities.alive[openChestE] && entities.type[openChestE] == EntityType.POI_CHEST_HIDDEN) {
      boolean empty = true;
      for (int id = 0; id < chest.countsById.length; id++) {
        if (chest.countsById[id] > 0) { empty = false; break; }
      }
      if (empty) {
        // Mark consumed and remove the entity so it never comes back.
        String tid = (worldMap != null) ? worldMap.curTemplateId : "";
        int tx = (int) Math.floor(entities.x[openChestE] / World.TILE_WORLD);
        int ty = (int) Math.floor(entities.y[openChestE] / World.TILE_WORLD);
        String key = tid + "|HIDDEN_CHEST|" + tx + "|" + ty;
        if (worldMap != null) worldMap.consumedPois.add(key);
        entities.kill(openChestE);
        openChestE = -1;
        toast = "Die Truhe verschwindet...";
        toastT = 15f;
      }
    }
  }

  private void drawStatsPanel() {
    // Compact stat panel (bottom-left). UI elements only.
    float pad = 16f;
    float x0 = 18f;
    float y0 = 18f + 144f + 18f; // keep clear of hotbar

    // Requested: 4x wider and half as high.
    float barW = Math.min(1120f, Gdx.graphics.getWidth() - 40f);
    float barH = 20f;
    float gap = 8f;

    float panelW = barW + pad * 2f;
    float panelH = (barH * 5f) + (gap * 4f) + pad * 2f;

    // Requested: background only 5% wider on both sides
    float bgExtra = panelW * 0.05f;
    batch.setColor(1f, 1f, 1f, 1f);
    batch.draw(uiRegions.panelSlots, x0 - bgExtra, y0, panelW + bgExtra * 2f, panelH);

    float x = x0 + pad;
    float y = y0 + panelH - pad - barH;

    // Bars: solid color. Names BEFORE numbers.
    // Colors: HP red, Ausdauer yellow, Mana blue, Hunger green, Müdigkeit dark blue.
    drawStatBarSolid("HP", x, y, barW, barH, 0.90f, 0.20f, 0.20f, needs.hp, needs.hpMax);
    y -= (barH + gap);
    drawStatBarSolid("Ausdauer", x, y, barW, barH, 0.95f, 0.90f, 0.20f, needs.stamina, needs.staminaMax);
    y -= (barH + gap);
    drawStatBarSolid("Mana", x, y, barW, barH, 0.20f, 0.45f, 0.95f, needs.mana, needs.manaMax);
    y -= (barH + gap);
    drawStatBarSolid("Hunger", x, y, barW, barH, 0.20f, 0.80f, 0.25f, needs.hunger, needs.hungerMax);
    y -= (barH + gap);
    drawStatBarSolid("Muedigkeit", x, y, barW, barH, 0.12f, 0.20f, 0.55f, needs.sleep, needs.sleepMax);

    batch.setColor(1f, 1f, 1f, 1f);
  }

  private void drawStatBarSolid(String name, float x, float y, float w, float h, float r, float g, float b, float v, float vmax) {
    // Frame/background
    batch.setColor(0f, 0f, 0f, 0.55f);
    batch.draw(renderPipeline.white, x, y, w, h);

    // Fill
    float ratio = (vmax <= 1e-6f) ? 0f : MathUtils.clamp(v / vmax, 0f, 1f);
    if (ratio > 0f) {
      batch.setColor(r, g, b, 0.95f);
      batch.draw(renderPipeline.white, x + 2f, y + 2f, Math.max(0f, (w - 4f) * ratio), Math.max(0f, h - 4f));
    }

    // Border
    batch.setColor(0f, 0f, 0f, 0.85f);
    batch.draw(renderPipeline.white, x, y, w, 2f);
    batch.draw(renderPipeline.white, x, y + h - 2f, w, 2f);
    batch.draw(renderPipeline.white, x, y, 2f, h);
    batch.draw(renderPipeline.white, x + w - 2f, y, 2f, h);

    // black text inside: NAME before numbers
    font.setColor(0f, 0f, 0f, 1f);
    font.getData().setScale(0.95f * UI_FONT_SCALE);
    String s = name + ": " + ((int) Math.ceil(v)) + "/" + ((int) Math.ceil(vmax));
    font.draw(batch, s, x + 10f, y + h * 0.75f);
    font.setColor(0f, 0f, 0f, 1f);

    batch.setColor(1f, 1f, 1f, 1f);
  }

  private void drawHotbarHud() {
    // Bottom anchored HUD: slot icons + selection frame.
    float slot = 144f;
    float pad = 18f;

    float barW = hotbar.length * slot + (hotbar.length - 1) * pad;

    float x0 = (Gdx.graphics.getWidth() - barW) * 0.5f;
    float y0 = 0f; // bottom edge flush with screen bottom

    // cache for hit-tests
    hotbarX0 = x0;
    hotbarY0 = y0;
    hotbarSlotPx = slot;
    hotbarPadPx = pad;
// Nicht fertiges Feature:     hotbarLayoutValid = true;

    for (int i=0;i<hotbar.length;i++) {
      float sx = x0 + i * (slot + pad);
      float sy = y0;

      boolean selected = (i == hotbarSel);
      batch.draw(selected ? uiRegions.slotPressed : uiRegions.slot, sx, sy, slot, slot);

      int id = hotbar[i];
      if (id >= 0) {
        TextureRegion icon = entityRegions.itemIcon(id);
        float iw = slot * 0.72f;
        float ih = slot * 0.72f;
        boolean owned = inv.hasItem(id);
        if (!owned) batch.setColor(1f, 1f, 1f, 0.35f);
        if (icon != null) batch.draw(icon, sx + (slot - iw) * 0.5f, sy + (slot - ih) * 0.5f, iw, ih);
        if (!owned) batch.setColor(1f, 1f, 1f, 1f);
      }
    }
  }

  // Nicht fertiges Feature: commented out unused method
  /*
  private void drawInventoryLines(float x, float y) {
    // legacy (unused) - kept for quick debug
    int shown = 0;
    for (int id=0; id<inv.countsById.length; id++) {
      int c = inv.countsById[id];
      if (c <= 0) continue;
      String name = (data.items[id] != null) ? data.items[id].name : ("item_"+id);
      font.draw(batch, name + ": " + c, x, y - shown*18);
      shown++;
      if (shown >= 12) break;
    }
    if (shown == 0) font.draw(batch, "(empty)", x, y);
  }
  */

  // Nicht fertiges Feature: commented out unused method
  /*
  private void drawBuildLines(float x, float y) {
    String[] names = {"Workbench","Bed","Campfire","Lamp"};
    for (int i=0;i<names.length;i++) {
      String sel = (i == buildSel) ? ">" : " ";
      font.draw(batch, sel + (i+1) + ") " + names[i] + " rot=" + (int)buildRot, x, y - i*18);
    }
    font.draw(batch, "Placement rule: not on water.", x, y - names.length*18 - 10);
  }
  */

  private void placeBuildAtMouse(float wx, float wy) {
    if (!building.canPlace(world, wx, wy)) return;

    EntityType t = switch (buildSel) {
      case 0 -> EntityType.BUILD_WORKBENCH;
      case 1 -> EntityType.BUILD_BED;
      case 2 -> EntityType.BUILD_CAMPFIRE;
      case 3 -> EntityType.BUILD_LAMP;
      default -> EntityType.BUILD_WORKBENCH;
    };

    // Local build placement
    building.place(entities, t, wx, wy, buildRot, -1);
    game.audio.sfx("audio/sfx/place.wav", game.audio.sfxVolume(game.settings));
  }

  // Nicht fertiges Feature: commented out unused method
  /*
  private void drawChestLines(float x, float y) {
    if (openChestE < 0) return;
    int idx = entities.data0[openChestE];
    com.yourgame.survival.data.Inventory chest = chestStore.get(idx);
    if (chest == null) {
      font.draw(batch, "(broken chest)", x, y);
      return;
    }

    font.draw(batch, "Player wood=" + inv.countsById[0] + " stone=" + inv.countsById[1] + " coins=" + inv.countsById[31], x, y);
    font.draw(batch, "Chest  wood=" + chest.countsById[0] + " stone=" + chest.countsById[1] + " coins=" + chest.countsById[31], x, y - 18);
  }
  */

  private void chestStoreFromPlayer(int itemId, int amount) {
    if (openChestE < 0) return;
    int idx = entities.data0[openChestE];
    com.yourgame.survival.data.Inventory chest = chestStore.get(idx);
    if (chest == null) return;

    int have = inv.hasItem(itemId) ? inv.countsById[itemId] : 0;
    int a = Math.min(amount, have);
    if (a <= 0) return;
    if (!inv.spend(itemId, a)) return;
    chest.add(itemId, a);
  }

  private void chestTakeAll() {
    if (openChestE < 0) return;
    int idx = entities.data0[openChestE];
    com.yourgame.survival.data.Inventory chest = chestStore.get(idx);
    if (chest == null) return;

    for (int id=0; id<chest.countsById.length; id++) {
      int c = chest.countsById[id];
      if (c <= 0) continue;
      inv.add(id, c);
      chest.spend(id, c);
    }
  }

  private int randRange(int a, int b) {
    if (b < a) b = a;
    return a + (int)Math.floor(Math.random() * (b - a + 1));
  }

  /**
   * Debug-only travel trigger for the new WorldMap system.
   *
   * IMPORTANT:
   * - This is scaffolding. Final travel will be automatic at exits/edges or via WorldMap UI.
   * - The loader currently used is {@code NoopAreaWorldLoader}, so this does NOT modify the current
   *   procedural world. It only mutates {@link com.yourgame.survival.worldmap.WorldMapState}.
   *
   * Why keep it in GameScreen?
   * - We already have an input loop here and a toast system.
   * - This lets us quickly verify: save->load preserves knownAreas/frontier/edges.
   */
  private void debugWorldMapTravel(com.yourgame.survival.worldmap.Dir4 dir) {
    try {
      // Seed choice:
      // - We use worldSeed because it's already per-save and stored in saves.
      // - Later we may introduce a dedicated mapSeed, but worldSeed is fine for alpha.
      long seed = worldSeed;

      // Store "war stand" for the area we are leaving.
      areaOnLeaveCurrent();

      com.yourgame.survival.worldmap.AreaTravelResult r = worldMapTravel.travel(this, worldMap, dir, seed);
      if (r == null) {
        toast = "WorldMap travel: ???";
        toastT = 2.0f;
        return;
      }

      // Human-readable debug feedback.
      // We keep it short because it may be used frequently.
      switch (r.code) {
        case OK -> {
          // Alpha exits: all sides are exits for now.
          com.yourgame.survival.worldmap.AreaCoord c1 = new com.yourgame.survival.worldmap.AreaCoord(worldMap.curAx, worldMap.curAy);
          if (!worldMap.exitsByArea.containsKey(c1)) {
            worldMap.exitsByArea.put(c1, new com.yourgame.survival.worldmap.WorldMapState.AreaExits(true, true, true, true));
          }
// Nicht fertiges Feature:           worldMapDirty = true;
          toast = "WorldMap: entered " + r.templateId + " @(" + worldMap.curAx + "," + worldMap.curAy + ")";
          toastT = 2.2f;
        }
        case NO_EXIT -> {
          toast = "WorldMap: no exit";
          toastT = 2.0f;
        }
        case INVALID_PLACEMENT -> {
          toast = "WorldMap: invalid placement";
          toastT = 2.2f;
        }
        case LOAD_FAILED -> {
          toast = "WorldMap: load failed: " + r.templateId;
          toastT = 2.6f;
        }
      }
    } catch (Throwable t) {
      toast = "WorldMap travel error";
      toastT = 2.6f;
    }
  }

  /**
   * Save the "war stand" snapshot for the current area.
   *
   * Requirement:
   * - When zooming into a NOT-current area, the UI must show the last-known state when we left.
   * - The current area is shown as live.
   */
  private void areaOnLeaveCurrent() {
    try {
      com.yourgame.survival.worldmap.AreaCoord c = new com.yourgame.survival.worldmap.AreaCoord(worldMap.curAx, worldMap.curAy);

      // Ensure exits exist (alpha: all sides).
      if (!worldMap.exitsByArea.containsKey(c)) {
        worldMap.exitsByArea.put(c, new com.yourgame.survival.worldmap.WorldMapState.AreaExits(true, true, true, true));
      }

      // Preserve existing per-area state (fog) and only update war-stand snapshot fields.
      com.yourgame.survival.worldmap.WorldMapState.AreaState st = worldMap.areaStates.get(c);
      if (st == null) st = new com.yourgame.survival.worldmap.WorldMapState.AreaState();

      st.ax = c.ax;
      st.ay = c.ay;
      st.templateId = worldMap.curTemplateId;

      // Mini-map snapshot: downsample area tiles to a compact grid.
      st.miniScale = com.yourgame.survival.tuning.TuningAreas.MAP_MINI_SCALE;
      st.miniW = com.yourgame.survival.tuning.TuningAreas.AREA_W_TILES / st.miniScale;
      st.miniH = com.yourgame.survival.tuning.TuningAreas.AREA_H_TILES / st.miniScale;
      st.miniMapB64 = captureMiniMapB64(st.miniScale, st.miniW, st.miniH);

      st.leftDayIndex = dayIndex;
      st.leftDayT = dayNight.t;

      // Persist tile-tree cuts (so harvested trees do not respawn).
      try {
        if (TILE_TREES_FELL_ON_HARVEST && AREA_MODE && areaTreeCutBits != null && areaTreeW > 0 && areaTreeH > 0) {
          st.treeCutW = areaTreeW;
          st.treeCutH = areaTreeH;
          st.treeCutB64 = java.util.Base64.getEncoder().encodeToString(areaTreeCutBits);
        }
      } catch (Throwable ignored2) {}

      worldMap.areaStates.put(c, st);
    } catch (Throwable ignored) {}
  }

  /** Capture a downsampled groundId map and encode it as base64. */
  private String captureMiniMapB64(int scale, int miniW, int miniH) {
    try {
      if (world == null) return "";
      if (scale <= 0 || miniW <= 0 || miniH <= 0) return "";

      byte[] out = new byte[miniW * miniH];
      int idx = 0;
      for (int my = 0; my < miniH; my++) {
        int ty = my * scale;
        for (int mx = 0; mx < miniW; mx++) {
          int tx = mx * scale;

          int cx = tx / World.CHUNK_SIZE;
          int cy = ty / World.CHUNK_SIZE;
          int lx = tx - cx * World.CHUNK_SIZE;
          int ly = ty - cy * World.CHUNK_SIZE;

          short gid = 0;
          com.yourgame.survival.world.Chunk c = world.peekChunk(cx, cy);
          if (c != null && c.layers != null) {
            int li = lx + ly * World.CHUNK_SIZE;
            if (li >= 0 && li < c.layers.groundId.length) {
              gid = c.layers.groundId[li];
            }
          }
          out[idx++] = (byte) (gid & 0xFF);
        }
      }

      return java.util.Base64.getEncoder().encodeToString(out);
    } catch (Throwable t) {
      return "";
    }
  }

  private static float smooth01(float x) {
    if (x <= 0f) return 0f;
    if (x >= 1f) return 1f;
    return x * x * (3f - 2f * x);
  }

  private void drawWorldMapOverview(float alpha, float scale) {
    try {
      if (shape == null || font == null) return;

      // Background dim
      shape.setProjectionMatrix(uiCam.combined);
      shape.begin(com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType.Filled);
      shape.setColor(0f, 0f, 0f, 0.85f * alpha);
      shape.rect(0f, 0f, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
      shape.end();

      float cx0 = (Gdx.graphics.getWidth() * 0.5f) + mapPanX;
      float cy0 = (Gdx.graphics.getHeight() * 0.5f) + mapPanY;
      float cell = 40f * scale;

      // Tiles
      shape.begin(com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType.Filled);
      for (java.util.Map.Entry<com.yourgame.survival.worldmap.AreaCoord, String> e : worldMap.knownAreas.entrySet()) {
        com.yourgame.survival.worldmap.AreaCoord c = e.getKey();
        String tid = e.getValue();

        float bx = cx0 + c.ax * cell;
        float by = cy0 + c.ay * cell;

        boolean selected = (c.ax == mapSelectedAx && c.ay == mapSelectedAy);
        boolean current = (c.ax == worldMap.curAx && c.ay == worldMap.curAy);

        // Base color by template
        float r = 0.25f, g = 0.25f, b = 0.25f;
        switch (tid) {
          case "HOME" -> { r = 0.30f; g = 0.35f; b = 0.45f; }
          case "GEN_GRASSLAND" -> { r = 0.20f; g = 0.55f; b = 0.20f; }
          case "GEN_ROCKY_FIELDS" -> { r = 0.45f; g = 0.45f; b = 0.45f; }
          case "GEN_LIGHT_FOREST" -> { r = 0.18f; g = 0.35f; b = 0.18f; }
          default -> { /* keep base */ }
        }

        float a = 0.85f * alpha;
        shape.setColor(r, g, b, a);
        shape.rect(bx - cell * 0.45f, by - cell * 0.45f, cell * 0.90f, cell * 0.90f);

        // Selected/current highlight border
        if (selected || current) {
          shape.setColor(current ? 1f : 1f, current ? 1f : 1f, current ? 1f : 0.2f, 1f * alpha);
          float bw = cell * 0.92f;
          float bh = cell * 0.92f;
          float x = bx - bw * 0.5f;
          float y = by - bh * 0.5f;
          // simple thick border
          float t = 2f;
          shape.rect(x, y, bw, t);
          shape.rect(x, y + bh - t, bw, t);
          shape.rect(x, y, t, bh);
          shape.rect(x + bw - t, y, t, bh);
        }
      }
      shape.end();

      // Text
      batch.setColor(1f, 1f, 1f, alpha);
      font.getData().setScale(1.0f * UI_FONT_SCALE);
      font.draw(batch, "MAP (Shift+M)", 20, Gdx.graphics.getHeight() - 160);
      font.draw(batch, "Known areas: " + worldMap.knownAreas.size(), 20, Gdx.graphics.getHeight() - 190);
      font.draw(batch, "Click area to view map", 20, Gdx.graphics.getHeight() - 220);
      batch.setColor(1f, 1f, 1f, 1f);
    } catch (Throwable ignored) {
      try { shape.end(); } catch (Throwable ignored2) {}
    }
  }

  private void drawSelectedAreaMap(float alpha, float scale) {
    try {
      if (shape == null || font == null) return;

      // Background dim
      shape.setProjectionMatrix(uiCam.combined);
      shape.begin(com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType.Filled);
      shape.setColor(0f, 0f, 0f, 0.92f * alpha);
      shape.rect(0f, 0f, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
      shape.end();

      boolean isCurrent = (mapSelectedAx == worldMap.curAx && mapSelectedAy == worldMap.curAy);

      // Map rect
      float maxSize = Math.min(Gdx.graphics.getWidth(), Gdx.graphics.getHeight()) * 0.78f * scale;
      float x0 = (Gdx.graphics.getWidth() - maxSize) * 0.5f;
      float y0 = (Gdx.graphics.getHeight() - maxSize) * 0.5f;

      int miniScale = 4;
      int miniW = com.yourgame.survival.tuning.TuningAreas.AREA_W_TILES / miniScale;
      int miniH = com.yourgame.survival.tuning.TuningAreas.AREA_H_TILES / miniScale;

      byte[] mapBytes = null;

      if (isCurrent) {
        mapBytes = captureMiniMapBytesLive(miniScale, miniW, miniH);
      } else {
        com.yourgame.survival.worldmap.AreaCoord c = new com.yourgame.survival.worldmap.AreaCoord(mapSelectedAx, mapSelectedAy);
        com.yourgame.survival.worldmap.WorldMapState.AreaState st = worldMap.areaStates.get(c);
        if (st != null && st.miniMapB64 != null && !st.miniMapB64.isEmpty()) {
          try { mapBytes = java.util.Base64.getDecoder().decode(st.miniMapB64); } catch (Throwable ignored) { mapBytes = null; }
        }
      }

      // Decode persistent fog alpha (0..255)
      byte[] fogABytes = null;
      {
        com.yourgame.survival.worldmap.AreaCoord c = new com.yourgame.survival.worldmap.AreaCoord(mapSelectedAx, mapSelectedAy);
        com.yourgame.survival.worldmap.WorldMapState.AreaState st = worldMap.areaStates.get(c);
        if (st != null) {
          // Determine expected alpha-map size for this stored area.
          int sc = (st.fogScale > 0) ? st.fogScale : com.yourgame.survival.tuning.TuningAreas.FOW_ALPHA_SCALE_TILES;
          int fw = com.yourgame.survival.tuning.TuningAreas.AREA_W_TILES / sc;
          int fh = com.yourgame.survival.tuning.TuningAreas.AREA_H_TILES / sc;
          if (st.fogBitsB64 != null && !st.fogBitsB64.isEmpty()) {
            try {
              byte[] raw = java.util.Base64.getDecoder().decode(st.fogBitsB64);
              if (raw != null) {
                if (raw.length == fw * fh) {
                  fogABytes = raw;
                } else {
                  // old bitset -> alpha conversion
                  int bits = fw * fh;
                  int bytesOld = (bits + 7) >> 3;
                  if (raw.length == bytesOld) {
                    int exploredA = (int) (com.yourgame.survival.tuning.TuningAreas.FOW_EXPLORED_ALPHA * 255f);
                    if (exploredA < 0) exploredA = 0;
                    if (exploredA > 255) exploredA = 255;
                    fogABytes = new byte[fw * fh];
                    for (int i = 0; i < fogABytes.length; i++) {
                      int bi = i >> 3;
                      int bit = i & 7;
                      int mask = 1 << bit;
                      boolean explored = (raw[bi] & mask) != 0;
                      fogABytes[i] = (byte) (explored ? exploredA : 255);
                    }
                    // upgrade stored payload
                    st.fogScale = sc;
                    st.fogW = fw;
                    st.fogH = fh;
                    st.fogBitsB64 = java.util.Base64.getEncoder().encodeToString(fogABytes);
// Nicht fertiges Feature:                     worldMapDirty = true;
                  }
                }
              }
            } catch (Throwable ignored) { fogABytes = null; }
          }
        }
      }

      // Visible radius (current area only): action ring + margin
      int pMx = -9999, pMy = -9999;
      float rVisMini = 0f;
      float fadeMini = 0f;
      if (isCurrent) {
        int ptx = (int) Math.floor(px / World.TILE_WORLD);
        int pty = (int) Math.floor(py / World.TILE_WORLD);
        pMx = ptx / miniScale;
        pMy = pty / miniScale;

        float actionR = actionReach(equippedFromHotbar());
        float marginWu = com.yourgame.survival.tuning.TuningAreas.FOW_VISIBLE_MARGIN_TILES * World.TILE_WORLD;
        float rVisTiles = (actionR + marginWu) / World.TILE_WORLD;
        rVisMini = rVisTiles / (float) miniScale;

        fadeMini = Math.max(1f, (float) com.yourgame.survival.tuning.TuningAreas.FOW_EDGE_FADE_TILES / (float) miniScale);
      }

      // Draw minimap tiles + fog overlay
      shape.begin(com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType.Filled);
      float cw = maxSize / (float) miniW;
      float ch = maxSize / (float) miniH;

      for (int my = 0; my < miniH; my++) {
        for (int mx = 0; mx < miniW; mx++) {
          int idx = mx + my * miniW;
          int gid = (mapBytes != null && idx >= 0 && idx < mapBytes.length) ? (mapBytes[idx] & 0xFF) : 0;

          // groundId colors (0..5 from tileset.json)
          float r = 0.15f, g = 0.15f, b = 0.15f;
          switch (gid) {
            case 0 -> { r = 0.15f; g = 0.55f; b = 0.20f; } // GRASS
            case 1 -> { r = 0.45f; g = 0.30f; b = 0.15f; } // DIRT
            case 2 -> { r = 0.70f; g = 0.65f; b = 0.25f; } // SAND
            case 3 -> { r = 0.45f; g = 0.45f; b = 0.45f; } // ROCK
            case 4 -> { r = 0.85f; g = 0.90f; b = 0.95f; } // SNOW
            case 5 -> { r = 0.85f; g = 0.15f; b = 0.10f; } // LAVA
          }

          float rx = x0 + mx * cw;
          float ry = y0 + my * ch;

          // base tile
          shape.setColor(r, g, b, 1f * alpha);
          shape.rect(rx, ry, cw + 0.5f, ch + 0.5f);

          // fog overlay alpha (from persistent alpha-map)
          float fogA = 1.0f;
          if (fogABytes != null) {
            // Map minimap cell -> fog alpha cell (different resolution)
            int sc = com.yourgame.survival.tuning.TuningAreas.FOW_ALPHA_SCALE_TILES;
            int fw = com.yourgame.survival.tuning.TuningAreas.AREA_W_TILES / sc;
            int fh = com.yourgame.survival.tuning.TuningAreas.AREA_H_TILES / sc;

            // Convert minimap cell coords back to tile coords, then to fog cell.
            int tx = mx * miniScale;
            int ty = my * miniScale;
            int fx = MathUtils.clamp(tx / sc, 0, fw - 1);
            int fy = MathUtils.clamp(ty / sc, 0, fh - 1);
            int fi = fx + fy * fw;
            int aByte = fogABytes[fi] & 0xFF;
            fogA = aByte / 255f;
          }

          // Live visibility (current area only): clear circle with soft edge over explored
          if (isCurrent) {
            float dx = (mx + 0.5f) - (pMx + 0.5f);
            float dy = (my + 0.5f) - (pMy + 0.5f);
            float d = (float) Math.sqrt(dx * dx + dy * dy);
            if (d <= rVisMini) {
              fogA = 0f;
            } else if (d <= rVisMini + fadeMini) {
              float t = (d - rVisMini) / fadeMini;
              t = t * t * (3f - 2f * t);
              fogA = fogA * t;
            }
          }

          if (fogA > 1e-3f) {
            shape.setColor(0f, 0f, 0f, fogA * alpha);
            shape.rect(rx, ry, cw + 0.5f, ch + 0.5f);
          }
        }
      }
      shape.end();

      // Text
      batch.setColor(1f, 1f, 1f, alpha);
      font.getData().setScale(1.0f * UI_FONT_SCALE);
      font.draw(batch, "AREA (" + mapSelectedAx + "," + mapSelectedAy + ")" + (isCurrent ? " [LIVE]" : " [WAR]"), 20, Gdx.graphics.getHeight() - 160);
      font.draw(batch, "ESC = Back", 20, Gdx.graphics.getHeight() - 190);
      if (!isCurrent && mapBytes == null) {
        font.draw(batch, "No saved snapshot yet", 20, Gdx.graphics.getHeight() - 220);
      }

      // Fog of War info (map-only)
      font.draw(batch, "FoW: unknown=black, explored=fog, visible=clear", 20, Gdx.graphics.getHeight() - 220);
      batch.setColor(1f, 1f, 1f, 1f);
    } catch (Throwable ignored) {
      try { shape.end(); } catch (Throwable ignored2) {}
    }
  }

  private boolean areaTryTravelAtEdge(com.yourgame.survival.worldmap.Dir4 dir) {
    try {
      // Save war-stand for current area before leaving.
      areaOnLeaveCurrent();

      long seed = worldSeed;
      com.yourgame.survival.worldmap.AreaTravelResult r = worldMapTravel.travel(this, worldMap, dir, seed);
      if (r == null || r.code != com.yourgame.survival.worldmap.AreaTravelResult.Code.OK) {
        toast = "WorldMap: travel blocked";
        toastT = 1.4f;
        return false;
      }

      // Alpha exits: ensure exits exist.
      com.yourgame.survival.worldmap.AreaCoord c1 = new com.yourgame.survival.worldmap.AreaCoord(worldMap.curAx, worldMap.curAy);
      if (!worldMap.exitsByArea.containsKey(c1)) {
        worldMap.exitsByArea.put(c1, new com.yourgame.survival.worldmap.WorldMapState.AreaExits(true, true, true, true));
      }

      // Ensure fog alpha map storage exists immediately for the new area.
      {
        com.yourgame.survival.worldmap.WorldMapState.AreaState st = worldMap.areaStates.get(c1);
        if (st == null) st = new com.yourgame.survival.worldmap.WorldMapState.AreaState();
        st.ax = c1.ax;
        st.ay = c1.ay;
        st.templateId = worldMap.curTemplateId;

        int sc = com.yourgame.survival.tuning.TuningAreas.FOW_ALPHA_SCALE_TILES;
        int fw = com.yourgame.survival.tuning.TuningAreas.AREA_W_TILES / sc;
        int fh = com.yourgame.survival.tuning.TuningAreas.AREA_H_TILES / sc;
        st.fogScale = sc;
        st.fogW = fw;
        st.fogH = fh;
        if (st.fogBitsB64 == null || st.fogBitsB64.isEmpty()) {
          byte[] a = new byte[fw * fh];
          java.util.Arrays.fill(a, (byte) 255);
          st.fogBitsB64 = java.util.Base64.getEncoder().encodeToString(a);
        }
        worldMap.areaStates.put(c1, st);
      }

      // Force next reveal tick to run immediately after travel.
      fowAccT = com.yourgame.survival.tuning.TuningAreas.FOW_REVEAL_STEP_SEC;

// Nicht fertiges Feature:       worldMapDirty = true;

      // Place player just inside the opposite edge.
      float tw = World.TILE_WORLD;
      float w = com.yourgame.survival.tuning.TuningAreas.AREA_W_TILES * tw;
      float h = com.yourgame.survival.tuning.TuningAreas.AREA_H_TILES * tw;
      float pad = 2f * tw;
      switch (dir) {
        case W -> px = w - pad;
        case E -> px = pad;
        case S -> py = h - pad;
        case N -> py = pad;
      }
      // Keep other axis (roughly) stable.
      px = MathUtils.clamp(px, pad, w - pad);
      py = MathUtils.clamp(py, pad, h - pad);
      if (playerE >= 0) { entities.x[playerE] = px; entities.y[playerE] = py; }

      toast = "Gebiet: " + worldMap.curTemplateId + " (" + worldMap.curAx + "," + worldMap.curAy + ")";
      toastT = 1.8f;
      return true;
    } catch (Throwable t) {
      toast = "Travel error";
      toastT = 1.8f;
      return false;
    }
  }

  // Nicht fertiges Feature: commented out unused block
  /*
  private static boolean fogBitGet(byte[] fog, int idx) {
    if (fog == null) return false;
    int bi = idx >> 3;
    int bit = idx & 7;
    if (bi < 0 || bi >= fog.length) return false;
    int mask = 1 << bit;
    return (fog[bi] & mask) != 0;
  }
  */

  // Nicht fertiges Feature: commented out unused block
  /*
  private static boolean fogBitSet(byte[] fog, int idx) {
    if (fog == null) return false;
    int bi = idx >> 3;
    int bit = idx & 7;
    if (bi < 0 || bi >= fog.length) return false;
    byte mask = (byte) (1 << bit);
    if ((fog[bi] & mask) != 0) return false;
    fog[bi] |= mask;
    return true;
  }
  */

  private byte[] getCurrentAreaFogAlphaBytesOrNull(int fogW, int fogH) {
    try {
      if (worldMap == null) return null;
      com.yourgame.survival.worldmap.AreaCoord c = new com.yourgame.survival.worldmap.AreaCoord(worldMap.curAx, worldMap.curAy);
      com.yourgame.survival.worldmap.WorldMapState.AreaState st = worldMap.areaStates.get(c);
      if (st == null || st.fogBitsB64 == null || st.fogBitsB64.isEmpty()) return null;

      byte[] raw = java.util.Base64.getDecoder().decode(st.fogBitsB64);
      if (raw == null) return null;

      // New format: fogW*fogH bytes (0..255 alpha)
      if (raw.length == fogW * fogH) return raw;

      // Backward compat: old bitset ((w*h+7)/8). Convert to alpha bytes.
      int bits = fogW * fogH;
      int bytesOld = (bits + 7) >> 3;
      if (raw.length == bytesOld) {
        int exploredA = (int) (com.yourgame.survival.tuning.TuningAreas.FOW_EXPLORED_ALPHA * 255f);
        if (exploredA < 0) exploredA = 0;
        if (exploredA > 255) exploredA = 255;
        byte[] a = new byte[fogW * fogH];
        for (int i = 0; i < fogW * fogH; i++) {
          int bi = i >> 3;
          int bit = i & 7;
          int mask = 1 << bit;
          boolean explored = bi >= 0 && bi < raw.length && ((raw[bi] & mask) != 0);
          a[i] = (byte) (explored ? exploredA : 255);
        }
        // upgrade in-memory save payload
        st.fogBitsB64 = java.util.Base64.getEncoder().encodeToString(a);
        st.fogW = fogW;
        st.fogH = fogH;
        st.fogScale = com.yourgame.survival.tuning.TuningAreas.FOW_ALPHA_SCALE_TILES;
// Nicht fertiges Feature:         worldMapDirty = true;
        return a;
      }

      return null;
    } catch (Throwable ignored) {
      return null;
    }
  }

  private void renderFogOfWarOverlayWorld() {
    try {
      // StarCraft-like FoW:
      // - unknown = black (alpha=1)
      // - explored = light translucent fog (alpha=FOW_EXPLORED_ALPHA)
      // - visible now = clear (alpha=0), soft edge
      if (batch == null) return;

      // Use higher-res alpha map so clearing is not raster-y.
      int scale = com.yourgame.survival.tuning.TuningAreas.FOW_ALPHA_SCALE_TILES;
      int wTiles = com.yourgame.survival.tuning.TuningAreas.AREA_W_TILES;
      int hTiles = com.yourgame.survival.tuning.TuningAreas.AREA_H_TILES;
      int fogW = wTiles / scale;
      int fogH = hTiles / scale;

      byte[] fogABytes = getCurrentAreaFogAlphaBytesOrNull(fogW, fogH);
      if (fogABytes == null || fogABytes.length != fogW * fogH) {
        fogABytes = new byte[fogW * fogH];
        java.util.Arrays.fill(fogABytes, (byte) 255);
      }

      // Ensure backing pixmap/texture
      if (fowPm == null || fowPm.getWidth() != fogW || fowPm.getHeight() != fogH) {
        try { if (fowPm != null) fowPm.dispose(); } catch (Throwable ignored) {}
        try { if (fowTex != null) fowTex.dispose(); } catch (Throwable ignored) {}
        fowPm = new Pixmap(fogW, fogH, Pixmap.Format.RGBA8888);
        fowPm.setBlending(Pixmap.Blending.None);
        fowTex = new Texture(fowPm);
        fowTex.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
      }

      // Player pos in tiles -> fog cells
      int ptx = (int) Math.floor(px / World.TILE_WORLD);
      int pty = (int) Math.floor(py / World.TILE_WORLD);
      float pFx = (ptx + 0.5f) / (float) scale;
      float pFy = (pty + 0.5f) / (float) scale;

      // Clear radius (circle): action ring + margin, cut off slightly (requested earlier)
      float actionR = actionReach(equippedFromHotbar());
      float marginWu = com.yourgame.survival.tuning.TuningAreas.FOW_VISIBLE_MARGIN_TILES * World.TILE_WORLD;
      float rClearTilesRaw = (actionR + marginWu) / World.TILE_WORLD;
      float rClearTiles = Math.max(2f, rClearTilesRaw - com.yourgame.survival.tuning.TuningAreas.FOW_CLEAR_CUTOFF_FORWARD_TILES);
      float rClear = rClearTiles / (float) scale;

      float fadeTiles = com.yourgame.survival.tuning.TuningAreas.FOW_EDGE_FADE_TILES;
      float fade = Math.max(1f / (float) scale, fadeTiles / (float) scale);

      for (int y = 0; y < fogH; y++) {
        for (int x = 0; x < fogW; x++) {
          int idx = x + y * fogW;
          float a0 = (fogABytes[idx] & 0xFF) / 255f;

          // Apply "visible now" clear circle with soft edge.
          float dx = (x + 0.5f) - pFx;
          float dy = (y + 0.5f) - pFy;
          float d = (float) Math.sqrt(dx * dx + dy * dy);

          float a = a0;
          if (d <= rClear) {
            a = 0f;
          } else if (d <= rClear + fade) {
            float t = (d - rClear) / Math.max(1e-3f, fade);
            t = t * t * (3f - 2f * t);
            a = a0 * t;
          }

          // Write pixel (flip Y)
          int pyPm = (fogH - 1) - y;
          fowPm.setColor(0f, 0f, 0f, MathUtils.clamp(a, 0f, 1f));
          fowPm.drawPixel(x, pyPm);
        }
      }

      fowTex.draw(fowPm, 0, 0);

      // Draw scaled over the area in world coordinates.
      float cellWu = World.TILE_WORLD * scale;
      float wWu = fogW * cellWu;
      float hWu = fogH * cellWu;

      batch.setProjectionMatrix(cam.combined);
      batch.begin();
      batch.enableBlending();
      batch.setColor(1f, 1f, 1f, 1f);
      batch.draw(fowTex, 0f, 0f, wWu, hWu);
      batch.end();
    } catch (Throwable ignored) {
      try { batch.end(); } catch (Throwable ignored2) {}
    }
  }

  private void areaFogRevealTick(float dt) {
    try {
      if (!AREA_MODE) return;
      if (worldMap == null) return;

      fowAccT += dt;
      if (fowAccT < com.yourgame.survival.tuning.TuningAreas.FOW_REVEAL_STEP_SEC) return;
      fowAccT = 0f;

      // Persistent explored fog alpha map (higher-res than minimap)
      int scale = com.yourgame.survival.tuning.TuningAreas.FOW_ALPHA_SCALE_TILES;
      int fogW = com.yourgame.survival.tuning.TuningAreas.AREA_W_TILES / scale;
      int fogH = com.yourgame.survival.tuning.TuningAreas.AREA_H_TILES / scale;

      com.yourgame.survival.worldmap.AreaCoord c = new com.yourgame.survival.worldmap.AreaCoord(worldMap.curAx, worldMap.curAy);
      com.yourgame.survival.worldmap.WorldMapState.AreaState st = worldMap.areaStates.get(c);
      if (st == null) {
        st = new com.yourgame.survival.worldmap.WorldMapState.AreaState();
        st.ax = c.ax;
        st.ay = c.ay;
        st.templateId = worldMap.curTemplateId;
        worldMap.areaStates.put(c, st);
      }

      // Ensure fog storage metadata
      st.fogScale = scale;
      st.fogW = fogW;
      st.fogH = fogH;

      // Load or initialize alpha bytes
      byte[] a = getCurrentAreaFogAlphaBytesOrNull(fogW, fogH);
      if (a == null || a.length != fogW * fogH) {
        a = new byte[fogW * fogH];
        java.util.Arrays.fill(a, (byte) 255);
      }

      int exploredA = (int) (com.yourgame.survival.tuning.TuningAreas.FOW_EXPLORED_ALPHA * 255f);
      if (exploredA < 0) exploredA = 0;
      if (exploredA > 255) exploredA = 255;

      // Brush: circular erase with falloff (in tiles)
      float rOuterTiles = com.yourgame.survival.tuning.TuningAreas.FOW_EXPLORE_RADIUS_TILES;
      float falloffTiles = com.yourgame.survival.tuning.TuningAreas.FOW_EXPLORE_FALLOFF_TILES;
      float rInnerTiles = Math.max(0f, rOuterTiles - falloffTiles);

      // Center in fog-cell space
      int ptx = (int) Math.floor(px / World.TILE_WORLD);
      int pty = (int) Math.floor(py / World.TILE_WORLD);
      float pFx = (ptx + 0.5f) / (float) scale;
      float pFy = (pty + 0.5f) / (float) scale;

      float rOuter = rOuterTiles / (float) scale;
      int rBox = (int) Math.ceil(rOuter) + 2;

      boolean changed = false;
      for (int dy = -rBox; dy <= rBox; dy++) {
        int y = (int) Math.floor(pFy) + dy;
        if (y < 0 || y >= fogH) continue;
        for (int dx = -rBox; dx <= rBox; dx++) {
          int x = (int) Math.floor(pFx) + dx;
          if (x < 0 || x >= fogW) continue;

          float cx = (x + 0.5f) - pFx;
          float cy = (y + 0.5f) - pFy;
          float dCells = (float) Math.sqrt(cx * cx + cy * cy);
          float dTiles = dCells * scale;
          if (dTiles > rOuterTiles) continue;

          float t;
          if (dTiles <= rInnerTiles || falloffTiles <= 1e-3f) {
            t = 0f;
          } else {
            t = (dTiles - rInnerTiles) / falloffTiles;
            if (t < 0f) t = 0f;
            if (t > 1f) t = 1f;
            // smoothstep
            t = t * t * (3f - 2f * t);
          }

          int targetA = (int) (exploredA + (255 - exploredA) * t);
          int idx = x + y * fogW;
          int cur = a[idx] & 0xFF;
          if (targetA < cur) {
            a[idx] = (byte) targetA;
            changed = true;
          }
        }
      }

      if (changed) {
        st.fogBitsB64 = java.util.Base64.getEncoder().encodeToString(a);
// Nicht fertiges Feature:         worldMapDirty = true;
      }
    } catch (Throwable ignored) {}
  }

  private byte[] captureMiniMapBytesLive(int scale, int miniW, int miniH) {
    try {
      if (world == null) return null;
      byte[] out = new byte[miniW * miniH];
      int idx = 0;
      for (int my = 0; my < miniH; my++) {
        int ty = my * scale;
        for (int mx = 0; mx < miniW; mx++) {
          int tx = mx * scale;
          int cx = tx / World.CHUNK_SIZE;
          int cy = ty / World.CHUNK_SIZE;
          int lx = tx - cx * World.CHUNK_SIZE;
          int ly = ty - cy * World.CHUNK_SIZE;
          short gid = 0;
          com.yourgame.survival.world.Chunk c = world.peekChunk(cx, cy);
          if (c != null && c.layers != null) {
            int li = lx + ly * World.CHUNK_SIZE;
            if (li >= 0 && li < c.layers.groundId.length) gid = c.layers.groundId[li];
          }
          out[idx++] = (byte) (gid & 0xFF);
        }
      }
      return out;
    } catch (Throwable t) {
      return null;
    }
  }

  private static byte dirFromVel(float vx, float vy, byte last) {
    float ax = Math.abs(vx);
    float ay = Math.abs(vy);
    if (ax < 1e-3f && ay < 1e-3f) return last;
    if (ax > ay) return (byte) ((vx >= 0f) ? 1 : 3); // E/W
    return (byte) ((vy >= 0f) ? 0 : 2); // N/S
  }

  @Deprecated
  // Nicht fertiges Feature: commented out unused method
  /*
  private void ensureEncounters() {
    // Replaced by EncounterSpawner (Block 12). Intentionally left as no-op.
  }
  */

  // =====================================================================
  // Area/WorldMap loading helpers (alpha scaffolding)
  // =====================================================================
  //
  // These methods form the controlled "seam" where the story-first Area system
  // can swap the world content without exposing internal fields directly.
  //
  // Design decision:
  // - The Area loader operates *through* GameScreen.
  // - Reason: GameScreen owns multiple coupled systems (World, node spawner,
  //   simContext, player position, etc.). A narrow API reduces accidental bugs.

  /** @return the base world seed stored in saves (stable per save slot). */
  public long areaGetWorldSeed() {
    return worldSeed;
  }

  /** @return same as {@link #areaGetWorldSeed()}, but avoids any deprecated symbol in callers. */
  public long areaWorldSeed() {
    return worldSeed;
  }

  /** @return current world instance (after any area load/reset). */
  public com.yourgame.survival.world.World areaWorld() {
    return world;
  }

  /** @return global entity container (used by loader for spawning nodes/animals). */
  public com.yourgame.survival.entity.Entities areaEntities() {
    return entities;
  }

  /** @return persistent WorldMapState (per-save) used for one-time POIs and authored node removals. */
  public com.yourgame.survival.worldmap.WorldMapState areaWorldMapState() {
    return worldMap;
  }

  /** @return chest store used by both build-chests and POI chests. */
  public com.yourgame.survival.data.ChestStore areaChestStore() {
    return chestStore;
  }

  // ============================================================
  // Authored enemy zones (FUSA Story)
  // ============================================================

  private static final class EnemyZone {
    int cxTile;
    int cyTile;
    int rTiles;
    int targetMin;
    int targetMax;
    int respawnDaysMin;
    int respawnDaysMax;

    int targetCount;
    int nextRespawnDayIndex;

    long seed;
  }

  private final com.badlogic.gdx.utils.Array<EnemyZone> enemyZones = new com.badlogic.gdx.utils.Array<>(8);

  // ============================================================
  // Authored tile-tree field (FUSA Story)
  // ============================================================

  // Presence mask: 1 bit per tile (384*384 bits => 18432 bytes). Generated deterministically on area load.
  private byte[] areaTreePresentBits = null;
  // Cut mask: 1 bit per tile. Persisted per-area state (so trees don't come back after save/load).
  private byte[] areaTreeCutBits = null;
  private int areaTreeW = 0;
  private int areaTreeH = 0;
  private boolean areaTreeDebugToastOnce = false;
  private boolean areaTreeInitToastOnce = false;

  public void areaSetTreePresentBits(int wTiles, int hTiles, byte[] bits) {
    this.areaTreeW = Math.max(0, wTiles);
    this.areaTreeH = Math.max(0, hTiles);
    this.areaTreePresentBits = bits;
    this.areaTreeDebugToastOnce = false;
  }

  public void areaSetTreeCutBits(int wTiles, int hTiles, byte[] bits) {
    this.areaTreeW = Math.max(0, wTiles);
    this.areaTreeH = Math.max(0, hTiles);
    this.areaTreeCutBits = bits;
  }

  // One-shot debug toast helper for diagnosing area load/spawn issues.
  public void areaDebugToastOnce(String msg) {
    if (msg == null || msg.isEmpty()) return;
    if (areaTreeInitToastOnce) return;
    toast = msg;
    toastT = 6.0f;
    areaTreeInitToastOnce = true;
  }

  private static int bitIndex(int tx, int ty, int wTiles) {
    return tx + ty * wTiles;
  }

  private static boolean bitGet(byte[] bits, int bit) {
    if (bits == null || bit < 0) return false;
    int i = bit >>> 3;
    if (i < 0 || i >= bits.length) return false;
    int m = 1 << (bit & 7);
    return (bits[i] & m) != 0;
  }

  private static void bitSet(byte[] bits, int bit, boolean on) {
    if (bits == null || bit < 0) return;
    int i = bit >>> 3;
    if (i < 0 || i >= bits.length) return;
    int m = 1 << (bit & 7);
    if (on) bits[i] = (byte) (bits[i] | m);
    else bits[i] = (byte) (bits[i] & ~m);
  }

  public void areaClearEnemyZones() {
    enemyZones.clear();
  }

  public void areaAddEnemyZone(int cxTile, int cyTile, int rTiles, int min, int max, int respawnDaysMin, int respawnDaysMax) {
    EnemyZone z = new EnemyZone();
    z.cxTile = cxTile;
    z.cyTile = cyTile;
    z.rTiles = Math.max(1, rTiles);
    z.targetMin = Math.max(0, min);
    z.targetMax = Math.max(z.targetMin, max);
    z.respawnDaysMin = Math.max(1, respawnDaysMin);
    z.respawnDaysMax = Math.max(z.respawnDaysMin, respawnDaysMax);

    // Deterministic per-zone seed
    long s = worldSeed;
    s ^= (long) cxTile * 0x9E3779B97F4A7C15L;
    s ^= (long) cyTile * 0xC2B2AE3D27D4EB4FL;
    s ^= (long) z.rTiles * 0x165667B19E3779F9L;
    z.seed = s;

    java.util.Random r = new java.util.Random(z.seed ^ 0xA11CE55EL);
    z.targetCount = z.targetMin + (z.targetMax > z.targetMin ? r.nextInt(z.targetMax - z.targetMin + 1) : 0);
    z.nextRespawnDayIndex = dayIndex; // allow spawn immediately

    enemyZones.add(z);
  }

  /**
   * Resets the World instance to a clean state using the provided seed.
   *
   * Decision + rationale:
   * - We reset the world when loading an area to avoid procedural generation artifacts.
   * - A hand-authored area must be deterministic and must not contain roads/water/etc.
   *   that came from the procedural pipeline.
   */
  public void areaResetWorld(long seed) {
    resetWorld(seed);
    // Ensure node spawner starts "fresh" for the new world.
    try { if (nodeSpawner != null) nodeSpawner.resetSpawnedChunks(); } catch (Throwable ignored) {}
  }

  /**
   * Clears entities that are considered "area-local" (procedural nodes + encounters).
   *
   * We KEEP:
   * - PLAYER (obviously)
   * - BUILD_* (player-placed objects)
   * - merchants (if present) (treat as world objects for now)
   */
  public void areaClearAreaLocalEntities() {
    for (int i = 0; i < com.yourgame.survival.entity.Entities.MAX; i++) {
      if (!entities.alive[i]) continue;
      com.yourgame.survival.entity.EntityType t = entities.type[i];
      if (t == com.yourgame.survival.entity.EntityType.PLAYER) continue;

      // Keep player builds.
      if (t == com.yourgame.survival.entity.EntityType.BUILD_CHEST
          || t == com.yourgame.survival.entity.EntityType.BUILD_WORKBENCH
          || t == com.yourgame.survival.entity.EntityType.BUILD_BED
          || t == com.yourgame.survival.entity.EntityType.BUILD_CAMPFIRE
          || t == com.yourgame.survival.entity.EntityType.BUILD_LAMP
          || t == com.yourgame.survival.entity.EntityType.POI_CHEST_HIDDEN) {
        continue;
      }

      // Keep merchants for now.
      if (t == com.yourgame.survival.entity.EntityType.MERCHANT_ELF
          || t == com.yourgame.survival.entity.EntityType.MERCHANT_WANDERING) {
        continue;
      }

      // Remove nodes + encounters + drops.
      entities.kill(i);
    }

    // Also clear node "removed" cache so trees in a new area can exist even
    // if a player harvested trees in a previous area.
    //
    // Rationale:
    // - In the final system, WorldNodes.removed should be per-area.
    // - For scaffolding, we reset it on area load to avoid confusing "missing trees".
    try { worldNodes.removed.clear(); } catch (Throwable ignored) {}
  }

  /**
   * Clears ALL runtime state that must never survive across save/load.
   *
   * This is intentionally aggressive: it prevents ghost entities / duplicated players after loading.
   */
  private void clearAllStateForLoad() {
    // Entities: wipe everything first; load will restore from snapshot.
    for (int i = 0; i < Entities.MAX; i++) {
      entities.alive[i] = false;
      entities.type[i] = null;
      entities.flags[i] = 0;
      entities.itemId[i] = -1;
      entities.itemAmount[i] = 0;
      entities.data0[i] = -1;
      entities.hp[i] = 0f;
      entities.hpMax[i] = 0f;
      entities.vx[i] = 0f;
      entities.vy[i] = 0f;
      entities.faceLock[i] = 0f;
      entities.aiT[i] = 0f;
      entities.aiT2[i] = 0f;
      entities.aiF0[i] = 0f;
      entities.aiF1[i] = 0f;
      entities.rot[i] = 0f;
    }
    playerE = -1;

    // Containers/caches that should not leak between runs.
    try { chestStore.clear(); } catch (Throwable ignored) {}
    try { worldNodes.removed.clear(); } catch (Throwable ignored) {}

    // WorldMap is per-save; clear before importing from save.
    try {
      worldMap.knownAreas.clear();
      worldMap.frontier.clear();
      worldMap.edges.clear();
      worldMap.exitsByArea.clear();
      worldMap.areaStates.clear();
      worldMap.consumedPois.clear();
      worldMap.removedAuthoredNodes.clear();
      worldMap.setCurrent(0, 0, "");
    } catch (Throwable ignored) {}

    // Transient UI state.
    shopOpen = false;
    invOpen = false;
    craftOpen = false;
    buildMode = false;
    openChestE = -1;

    buyPopup = false;
    sellPopup = false;
    buyBuffer = "";
    // Nicht fertiges Feature: sellBuffer = "";
    dragArmed = false;
    dragActive = false;
    dragSrc = DRAG_SRC_NONE;
    dragItemId = -1;
    dragIndex = -1;

    pricingOpen = false;
    pricingPresetPopup = false;

    // Projectiles
    for (int i = 0; i < ARROW_MAX; i++) arrowAlive[i] = false;

    // CommandQueue scaffolding
    commandQueue.clear();
  }

  /** Sets player position and keeps the PLAYER entity in sync. */
  public void areaSetPlayerWorldPos(float wx, float wy) {
    px = wx;
    py = wy;
    if (playerE >= 0) {
      entities.x[playerE] = wx;
      entities.y[playerE] = wy;
    }
  }

  public void doSave(int slot) {
    doSave(slot, "Slot " + slot);
  }

  public void doSave(int slot, String name) {
    try {
      com.yourgame.survival.data.SaveManager.saveSlot(
          slot,
          name,
          worldSeed,
          px, py,
          inv,
          wallet,
          progress,
          needs,
          dayNight.t,
          dayIndex,
          hotbar,
          hotbarSel,
          hasBoat,
          hasClimb,
          entities,
          chestStore,
          worldNodes,
          merchants,
          worldMap
      );
      toast = "Saved: slot" + slot;
      toastT = 2.5f;
    } catch (Throwable t) {
      toast = "Save failed";
      toastT = 3.5f;
    }
  }
  public void doLoad(int slot) {
    try {
      // HARD RULE: loading a save must not keep any runtime cache/state from prior runs.
      // If we don't wipe entities/world caches first, old entities can survive and you can "see a copy" of yourself.
      clearAllStateForLoad();

      long[] seed = new long[1];
      float[] pxpy = new float[2];
      float[] dt = new float[1];
      int[] dIdx = new int[1];
      int[] hb = new int[8];
      int[] hbSel = new int[1];
      boolean[] boat = new boolean[1];
      boolean[] climb = new boolean[1];

      boolean ok = com.yourgame.survival.data.SaveManager.loadSlot(
          slot,
          seed,
          pxpy,
          inv,
          wallet,
          progress,
          needs,
          dt,
          dIdx,
          hb,
          hbSel,
          boat,
          climb,
          entities,
          chestStore,
          worldNodes,
          null,
          worldMap
      );
      if (!ok) {
        toast = "No save in slot" + slot;
        toastT = 2.5f;
        return;
      }

      // Inventory slot layout may be loaded (v2). As a fallback for older saves, rebuild from totals.
      // (If slots were imported, rebuildSlotsFromCounts() would destroy organization.)
      // Heuristic: if normal slots are still minimal and empty but counts exist, rebuild.
      boolean anyCounts = false;
      for (int i = 0; i < inv.countsById.length; i++) { if (inv.countsById[i] > 0) { anyCounts = true; break; } }
      boolean anySlot = false;
      for (int i = 0; i < inv.normalSlotCount(); i++) { if (inv.getNormalItemId(i) >= 0 && inv.getNormalCount(i) > 0) { anySlot = true; break; } }
      for (int i = 0; i < inv.toolSlotCount() && !anySlot; i++) { if (inv.getToolItemId(i) >= 0 && inv.getToolCount(i) > 0) { anySlot = true; break; } }
      if (anyCounts && !anySlot) inv.rebuildSlotsFromCounts();

      // restore scalar state
      px = pxpy[0];
      py = pxpy[1];
      // Loading a save should preserve saved HP (do not force full HP like on new game).
      forceFullHpOnce = false;
      dayNight.t = dt[0];
      prevDayT = dayNight.t;

      hasBoat = boat[0];
      hasClimb = climb[0];

      // Destroy active world and rebuild from save seed.
      resetWorld(seed[0]);

      // Areas-only mode: reload the current area tilemap into the new world.
      if (AREA_MODE) {
        try {
          new com.yourgame.survival.worldmap.JsonAreaWorldLoader().loadInto(this, worldMap.curTemplateId, null);
        } catch (Throwable ignored) {}
      }

      // Re-apply mined ROCK tiles (rock->grass) from save.
      applyMinedRockTilesFromSave();

      merchants = new com.yourgame.survival.systems.MerchantSystem(seed[0]);
      merchants.importFromSave(com.yourgame.survival.data.SaveManager.readMerchantSys(slot), entities);
      encounterSpawner.resetTimers();

      // restore scalar state
      dayIndex = dIdx[0];
      System.arraycopy(hb, 0, hotbar, 0, Math.min(hotbar.length, hb.length));
      hotbarSel = (hbSel[0] >= 0 && hbSel[0] < hotbar.length) ? hbSel[0] : 0;

      // Entities were restored from save snapshot; find the player entity.
      playerE = -1;
      for (int e = 0; e < Entities.MAX; e++) {
        if (!entities.alive[e]) continue;
        if (entities.type[e] == EntityType.PLAYER) { playerE = e; break; }
      }
      if (playerE >= 0) {
        entities.setAlwaysActive(playerE, true);
        px = entities.x[playerE];
        py = entities.y[playerE];
      } else {
        // fallback
        playerE = entities.spawn(EntityType.PLAYER, px, py);
        entities.setAlwaysActive(playerE, true);
      }

      // BLOCK D: procedural nodes (ensure around, but do NOT overwrite existing restored entities)
      // Use warmup-limited radius to avoid a generation burst right after loading.
      int r0 = (streamWarmupFrames > 0) ? 0 : streamRadiusChunks;
      // Node visibility/removal: do not spawn local procedural nodes here.
      if (true) {
        nodeSpawner.ensureAround(entities, worldNodes, px, py, r0);
      }

      shopOpen = false;
      invOpen = false;
      craftOpen = false;
      buildMode = false;
      openChestE = -1;

      // Clear transient caches/state (projectiles, UI drags/popups, cooldowns) before continuing.
      buyPopup = false;
      buyBuffer = "";
      dragArmed = false;
      dragActive = false;
// Nicht fertiges Feature:       hackSfxT = 0f;
      bowCooldownT = 0f;
      for (int i = 0; i < ARROW_MAX; i++) arrowAlive[i] = false;
      commandQueue.clear();

      regenShopOffers();

      toast = "Loaded: slot" + slot;
      toastT = 2.5f;
    } catch (Throwable t) {
      toast = "Load failed";
      toastT = 3.5f;
    }
  }

  @Override
  public void dispose() {
    if (batch != null) batch.dispose();
    if (font != null) font.dispose();
    if (chunkRenderer != null) chunkRenderer.dispose();
    if (tiles != null) tiles.dispose();
    if (entityRegions != null) entityRegions.dispose();
    if (renderPipeline != null) renderPipeline.dispose();
    if (uiRegions != null) uiRegions.dispose();

    for (Texture t : skillIconTex.values()) {
      try { if (t != null) t.dispose(); } catch (Throwable ignored) {}
    }
    skillIconTex.clear();

    if (walletCoinCopperTex != null) walletCoinCopperTex.dispose();
    if (walletCoinSilverTex != null) walletCoinSilverTex.dispose();
    if (walletCoinGoldTex != null) walletCoinGoldTex.dispose();
    if (dayNight1x1 != null) {
      dayNight1x1.dispose();
      dayNight1x1 = null;
    }
    if (dnLightTex != null) {
      dnLightTex.dispose();
      dnLightTex = null;
    }
    if (dnMaskFbo != null) {
      try { dnMaskFbo.dispose(); } catch (Throwable ignored) {}
      dnMaskFbo = null;
    }
    dnMaskRegion = null;

    try { if (dayBgMusic != null) dayBgMusic.dispose(); } catch (Throwable ignored) {}
    dayBgMusic = null;
    try { if (nightBgMusic != null) nightBgMusic.dispose(); } catch (Throwable ignored) {}
    nightBgMusic = null;

    if (shape != null) shape.dispose();

    if (fowTex != null) {
      try { fowTex.dispose(); } catch (Throwable ignored) {}
      fowTex = null;
    }
    if (fowPm != null) {
      try { fowPm.dispose(); } catch (Throwable ignored) {}
      fowPm = null;
    }
  }

  private void drawInventoryGrid() {
    // Inventory: normal grid + tool grid underneath.
    final int gridW = com.yourgame.survival.data.Inventory.GRID_W;
    int normalRows = inv.normalRowsUsed();
    int toolRows = inv.visibleToolRows();

    float uiScale = 0.85f; // requested: inventory UI 15% smaller

    float slot = 144f * uiScale;
    float pad = 20f * uiScale;

    float normalH = normalRows * slot + (normalRows - 1) * pad;
    float toolH = toolRows * slot + (toolRows - 1) * pad;
    float labelH = 52f * uiScale;

    float innerW = gridW * slot + (gridW - 1) * pad;
    float innerH = normalH + labelH + toolH;

    float panelPad = 52f * uiScale;
    float titleH = 96f * uiScale;
    float panelW = innerW + panelPad * 2f;
    float panelH = innerH + panelPad * 2f + titleH;

    // anchored bottom-center (default) but movable by drag
    float x0Default = (Gdx.graphics.getWidth() - panelW) * 0.5f;
    float y0Default = 0f;

    if (Float.isNaN(invAnchorX) || Float.isNaN(invAnchorY) || (invAnchorX == 0f && invAnchorY == 0f) || invJustOpened) {
      float xPick = x0Default;
      float yPick = y0Default;

      // If craft panel is open, avoid placing inventory on top of it.
      if (craftOpen) {
        final float craftW = 1230f;
        final float craftH = 540f;
        final float cx = craftAnchorX;
        final float cy = craftAnchorY;

        final float[] outPos = new float[2];
        placePanelAvoiding(panelW, panelH, x0Default, y0Default, cx, cy, craftW, craftH, (xx, yy) -> {
          outPos[0] = xx;
          outPos[1] = yy;
        });
        xPick = outPos[0];
        yPick = outPos[1];
      }

      invAnchorX = xPick;
      invAnchorY = yPick;
      invJustOpened = false;
    }

    // Drag handling (panel header) - disabled while modal UI / drag&drop is active
    boolean allowPanelDrag = !pricingOpen && !walletOpen && !buyPopup && !sellPopup && !dragArmed && !dragActive;
    if (allowPanelDrag) {
      float mx = Gdx.input.getX();
      float my = Gdx.graphics.getHeight() - Gdx.input.getY();
      if (Gdx.input.justTouched()) {
        float headerY = invAnchorY + panelH - titleH;
        if (mx >= invAnchorX && mx <= invAnchorX + panelW && my >= headerY && my <= invAnchorY + panelH) {
          invDrag = true;
          invDragDx = mx - invAnchorX;
          invDragDy = my - invAnchorY;
        }
      }
      if (invDrag) {
        if (Gdx.input.isTouched()) {
          invAnchorX = mx - invDragDx;
          invAnchorY = my - invDragDy;
        } else {
          invDrag = false;
        }
      }
    } else {
      invDrag = false;
    }

    // clamp to screen so it stays reachable
    invAnchorX = MathUtils.clamp(invAnchorX, 0f, Math.max(0f, Gdx.graphics.getWidth() - panelW));
    invAnchorY = MathUtils.clamp(invAnchorY, 0f, Math.max(0f, Gdx.graphics.getHeight() - panelH));

    float x0 = invAnchorX;
    float y0 = invAnchorY;

    batch.setColor(1f, 1f, 1f, 1f);
    batch.draw(uiRegions.panelSlots, x0, y0, panelW, panelH);

    font.getData().setScale(2.0f * uiScale);
    font.setColor(0f, 0f, 0f, 1f);
    font.draw(batch, "INVENTORY (tools -> hotbar)", x0 + panelPad, y0 + panelH - 28f * uiScale);
    font.getData().setScale(1.0f * UI_FONT_SCALE);
    font.setColor(0f, 0f, 0f, 1f);

    float sx0 = x0 + panelPad;

    float toolY0 = y0 + panelPad;
    // Add a clearer gap between normal items and tools.
    float labelY0 = toolY0 + toolH + 34f * uiScale;
    float normalY0 = labelY0 + labelH;

    // cache layout for hit tests
    invSlotPx = slot;
    invPadPx = pad;
    invToolSlotsX0 = sx0;
    invToolSlotsY0 = toolY0;
    invNormSlotsX0 = sx0;
    invNormSlotsY0 = normalY0;
    invToolRowsDrawn = toolRows;
    invNormRowsDrawn = normalRows;

    // tool grid
    font.getData().setScale(1.3f * uiScale);
    font.setColor(0f, 0f, 0f, 1f);
    font.draw(batch, "TOOLS", sx0, labelY0 + 36f * uiScale);
    font.getData().setScale(1.0f * UI_FONT_SCALE);
    font.setColor(0f, 0f, 0f, 1f);

    for (int y = 0; y < toolRows; y++) {
      for (int x = 0; x < gridW; x++) {
        int idx = y * gridW + x;
        float sx = sx0 + x * (slot + pad);
        float sy = toolY0 + y * (slot + pad);
        batch.draw(uiRegions.slot, sx, sy, slot, slot);

        int itemId = inv.getToolItemId(idx);
        int count = inv.getToolCount(idx);
        if (itemId >= 0 && count > 0) {
          TextureRegion icon = entityRegions.itemIcon(itemId);
          float iw = slot * 0.70f;
          float ih = slot * 0.70f;
          if (icon != null) batch.draw(icon, sx + (slot - iw) * 0.5f, sy + (slot - ih) * 0.5f, iw, ih);
          if (count > 1) {
            font.setColor(0f, 0f, 0f, 1f);
            font.draw(batch, String.valueOf(count), sx + 6f, sy + 16f);
            font.setColor(0f, 0f, 0f, 1f);
          }
        }
      }
    }

    // normal grid
    for (int y = 0; y < normalRows; y++) {
      for (int x = 0; x < gridW; x++) {
        int idx = y * gridW + x;
        float sx = sx0 + x * (slot + pad);
        float sy = normalY0 + y * (slot + pad);
        batch.draw(uiRegions.slot, sx, sy, slot, slot);

        int itemId = inv.getNormalItemId(idx);
        int count = inv.getNormalCount(idx);
        if (itemId >= 0 && count > 0) {
          TextureRegion icon = entityRegions.itemIcon(itemId);
          float iw = slot * 0.70f;
          float ih = slot * 0.70f;
          if (icon != null) batch.draw(icon, sx + (slot - iw) * 0.5f, sy + (slot - ih) * 0.5f, iw, ih);

          font.setColor(0f, 0f, 0f, 1f);
          font.draw(batch, String.valueOf(count), sx + 6f, sy + 16f);
          font.setColor(0f, 0f, 0f, 1f);
        }
      }
    }
  }

  // ---------------- Pricing editor (Shift+F12) ----------------

  private void pricingClampSelection() {
    if (pricingSel < 0) pricingSel = 0;
    if (pricingSel >= pricingEditCopper.length) pricingSel = pricingEditCopper.length - 1;
    if (pricingSel < pricingScroll) pricingScroll = pricingSel;
    int visible = pricingVisibleRows();
    if (pricingSel >= pricingScroll + visible) pricingScroll = pricingSel - visible + 1;
    if (pricingScroll < 0) pricingScroll = 0;
    int maxScroll = Math.max(0, pricingEditCopper.length - visible);
    if (pricingScroll > maxScroll) pricingScroll = maxScroll;
  }

  private int pricingVisibleRows() {
    // depends on screen height; keep it cheap
    int h = Gdx.graphics.getHeight();
    // title + buttons + margins => roughly 200px reserved; row height ~ 22
    return MathUtils.clamp((h - 260) / 22, 6, 26);
  }

  private void pricingApplyBufferToSelected() {
    if (pricingSel < 0 || pricingSel >= pricingEditCopper.length) return;
    if (pricingEditBuffer == null || pricingEditBuffer.isEmpty()) {
      pricingEditCopper[pricingSel] = 0;
      return;
    }
    try {
      long v = Long.parseLong(pricingEditBuffer);
      if (v < 0) v = 0;
      if (v > 2_000_000_000L) v = 2_000_000_000L;
      pricingEditCopper[pricingSel] = (int) v;
    } catch (NumberFormatException ignored) {
      // ignore
    }
  }

  private void pricingHandleInput() {
    // navigation
    if (Gdx.input.isKeyJustPressed(Input.Keys.UP)) {
      pricingSel--;
      pricingClampSelection();
      pricingEditBuffer = String.valueOf(pricingEditCopper[pricingSel]);
    }
    if (Gdx.input.isKeyJustPressed(Input.Keys.DOWN)) {
      pricingSel++;
      pricingClampSelection();
      pricingEditBuffer = String.valueOf(pricingEditCopper[pricingSel]);
    }
    if (Gdx.input.isKeyJustPressed(Input.Keys.PAGE_UP)) {
      pricingSel -= pricingVisibleRows();
      pricingClampSelection();
      pricingEditBuffer = String.valueOf(pricingEditCopper[pricingSel]);
    }
    if (Gdx.input.isKeyJustPressed(Input.Keys.PAGE_DOWN)) {
      pricingSel += pricingVisibleRows();
      pricingClampSelection();
      pricingEditBuffer = String.valueOf(pricingEditCopper[pricingSel]);
    }

    // actions
    if (!pricingPresetPopup && Gdx.input.isKeyJustPressed(Input.Keys.F5)) {
      // Save
      priceBook.copyFrom(pricingEditCopper);
      boolean ok = priceBook.saveCurrent();
      regenShopOffers();
      toast = ok ? "Pricing saved" : "Pricing save failed";
      toastT = 2.5f;
    }

    if (!pricingPresetPopup && Gdx.input.isKeyJustPressed(Input.Keys.F8)) {
      // Reset to defaults (items.json)
      priceBook.setDefaultsFromItems(data.items);
      priceBook.copyTo(pricingEditCopper);
      pricingEditBuffer = String.valueOf(pricingEditCopper[pricingSel]);
      toast = "Pricing reset to defaults (not saved)";
      toastT = 2.5f;
    }

    if (!pricingPresetPopup && Gdx.input.isKeyJustPressed(Input.Keys.F9)) {
      // Preset popup
      pricingPresetNames = pricingListPresetNames();
      pricingPresetPopup = true;
    }

    if (pricingPresetPopup) {
      // choose preset 1..9
      int pick = -1;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_1)) pick = 0;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_2)) pick = 1;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_3)) pick = 2;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_4)) pick = 3;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_5)) pick = 4;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_6)) pick = 5;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_7)) pick = 6;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_8)) pick = 7;
      if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_9)) pick = 8;

      if (pick >= 0 && pricingPresetNames != null && pick < pricingPresetNames.length) {
        com.yourgame.survival.data.PriceBook tmp = new com.yourgame.survival.data.PriceBook(60);
        tmp.copyFrom(pricingEditCopper);
        boolean ok = tmp.applyPresetLocal(pricingPresetNames[pick]);
        if (ok) {
          tmp.copyTo(pricingEditCopper);
          pricingEditBuffer = String.valueOf(pricingEditCopper[pricingSel]);
          toast = "Preset loaded (not saved)";
          toastT = 2.5f;
        } else {
          toast = "Preset load failed";
          toastT = 2.5f;
        }
        pricingPresetPopup = false;
      }

      if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
        pricingPresetPopup = false;
      }
    }
  }

  private String[] pricingListPresetNames() {
    try {
      com.badlogic.gdx.files.FileHandle dir = Gdx.files.local("pricing_presets");
      if (!dir.exists()) return new String[0];
      com.badlogic.gdx.files.FileHandle[] files = dir.list("json");
      int n = Math.min(9, files.length);
      String[] names = new String[n];
      for (int i = 0; i < n; i++) names[i] = files[i].name();
      return names;
    } catch (Throwable t) {
      return new String[0];
    }
  }

  private void drawWalletMenu() {
    float w = Math.min(560f, Gdx.graphics.getWidth() - 40f);
    float h = 300f;
    float x0 = (Gdx.graphics.getWidth() - w) * 0.5f;
    float y0 = (Gdx.graphics.getHeight() - h) * 0.5f;

    batch.setColor(1f, 1f, 1f, 1f);
    batch.draw(uiRegions.panelSlots, x0, y0, w, h);

    float pad = 28f;
    float x = x0 + pad;
    float yTop = y0 + h - pad;

    long copper = wallet.copper;
    double silver = copper / 100.0;      // 100 copper = 1 silver
    double gold = copper / 100000.0;     // 1000 silver = 1 gold => 100000 copper

    font.setColor(0f, 0f, 0f, 1f);
    font.getData().setScale(1.6f * 1.15f);
    font.draw(batch, "WALLET (G close)", x, yTop);

    float rowGap = 66f;
    float rowTop = yTop - 70f;

    float iconFrame = 54f;
    float iconInner = 42f;

    float valueBoxH = 48f;
    float valueX = x + iconFrame + 14f;
    float valueW = (x0 + w - pad) - valueX;

    font.getData().setScale(1.15f * UI_FONT_SCALE);

    // Kupfer
    {
      float by = rowTop;
      batch.setColor(1f, 1f, 1f, 1f);
      batch.draw(uiRegions.slot, x, by - iconFrame + 10f, iconFrame, iconFrame);
      if (walletCoinCopperIcon != null) {
        batch.draw(walletCoinCopperIcon, x + (iconFrame - iconInner) * 0.5f, by - iconFrame + 10f + (iconFrame - iconInner) * 0.5f, iconInner, iconInner);
      }
      batch.draw(uiRegions.button, valueX, by - valueBoxH + 10f, valueW, valueBoxH);
      font.draw(batch, String.format("%d", copper), valueX + 16f, by - 8f);
    }

    // Silber
    {
      float by = rowTop - rowGap;
      batch.setColor(1f, 1f, 1f, 1f);
      batch.draw(uiRegions.slot, x, by - iconFrame + 10f, iconFrame, iconFrame);
      if (walletCoinSilverIcon != null) {
        batch.draw(walletCoinSilverIcon, x + (iconFrame - iconInner) * 0.5f, by - iconFrame + 10f + (iconFrame - iconInner) * 0.5f, iconInner, iconInner);
      }
      batch.draw(uiRegions.button, valueX, by - valueBoxH + 10f, valueW, valueBoxH);
      font.draw(batch, String.format("%.2f", silver), valueX + 16f, by - 8f);
    }

    // Gold
    {
      float by = rowTop - rowGap * 2f;
      batch.setColor(1f, 1f, 1f, 1f);
      batch.draw(uiRegions.slot, x, by - iconFrame + 10f, iconFrame, iconFrame);
      if (walletCoinGoldIcon != null) {
        batch.draw(walletCoinGoldIcon, x + (iconFrame - iconInner) * 0.5f, by - iconFrame + 10f + (iconFrame - iconInner) * 0.5f, iconInner, iconInner);
      }
      batch.draw(uiRegions.button, valueX, by - valueBoxH + 10f, valueW, valueBoxH);
      font.draw(batch, String.format("%.4f", gold), valueX + 16f, by - 8f);
    }

    font.getData().setScale(1.0f * UI_FONT_SCALE);
    font.setColor(0f, 0f, 0f, 1f);
  }

  private void drawPricingMenu() {
    float w = Math.min(1120f, Gdx.graphics.getWidth() - 40f);
    float h = Math.min(720f, Gdx.graphics.getHeight() - 40f);
    float x0 = (Gdx.graphics.getWidth() - w) * 0.5f;
    float y0 = (Gdx.graphics.getHeight() - h) * 0.5f;

    batch.setColor(1f, 1f, 1f, 1f);
    batch.draw(uiRegions.panelSlots, x0, y0, w, h);

    float pad = 26f;
    float x = x0 + pad;
    float yTop = y0 + h - pad;

    font.setColor(0f, 0f, 0f, 1f);
    font.getData().setScale(1.6f * 1.15f);
    font.draw(batch, "PRICING (Shift+F12 close) | F5 Save | F8 Reset(defaults) | F9 Preset", x, yTop);
    font.getData().setScale(1.0f * UI_FONT_SCALE);

    float y = yTop - 40f;
    font.getData().setScale(1.0f * 1.15f);
    font.draw(batch, "[Item]   Current(Copper)   Current(Gold)     New(Copper)   New(Gold)", x, y);
    font.getData().setScale(1.0f * UI_FONT_SCALE);
    y -= 22f;

    int visible = pricingVisibleRows();
    int start = pricingScroll;
    int end = Math.min(pricingEditCopper.length, start + visible);

    for (int itemId = start; itemId < end; itemId++) {
      boolean sel = (itemId == pricingSel);
      if (sel) {
        // simple highlight bar
        batch.setColor(1f, 1f, 1f, 0.10f);
        batch.draw(uiRegions.slotPressed, x - 10f, y - 16f, w - pad * 2f + 20f, 22f);
        batch.setColor(1f, 1f, 1f, 1f);
      }

      String name = (itemId >= 0 && itemId < data.items.length && data.items[itemId] != null) ? data.items[itemId].name : ("item_" + itemId);
      int cur = priceBook.getBaseCopper(itemId);
      int neu = pricingEditCopper[itemId];

      String curGold = com.yourgame.survival.data.PriceBook.fmtGoldFromCopper(cur);
      String newGold = com.yourgame.survival.data.PriceBook.fmtGoldFromCopper(neu);

      String newCopperStr = (sel ? (pricingEditBuffer.isEmpty() ? "" : pricingEditBuffer) : String.valueOf(neu));

      font.draw(batch, String.format("%02d %-18s %8d   %-10s   %8s   %-10s", itemId, name, cur, curGold, newCopperStr, newGold), x, y);
      y -= 22f;
    }

    if (pricingPresetPopup) {
      float popupY = y0 + 120f;
      font.getData().setScale(1.3f);
      font.draw(batch, "PRESET wählen (1..9) | ESC abbrechen", x, popupY);
      font.getData().setScale(1.0f * UI_FONT_SCALE);
      popupY -= 24f;
      if (pricingPresetNames == null || pricingPresetNames.length == 0) {
        font.draw(batch, "(keine Presets gefunden in: pricing_presets/*.json)", x, popupY);
      } else {
        for (int i = 0; i < pricingPresetNames.length; i++) {
          font.draw(batch, (i + 1) + ") " + pricingPresetNames[i], x, popupY - i * 18f);
        }
      }
    }
  }

  private void preloadSkillIcons() {
    if (skillIconsLoaded) return;

    for (int i = 0; i < SkillDefs.COUNT; i++) {
      String path = SkillDefs.ICON_PATH[i];
      if (path == null || path.isEmpty()) continue;

      try {
        FileHandle fh = Gdx.files.internal(path);
        if (fh == null || !fh.exists()) continue;

        Texture t = new Texture(fh);
        // crisp pixel art
        t.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest);
        skillIconTex.put(i, t);
      } catch (Throwable ignored) {
        // keep menu usable even if one icon fails
      }
    }

    skillIconsLoaded = true;
  }

  private Texture getSkillIconTex(int idx) {
    if (idx < 0 || idx >= SkillDefs.COUNT) return null;
    return skillIconTex.get(idx);
  }

  private static String keyCatSub(String catKey, String subLabel) {
    return catKey + "::" + subLabel;
  }

  private void addSkillMenuSub(String catKey, String sub, String... skillIds) {
    String subKey = keyCatSub(catKey, sub);
    skillMenuRows.add(new SkillMenuRow(SkillMenuRow.HEADER2, sub, -1, catKey, subKey));
    skillMenuSubOpen.putIfAbsent(subKey, true);

    for (String sid : skillIds) {
      int idx = SkillDefs.indexOf(sid);
      if (idx >= 0) skillMenuRows.add(new SkillMenuRow(SkillMenuRow.SKILL, SkillDefs.NAME_DE[idx], idx, catKey, subKey));
    }
  }

  private void buildSkillMenuRows() {
    if (skillMenuRowsBuilt) return;
    skillMenuRows.clear();

    // Matches docs/Vision_Skizze.png structure: 5 categories with subcategories.
    // Ressourcen
    skillMenuRows.add(new SkillMenuRow(SkillMenuRow.HEADER1, "Ressourcen", -1, "Ressourcen", null));
    skillMenuCatOpen.putIfAbsent("Ressourcen", true);
    addSkillMenuSub("Ressourcen", "Sammeln", "Mining", "Woodcutting", "Herbalism", "Hunting", "Fishing", "Foraging");
    addSkillMenuSub("Ressourcen", "Verarbeitung", "Smelting", "Tanning", "Alchemy", "Cooking");

    // Kampf
    skillMenuRows.add(new SkillMenuRow(SkillMenuRow.HEADER1, "Kampf", -1, "Kampf", null));
    skillMenuCatOpen.putIfAbsent("Kampf", true);
    addSkillMenuSub("Kampf", "Waffen", "CombatMelee", "CombatRanged", "WeaponCraft", "DualWield", "ShieldMastery");
    addSkillMenuSub("Kampf", "Verteidigung", "ArmorCraft", "Dodging", "Parrying", "Toughness");
    addSkillMenuSub("Kampf", "Taktik", "Stealth", "Tracking", "Looting");

    // Soziales
    skillMenuRows.add(new SkillMenuRow(SkillMenuRow.HEADER1, "Soziales", -1, "Soziales", null));
    skillMenuCatOpen.putIfAbsent("Soziales", true);
    addSkillMenuSub("Soziales", "Handel", "Trading", "Barter", "Intimidation", "Persuasion");
    addSkillMenuSub("Soziales", "Support", "Leadership", "Negotiation", "Reputation");

    // Person
    skillMenuRows.add(new SkillMenuRow(SkillMenuRow.HEADER1, "Person", -1, "Person", null));
    skillMenuCatOpen.putIfAbsent("Person", true);
    addSkillMenuSub("Person", "Vitals", "Health", "Stamina", "HungerControl", "SleepControl");
    addSkillMenuSub("Person", "Mobilität", "CarryCapacity", "Climbing", "Boating", "FlyingEfficiency");
    addSkillMenuSub("Person", "Survival", "ColdResistance", "HeatResistance");

    // Andere
    skillMenuRows.add(new SkillMenuRow(SkillMenuRow.HEADER1, "Andere", -1, "Andere", null));
    skillMenuCatOpen.putIfAbsent("Andere", true);
    addSkillMenuSub("Andere", "Bauen", "Building");
    addSkillMenuSub("Andere", "Übernatürlich", "MagicAffinity", "SpiritSight", "Blessing");
    addSkillMenuSub("Andere", "Utility", "Crafting", "Engineering", "ToolDurability", "Navigation", "Scavenging");

    skillMenuRowsBuilt = true;
  }

  private void drawSkillMenu() {
    // Modal overlay. Simulation is paused elsewhere.
    float mx = Gdx.input.getX();
    float my = uiMouseYUp();

    // Close (ESC). Note: P toggling is handled in the main input section to avoid instant close on the open-press.
    if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
      skillsOpen = false;
      return;
    }

    // Fit to screen (avoid negative x/y on smaller resolutions)
    float screenW = Gdx.graphics.getWidth();
    float screenH = Gdx.graphics.getHeight();
    float w = Math.min(1120f, screenW - 40f);
    float h = Math.min(720f, screenH - 40f);
    w = Math.max(520f, w);
    h = Math.max(360f, h);
    float x0 = (screenW - w) * 0.5f;
    float y0 = (screenH - h) * 0.5f;
    if (x0 < 20f) x0 = 20f;
    if (y0 < 20f) y0 = 20f;

    batch.setColor(1f, 1f, 1f, 1f);
    batch.draw(uiRegions.panelSlots, x0, y0, w, h);

    font.setColor(0f, 0f, 0f, 1f);
    font.getData().setScale(1.6f * UI_FONT_SCALE);
    font.draw(batch, "SKILLBAUM", x0 + 36f, y0 + h - 28f);

    font.getData().setScale(1.0f * UI_FONT_SCALE);
    font.draw(batch, "Abenteurer Lvl: " + progress.level + "   XP: " + progress.xp + "/" + progress.xpToNext + "   Skillpunkte: " + progress.skillPoints, x0 + 36f, y0 + h - 70f);
    font.draw(batch, "ESC oder P = schließen | Klick auf Skill = +1", x0 + 36f, y0 + h - 104f);

    float listX = x0 + 36f;
    float listYTop = y0 + h - 150f;
    float listYBottom = y0 + 36f;

    // row metrics
    float rowSkillH = 42f * UI_FONT_SCALE;
    float rowHeader1H = 44f * UI_FONT_SCALE;
    float rowHeader2H = 38f * UI_FONT_SCALE;

    // Compute total content height (visible rows only) to clamp scroll.
    float totalH = 0f;
    for (int ri = 0; ri < skillMenuRows.size(); ri++) {
      SkillMenuRow r = skillMenuRows.get(ri);
      boolean visible = true;
      if (r.kind != SkillMenuRow.HEADER1) {
        visible = skillMenuCatOpen.getOrDefault(r.catKey, true);
        if (visible && r.kind == SkillMenuRow.SKILL) {
          visible = skillMenuSubOpen.getOrDefault(r.subKey, true);
        }
        if (visible && r.kind == SkillMenuRow.HEADER2) {
          visible = true; // sub headers are visible when category is open
        }
      }
      if (!visible) continue;
      float rh = (r.kind == SkillMenuRow.SKILL) ? (42f * UI_FONT_SCALE) : (r.kind == SkillMenuRow.HEADER1 ? (44f * UI_FONT_SCALE) : (38f * UI_FONT_SCALE));
      totalH += rh;
    }
    float viewH = Math.max(1f, listYTop - listYBottom);
    float maxScroll = Math.max(0f, totalH - viewH);
    if (skillMenuScrollPx > maxScroll) skillMenuScrollPx = maxScroll;

    String catHoverKey = null;
    String subHoverKey = null;

    skillHover = -1;
    float y = listYTop + skillMenuScrollPx;
    for (int ri = 0; ri < skillMenuRows.size(); ri++) {
      SkillMenuRow r = skillMenuRows.get(ri);

      if (r.kind != SkillMenuRow.HEADER1) {
        boolean catOpen = skillMenuCatOpen.getOrDefault(r.catKey, true);
        if (!catOpen) continue;

        // skills are only visible if their subcategory is open
        if (r.kind == SkillMenuRow.SKILL) {
          boolean subOpen = skillMenuSubOpen.getOrDefault(r.subKey, true);
          if (!subOpen) continue;
        }
      }

      float rh = (r.kind == SkillMenuRow.SKILL) ? rowSkillH : (r.kind == SkillMenuRow.HEADER1 ? rowHeader1H : rowHeader2H);
      float ry = y;
      // skip rows above the visible window
      if (ry > listYTop + rh) {
        y -= rh;
        continue;
      }
      // stop when we are past the bottom
      if (ry < listYBottom) break;

      switch (r.kind) {
        case SkillMenuRow.HEADER1 -> {
          boolean hov = mx >= listX && mx <= listX + (w - 72f) && my >= ry - rh + 6f && my <= ry + 6f;
          if (hov) catHoverKey = r.catKey;

          boolean open = skillMenuCatOpen.getOrDefault(r.catKey, true);
          String twisty = open ? "[-]" : "[+]";

          // Category: distinct big button
          batch.setColor(1f, 1f, 1f, 1f);
          batch.draw(hov ? uiRegions.buttonPressed : uiRegions.button, listX, ry - rh + 8f, w - 72f, rh - 8f);

          font.setColor(0f, 0f, 0f, 1f);
          font.getData().setScale(1.20f * UI_FONT_SCALE);
          font.draw(batch, twisty + "  " + r.label, listX + 16f, ry - 12f);
        }
        case SkillMenuRow.HEADER2 -> {
          // Subcategory indent (about "2 tiles"), keep right edge aligned by shrinking width.
          float subIndent = 64f;
          float subX = listX + 10f + subIndent;
          float subW = (w - 72f) - 20f - subIndent;

          boolean hov = mx >= subX && mx <= subX + subW && my >= ry - rh + 6f && my <= ry + 6f;
          if (hov) subHoverKey = r.subKey;

          boolean open = skillMenuSubOpen.getOrDefault(r.subKey, true);
          String twisty = open ? "[-]" : "[+]";

          // Subcategory: distinct medium row
          batch.setColor(1f, 1f, 1f, 1f);
          batch.draw(hov ? uiRegions.buttonPressed : uiRegions.button, subX, ry - rh + 10f, subW, rh - 12f);

          font.setColor(0f, 0f, 0f, 1f);
          font.getData().setScale(1.05f * UI_FONT_SCALE);
          font.draw(batch, twisty + "  " + r.label, subX + 18f, ry - 12f);
        }
        default -> {
          int i = r.skillIndex;

        // Skill indent (relative to subcategory position), keep right edge aligned.
        float subIndentBase = 64f;
        float skillIndent = subIndentBase + 64f;
        float sx = listX + skillIndent;
        float sw = (w - 72f) - skillIndent;

        boolean hov = mx >= sx && mx <= sx + sw && my >= ry - rh + 6f && my <= ry + 6f;
        if (hov) skillHover = i;

        batch.setColor(1f, 1f, 1f, 1f);
        batch.draw(hov ? uiRegions.buttonPressed : uiRegions.button, sx, ry - rh + 8f, sw, rh - 8f);

        int lv = (i >= 0 && i < progress.skillLv.length) ? progress.skillLv[i] : 0;
        int cost = SkillEffects.upgradeCost(lv);
        String line = SkillDefs.NAME_DE[i] + "   [" + lv + "/50]" + "   Kosten: " + cost;

        float iconS = Math.min(32f * UI_FONT_SCALE, rh - 12f);
        Texture iconTex = getSkillIconTex(i);
        float textX = sx + 20f;
        if (iconTex != null) {
          float ix = sx + 10f;
          float iy = (ry - rh + 8f) + ((rh - 8f) - iconS) * 0.5f;

          // Keep aspect ratio (avoid squashing tall/wide sprites)
          float tw = Math.max(1f, iconTex.getWidth());
          float th = Math.max(1f, iconTex.getHeight());
          float s = Math.min(iconS / tw, iconS / th);
          float dw = tw * s;
          float dh = th * s;
          float dx = ix + (iconS - dw) * 0.5f;
          float dy = iy + (iconS - dh) * 0.5f;

          batch.setColor(1f, 1f, 1f, 1f);
          batch.draw(iconTex, dx, dy, dw, dh);
          textX = ix + iconS + 14f;
        }

        font.setColor(0f, 0f, 0f, 1f);
        font.getData().setScale(1.0f * UI_FONT_SCALE);
        font.draw(batch, line, textX, ry - 12f);
        }
      }

      y -= rh;
    }

    if (Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)) {
      // Toggle category dropdown
      if (catHoverKey != null) {
        boolean open = skillMenuCatOpen.getOrDefault(catHoverKey, true);
        skillMenuCatOpen.put(catHoverKey, !open);
        game.audio.sfx("audio/sfx/ui_click.wav", game.audio.sfxVolume(game.settings));
        return;
      }

      // Toggle subcategory dropdown
      if (subHoverKey != null) {
        boolean open = skillMenuSubOpen.getOrDefault(subHoverKey, true);
        skillMenuSubOpen.put(subHoverKey, !open);
        game.audio.sfx("audio/sfx/ui_click.wav", game.audio.sfxVolume(game.settings));
        return;
      }

      // Click skill
      if (skillHover >= 0) {
        int i = skillHover;
        if (i >= 0 && i < progress.skillLv.length) {
          int curLv = progress.skillLv[i];
          int cost = SkillEffects.upgradeCost(curLv);

          if (curLv < 50 && progress.skillPoints >= cost) {
             
          } else {
            game.audio.sfx("audio/sfx/ui_error.wav", game.audio.sfxVolume(game.settings));
          }
        } else {
          game.audio.sfx("audio/sfx/ui_error.wav", game.audio.sfxVolume(game.settings));
        }
      }
    }
  }

  /** Ensures cursor state is re-applied after leaving a modal screen (Pause/Options/etc). */
  public void forceCursorResync() {
    lastCursorHidden = !lastCursorHidden;
  }

  // -----------------------------------------------------------------------------
  // Block 7 helper types (structural only; keep allocations out of hot paths)
  // -----------------------------------------------------------------------------

  private static final class RenderScratch {
    final Vector2 v2a = new Vector2();
    final Vector3 v3a = new Vector3();
    final Vector3 v3b = new Vector3();

    final Rectangle r0 = new Rectangle();
    final Rectangle r1 = new Rectangle();
  }

  // Nicht fertiges Feature: unused placeholder type (no current gameflow usage)
  /*
  private static final class UiState {
    // Placeholder for future UI state consolidation.
    boolean reserved;
  }
  */

  private static final class InputState {
    // Nicht fertiges Feature: currently never read
    // float delta;
    // int mx;
    // int my;
  }

  // Nicht fertiges Feature: unused placeholder type (no current gameflow usage)
  /*
  private static final class CommandBuffer {
    // Placeholder for future command buffering.
    int size = 0;
    void clear() { size = 0; }
  }
  */


  // Nicht fertiges Feature: commented out unused block
  /*
  private static int anchorToStep(int tile, int step) {
    if (step <= 1) return tile;
    // Round to nearest multiple of step (works for negative coordinates too).
    int m = Math.round(tile / (float) step);
    return m * step;
  }
  */

}
